/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osci_logi_console;

import java.awt.Dimension;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

/**
 *
 * @author akira
 */
public class Window extends JPanel {
    
    public int window_width;
    public int window_height;
    public int x_posi;
    public int y_posi;
    public boolean v_flag;
    public int cursor_posi;
    public int prev_cursor_posi;

    public int cursor_logiana_sampling_posi;
    public int cursor_oscillo_sampling_posi;
    public float cursor_time_posi;

    public int v_scale;   //  real_scale*256
    public int h_scale;   //  ex. 0x100 ==> 1.0
    public boolean och0_flag;
    public boolean och1_flag;
    public boolean och2_flag;
    public boolean och3_flag;
    public boolean lch0_flag;
    public boolean lch1_flag;
    public boolean lch2_flag;
    public boolean lch3_flag;
    public boolean lch4_flag;
    public boolean lch5_flag;
    public boolean lch6_flag;
    public boolean lch7_flag;
    public boolean lch8_flag;
    public boolean lch9_flag;
    public boolean lch10_flag;
    public boolean lch11_flag;
    public boolean type_flag;     // true:Oscillo type　false:Logiana type
    
//    public static final int Q_SIZE = Main_Frame.CANVAS_HEIGHT/4;
//    public static final int H_SIZE = Main_Frame.CANVAS_HEIGHT/2;
//    public static final int F_SIZE = Main_Frame.CANVAS_HEIGHT;
    public static final int BORDER = 5;
    public static final int DRAWING_HEIGHT_OFFSET = 20;
   
    public static int F_SIZE;
    public static int Q_SIZE;
    public static int H_SIZE;
    public static int Top_POSI;
    public static int Snd_POSI;
    public static int Trd_POSI;
    public static int Btm_POSI;
    
    public static final int SCALE_1_1 = 0x100;
    public static final int SCALE_2_1 = 0x200;
    public static final int SCALE_4_1 = 0x400;
    public static final int SCALE_8_1 = 0x800;
    public static final int SCALE_1_2 = 0x080;
    public static final int SCALE_1_4 = 0x040;
    public static final int SCALE_1_8 = 0x020;
    public static final boolean OSCILLO_TYPE = true;
    public static final boolean LOGIANA_TYPE = false;
    public static final int AUTO_UPDATE = 1;
    public static final int DATA_HOLD = 2;
    public static final int DATA_UPDATE = 3;

    private javax.swing.JScrollPane ScrollPane;
    public static int Canvas_Width;
    public static int Canvas_Height;
//    public int offset_posi;
    
    private Drawing_Panel drawing_panel;
    private Grid_Panel grid_panel;
    private Cursor_Panel cursor_panel;
    private javax.swing.JPanel base_panel;
    private int logiana_draw_ch_cnt;
    private int oscillo_draw_ch_cnt;
    private int sub_window;
    private Dimension drawing_size;
    private Dimension window_size;
    public int draw_range;
    public int draw_right_posi;
    public int draw_left_posi;
    public int draw_min_posi;
    public int draw_max_posi;
    public Log_Data log_data;
    public int[] logiana_draw_ch; 
    public int[] oscillo_draw_ch;
//    public boolean oscillo_data_display;
//    public boolean logiana_data_display;
    public boolean data_display_flag;
    public int logiana_cursor_data;
//    public int logiana_cursor_x_posi;
    public int[] logiana_cursor_y_posi;
    public int[] oscillo_cursor_data;
    public int cursor_x_posi;
    public int[] oscillo_cursor_y_posi;
    
    public int oscillo_start_point;
    public int oscillo_trigger_point;
    public int oscillo_end_point;
    public int logiana_start_point;
    public int logiana_trigger_point;
    public int logiana_end_point;
    public boolean hold_flag;
    public boolean[] oscillo_ch_selectable = new boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
    public boolean[] logiana_ch_selectable = new boolean[Log_Data.LOGIANA_MAX_CH_COUNT];
    public boolean redraw;
    private String w_name;
    Message_dialog data_display;

    public Window(int c_w,int c_h, String s){
       super();
       Canvas_Width = c_w;
       Canvas_Height = c_h;

       F_SIZE = Canvas_Height-BORDER*2;
       Q_SIZE = (F_SIZE-BORDER*3)/4;
       H_SIZE = Q_SIZE*2+BORDER;
       Top_POSI = BORDER;
       Snd_POSI = Top_POSI+Q_SIZE+BORDER;
       Trd_POSI = Snd_POSI+Q_SIZE+BORDER;
       Btm_POSI = Trd_POSI+Q_SIZE+BORDER;
       window_initialize(s);
    }

    public Window(String s){
       super();
       window_initialize(s);
    }

    private void window_initialize(String s){
       log_data = Osci_logi.current_log;

       logiana_draw_ch = new int[Log_Data.LOGIANA_MAX_CH_COUNT];
       oscillo_draw_ch = new int[Log_Data.OSCILLO_MAX_CH_COUNT];
       oscillo_cursor_data = new int[Log_Data.OSCILLO_MAX_CH_COUNT];
       oscillo_cursor_y_posi = new int[Log_Data.OSCILLO_MAX_CH_COUNT];
       logiana_cursor_y_posi = new int[Log_Data.LOGIANA_MAX_CH_COUNT];
       
       window_size = new java.awt.Dimension();
       v_flag = false;
       type_flag = LOGIANA_TYPE;
       x_posi = BORDER;
       y_posi = BORDER;
       v_scale = SCALE_1_1;
       h_scale = SCALE_1_1;
       window_width = Canvas_Width - BORDER*2;
       window_height = Q_SIZE;
       logiana_draw_ch_cnt = 0;
       oscillo_draw_ch_cnt = 0;
       
       base_panel = new javax.swing.JPanel();
       base_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
       base_panel.setOpaque(true);
       base_panel.setBackground(Main_Frame.CANVAS_COLOR);

       drawing_panel = new Drawing_Panel(this);

       grid_panel = new Grid_Panel(this);
       cursor_panel = new Cursor_Panel(this);
       ScrollPane = new javax.swing.JScrollPane();
       ScrollPane.setViewportView(base_panel);
       this.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
       this.add(ScrollPane, new AbsoluteConstraints(0, 0, -1, -1));

       set_draw_parameter();
       data_display_flag = false;
      
       hold_flag = false;
       prev_cursor_posi = -100000;

       och0_flag = false;
       och1_flag = false;
       och2_flag = false;
       och3_flag = false;
       lch0_flag = false;
       lch1_flag = false;
       lch2_flag = false;
       lch3_flag = false;
       lch4_flag = false;
       lch5_flag = false;
       lch6_flag = false;
       lch7_flag = false;
       lch8_flag = false;
       lch9_flag = false;
       
       redraw = true;
       w_name = s;
       data_display = new Message_dialog(w_name+" cursor data");
    }
    
    public void set_height_14(){
        window_height = Q_SIZE;
    }

    public void set_height_12(){
        window_height = H_SIZE;
    }
    
    public void set_height_11(){
        window_height = F_SIZE;
    }
    
    public void top_posi(){
        y_posi = Top_POSI;
    }
    
    public void second_posi(){
        y_posi = Snd_POSI;
    }
    
    public void third_posi(){
        y_posi = Trd_POSI;
    }
    
    public void bottom_posi(){
        y_posi = Btm_POSI;
    }
    
    public void update_draw_range(){
       draw_range = ( window_width * 256 ) / h_scale;
    }
    
    public void update_s_t_e()
    {
       int t_point;
       int s_point;
       int e_point;
    
       if(log_data.logiana_cell_size ==0 )log_data.logiana_cell_size = 2;
       
       t_point = log_data.logiana_trigger_point / log_data.logiana_cell_size;
       s_point = log_data.logiana_start_point / log_data.logiana_cell_size;
       e_point = log_data.logiana_end_point / log_data.logiana_cell_size;
       
       if( s_point > t_point )
       {
         t_point += Log_Data.LOGIANA_MAX_DATA_COUNT;
         e_point += Log_Data.LOGIANA_MAX_DATA_COUNT;
       }
       else if( t_point > e_point )
       {
         e_point += Log_Data.LOGIANA_MAX_DATA_COUNT;
       }
       logiana_trigger_point = t_point;
       logiana_start_point = s_point;
       logiana_end_point = e_point;
       
//       Debug.print("logiana_trigger_point=", logiana_trigger_point, "\n");
//       Debug.print("logiana_start_point=", logiana_start_point, "\n");
//       Debug.print("logiana_end_point=", logiana_end_point, "\n");
    
       if(log_data.oscillo_cell_size ==0 )log_data.oscillo_cell_size = 8;
       t_point = log_data.oscillo_trigger_point / log_data.oscillo_cell_size;
       s_point = log_data.oscillo_start_point / log_data.oscillo_cell_size;
       e_point = log_data.oscillo_end_point / log_data.oscillo_cell_size;
       
       if( s_point > t_point )
       {
         t_point += Log_Data.OSCILLO_MAX_DATA_COUNT/(log_data.oscillo_cell_size/2);
         e_point += Log_Data.OSCILLO_MAX_DATA_COUNT/(log_data.oscillo_cell_size/2);
       }
       else if( t_point > e_point )
       {
         e_point += Log_Data.OSCILLO_MAX_DATA_COUNT/(log_data.oscillo_cell_size/2);
       }
       oscillo_trigger_point = t_point;
       oscillo_start_point = s_point;
       oscillo_end_point = e_point;
       
//       Debug.print("oscillo_trigger_point=", oscillo_trigger_point, "\n");
//       Debug.print("oscillo_start_point=", oscillo_start_point, "\n");
//       Debug.print("oscillo_end_point=", oscillo_end_point, "\n");
    }
    
    public void set_draw_parameter()
    {
        if( type_flag == LOGIANA_TYPE )
        {
           draw_min_posi = logiana_start_point - logiana_trigger_point;
           draw_max_posi = logiana_end_point - logiana_trigger_point;
           draw_left_posi = draw_min_posi;
        }
        else
        {
           draw_min_posi = oscillo_start_point - oscillo_trigger_point;
           draw_max_posi = oscillo_end_point - oscillo_trigger_point;
           draw_left_posi = draw_min_posi;
        }
        update_draw_range();
    }
   
    
    public static final int SUB_OSCILLO = 100;
    public static final int SUB_LOGIANA_CH = 20;

    public int logiana_draw_ch_count_debug()
    {
        return logiana_draw_ch_count();
    }
            
    private int logiana_draw_ch_count()
    {
    int ch;
      ch = 0;
      if( lch0_flag )
      { 
          logiana_draw_ch[ch++] = 0;
      }
      if( lch1_flag )
      { 
          logiana_draw_ch[ch++] = 1;
      }
      if( lch2_flag )
      { 
          logiana_draw_ch[ch++] = 2;
      }
      if( lch3_flag )
      { 
          logiana_draw_ch[ch++] = 3;
      }
      if( lch4_flag )
      { 
          logiana_draw_ch[ch++] = 4;
      }
      if( lch5_flag )
      { 
          logiana_draw_ch[ch++] = 5;
      }
      if( lch6_flag )
      { 
          logiana_draw_ch[ch++] = 6;
      }
      if( lch7_flag )
      { 
          logiana_draw_ch[ch++] = 7;
      }
      if( lch8_flag )
      { 
          logiana_draw_ch[ch++] = 8;
      }
      if( lch9_flag )
      { 
          logiana_draw_ch[ch++] = 9;
      }
      if( lch10_flag )
      { 
          logiana_draw_ch[ch++] = 10;
      }
      if( lch11_flag )
      { 
          logiana_draw_ch[ch++] = 11;
      }
      
      for(int i=ch ; i<Log_Data.LOGIANA_MAX_CH_COUNT;i++)
      {
        logiana_draw_ch[i] = -1;
      }
      return ch;
    }

    public int oscillo_draw_ch_count_debug()
    {
      return oscillo_draw_ch_count();
    }
            
    private int oscillo_draw_ch_count()
    {
    int ch;
      ch = 0;
      if( och0_flag )
      { 
          oscillo_draw_ch[ch++] = 0;
      }
      if( och1_flag )
      { 
          oscillo_draw_ch[ch++] = 1;
      }
      if( och2_flag )
      { 
          oscillo_draw_ch[ch++] = 2;
      }
      if( och3_flag )
      { 
          oscillo_draw_ch[ch++] = 3;
      }
      for(int i=ch ; i<Log_Data.OSCILLO_MAX_CH_COUNT;i++)
      {
        oscillo_draw_ch[i] = -1;
      }
      return ch;
    }

    private Dimension calc_drawing_panel_size(){
        Dimension dim = new java.awt.Dimension();
//        dim.width = this.window_width;
//        dim.width = DRAWING_PANEL_SIZE;
//        dim.width = canvas_width;
        dim.width = window_width;
        dim.height = F_SIZE - DRAWING_HEIGHT_OFFSET;
        logiana_draw_ch_cnt = logiana_draw_ch_count();
        oscillo_draw_ch_cnt = oscillo_draw_ch_count();
        if( this.type_flag == OSCILLO_TYPE )
        {
          sub_window = logiana_draw_ch_count()*SUB_LOGIANA_CH;
        }
        else if( oscillo_draw_ch_count() >= 1 )
        {
            sub_window = SUB_OSCILLO;
        }
        else
        {
          sub_window = 0;
        }
//        dim.height += sub_window;
        return dim; 
    }            

    private void set_cursor_time_posi()
    {
      if( type_flag == OSCILLO_TYPE )
      {
        cursor_time_posi = cursor_posi*drawing_panel.oscillo_interval;
      }
      else
      {
        cursor_time_posi = cursor_posi*drawing_panel.logiana_interval;
      }
    }

    // call from View_Canvas() Main_Frame.java:83   
    public void setup() {
        window_size.height= window_height;
        window_size.width = window_width;
        setPreferredSize(window_size);
        setBackground(Main_Frame.CANVAS_COLOR);
       
       // draw line
       base_panel.removeAll();
       drawing_size = calc_drawing_panel_size();
       
       base_panel.setPreferredSize( drawing_size );

       drawing_panel.clear_draw();
       grid_panel.clear_grid();
       cursor_panel.clear_cursor();

       set_cursor_time_posi();
       
       drawing_panel.setPreferredSize( drawing_size );
       grid_panel.setPreferredSize( drawing_size );
       cursor_panel.setPreferredSize( drawing_size );
       
       grid_panel.set_grid_parameter(type_flag, logiana_draw_ch_cnt, oscillo_draw_ch_cnt, sub_window );
       grid_panel.repaint();
       cursor_panel.set_draw_parameter( draw_left_posi, h_scale );
       cursor_panel.repaint();

//       drawing_panel.set_data_parameter(log_data);
       drawing_panel.set_data_parameter();
       drawing_panel.set_draw_parameter(type_flag, logiana_draw_ch_cnt, oscillo_draw_ch_cnt, sub_window, draw_left_posi, h_scale );
       drawing_panel.repaint();

       base_panel.add(drawing_panel, new AbsoluteConstraints(0, 0, -1, -1));
       base_panel.add(grid_panel, new AbsoluteConstraints(0, 0, -1, -1));
       base_panel.add(cursor_panel, new AbsoluteConstraints(0, 0, -1, -1));
       
       base_panel.repaint();
       ScrollPane.setPreferredSize(window_size );
       
//       new Exception("Window setup()").printStackTrace();
    }
    
    void set_oscillo_cursor_y_posi( int ch, int y_posi )
    {
        oscillo_cursor_y_posi[ch] = y_posi;
    }
    
    void set_logiana_cursor_y_posi( int ch, int y_posi )
    {
        logiana_cursor_y_posi[ch] = y_posi;
    }
    
    void clear_cursor_data()
    {
//        cursor_x_posi = 0;
        for(int ch=0 ; ch<Log_Data.OSCILLO_MAX_CH_COUNT;ch++)
        {
          oscillo_cursor_data[ch] = -1;
//          oscillo_cursor_y_posi[ch] = 0;
        }
        
        logiana_cursor_data = 0;
//        logiana_cursor_x_posi = 0;
//        for(int ch=0 ; ch<Log_Data.LOGIANA_MAX_CH_COUNT;ch++)
//        {
//          logiana_cursor_y_posi[ch] = -1;
//        }
    }
    
//    public void set_logiana_ch_flag(int ch, boolean flag)
//    {
//      switch(ch)
//      {
//        case 0:
//            logiana_ch_selectable[0] = flag;
//            if( ( lch0_flag ) && ( !flag ) )
//            {
//              lch0_flag = flag;
//            }
//            break;
//        case 1:
//            logiana_ch_selectable[1] = flag;
//            if( ( lch1_flag ) && ( !flag ) )
//            {
//              lch1_flag = flag;
//            }
//            break;
//        case 2:
//            logiana_ch_selectable[2] = flag;
//            if( ( lch2_flag ) && ( !flag ) )
//            {
//              lch2_flag = flag;
//            }
//            break;
//        case 3:
//            logiana_ch_selectable[3] = flag;
//            if( ( lch3_flag ) && ( !flag ) )
//            {
//              lch3_flag = flag;
//            }
//            break;
//        case 4:
//            logiana_ch_selectable[4] = flag;
//            if( ( lch4_flag ) && ( !flag ) )
//            {
//              lch4_flag = flag;
//            }
//            break;
//        case 5:
//            logiana_ch_selectable[5] = flag;
//            if( ( lch5_flag ) && ( !flag ) )
//            {
//              lch5_flag = flag;
//            }
//            break;
//        case 6:
//            logiana_ch_selectable[6] = flag;
//            if( ( lch6_flag ) && ( !flag ) )
//            {
//              lch6_flag = flag;
//            }
//            break;
//        case 7:
//            logiana_ch_selectable[7] = flag;
//            if( ( lch7_flag ) && ( !flag ) )
//            {
//              lch7_flag = flag;
//            }
//            break;
//        case 8:
//            logiana_ch_selectable[8] = flag;
//            if( ( lch8_flag ) && ( !flag ) )
//            {
//              lch8_flag = flag;
//            }
//            break;
//        case 9:
//            logiana_ch_selectable[9] = flag;
//            if( ( lch9_flag ) && ( !flag ) )
//            {
//              lch9_flag = flag;
//            }
//            break;
//      }
//    }
    
//    public void set_oscillo_ch_flag(int ch, boolean flag)
//    {
//      switch(ch)
//      {
//        case 0:
//            Debug.print("@set_oscillo_ch_flag flag=", flag,"\n");
//            if( ( och0_flag ) && ( !flag ) )
//            {
//              och0_flag = flag;
//            }
//            oscillo_ch_selectable[0] = flag;
//            Debug.print("och_0=", och0_flag,"\n");
//            break;
//        case 1:
//            if( ( och1_flag ) && ( !flag ) )
//            {
//              och1_flag = flag;
//            }
//            oscillo_ch_selectable[1] = flag;
//            break;
//        case 2:
//            if( ( och2_flag ) && ( !flag ) )
//            {
//              och2_flag = flag;
//            }
//            oscillo_ch_selectable[2] = flag;
//            break;
//        case 3:
//            if( ( och3_flag ) && ( !flag ) )
//            {
//              och3_flag = flag;
//            }
//            oscillo_ch_selectable[3] = flag;
//            break;
//      }
//    }

    public void set_ch_selectable_flag()
    {
       if( hold_flag )return;

       for( int ch=0; ch<Log_Data.LOGIANA_MAX_CH_COUNT;ch++)
       {
           logiana_ch_selectable[ch] = (log_data.logiana_sampling_ch_list[ch] >= 0);
       }
       
       if( ( lch0_flag ) && ( !logiana_ch_selectable[0] ) )
       {
         lch0_flag = false;
       }
       if( ( lch1_flag ) && ( !logiana_ch_selectable[1] ) )
       {
         lch1_flag = false;
       }
       if( ( lch2_flag ) && ( !logiana_ch_selectable[2] ) )
       {
         lch2_flag = false;
       }
       if( ( lch3_flag ) && ( !logiana_ch_selectable[3] ) )
       {
         lch3_flag = false;
       }
       if( ( lch4_flag ) && ( !logiana_ch_selectable[4] ) )
       {
         lch4_flag = false;
       }
       if( ( lch5_flag ) && ( !logiana_ch_selectable[5] ) )
       {
         lch5_flag = false;
       }
       if( ( lch6_flag ) && ( !logiana_ch_selectable[6] ) )
       {
         lch6_flag = false;
       }
       if( ( lch7_flag ) && ( !logiana_ch_selectable[7] ) )
       {
         lch7_flag = false;
       }
       if( ( lch8_flag ) && ( !logiana_ch_selectable[8] ) )
       {
         lch8_flag = false;
       }
       if( ( lch9_flag ) && ( !logiana_ch_selectable[9] ) )
       {
         lch9_flag = false;
       }
       
       for( int ch=0; ch<Log_Data.OSCILLO_MAX_CH_COUNT;ch++)
       {
           oscillo_ch_selectable[ch] = (log_data.oscillo_sampling_ch_list[ch] >= 0);
       }
       
       if( ( och0_flag ) && ( !oscillo_ch_selectable[0] ) )
       {
          och0_flag = false;
       }
       if( ( och1_flag ) && ( !oscillo_ch_selectable[1] ) )
       {
          och1_flag = false;
       }
       if( ( och2_flag ) && ( !oscillo_ch_selectable[2] ) )
       {
          och2_flag = false;
       }
       if( ( och3_flag ) && ( !oscillo_ch_selectable[3] ) )
       {
          och3_flag = false;
       }
//       Osci_logi.main_frame.update_selectable_ch();
    }
    
    public void hold_off()
    {
        log_data.close();
        hold_flag = false;
        log_data = Osci_logi.current_log;
        set_ch_selectable_flag();
    }
    
    public void hold_on()
    {
       hold_flag = true;
       log_data = (Log_Data) Osci_logi.current_log.clone();
    }
    
    public void cursor_to_sampling_posi()
    {
      cursor_logiana_sampling_posi = drawing_panel.calc_cursor_sampling_posi( LOGIANA_TYPE );
      cursor_oscillo_sampling_posi = drawing_panel.calc_cursor_sampling_posi( OSCILLO_TYPE );
    }
    
    public void show_window_name()
    {
       Debug.print("Window Name=",w_name,"\n");
       Debug.print("Log data=",log_data,"\n");
       Debug.print("start =",log_data.oscillo_start_point,"\n");
       Debug.print("trigger =",log_data.oscillo_trigger_point,"\n");
       Debug.print("end =",log_data.oscillo_end_point,"\n");
    }
    
    void show_cursor_data()
    {
        short bit_flag;
        data_display.Message_dialog_clear();
        data_display.Message_dialog_add("cursor_posi="+String.valueOf(cursor_posi)+"\n");
        data_display.Message_dialog_add("cursor_time_posi="+String.valueOf(cursor_time_posi)+"\n");
        
        cursor_to_sampling_posi();
        data_display.Message_dialog_add("cursor_logiana_sampling_posi="+String.valueOf(cursor_logiana_sampling_posi)+"\n");
        data_display.Message_dialog_add("cursor_oscillo_sampling_posi="+String.valueOf(cursor_oscillo_sampling_posi)+"\n");
        
        for(int ch=0 ; ch<Log_Data.OSCILLO_MAX_CH_COUNT;ch++)
        {
          oscillo_cursor_data[ch] = drawing_panel.get_oscillo_data( cursor_oscillo_sampling_posi, ch);
        }

        data_display.Message_dialog_add("cursor x_posi="+String.valueOf(cursor_x_posi)+"\n");
        
        data_display.Message_dialog_add("-------------------------\n");
        data_display.Message_dialog_add("oscillo\n");

        for(int ch=0 ; ch<Log_Data.OSCILLO_MAX_CH_COUNT;ch++)
        {
          data_display.Message_dialog_add("ch"+String.valueOf(ch)+"="+String.valueOf(oscillo_cursor_data[ch])+"\n");
        }
        
        if( cursor_logiana_sampling_posi < log_data.logiana_data.length )
        {
           logiana_cursor_data =  log_data.logiana_data[cursor_logiana_sampling_posi];
        }
        else
        {
          logiana_cursor_data = -1;
        }
        
        data_display.Message_dialog_add("-------------------------\n");
        data_display.Message_dialog_add("logiana\n");
        for(int ch=0 ; ch<Log_Data.LOGIANA_MAX_CH_COUNT;ch++)
        {
          bit_flag = (short)(1<<log_data.ch_to_bitposi(ch));
          if(( logiana_cursor_data&bit_flag ) != 0 )
          {
            data_display.Message_dialog_add("ch"+String.valueOf(ch)+"=1\n");
          }
          else
          {
            data_display.Message_dialog_add("ch"+String.valueOf(ch)+"=0\n");
          }
        }
    }
}
