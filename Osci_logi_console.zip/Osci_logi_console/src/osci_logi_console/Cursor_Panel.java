/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package osci_logi_console;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author akira
 */
public class Cursor_Panel extends JPanel {
 //=============================================================================
 //フィールド
 //=============================================================================

 //キャンバスの寸法
 Dimension dimension;
// int cursor_posi;
 Window parent;

 //グラフ化するデータ 

 //=============================================================================
 //コンストラクタ
 //=============================================================================
 Cursor_Panel( Window window)
 {
  super();
  parent = window;
  this.setOpaque(false);
//  cursor_posi = 0;
 }
 
// public void set_cursor(int posi )
// {
//   cursor_posi = posi;
// }

 int drawing_position;
 public void set_draw_parameter( int left_posi, int scale )
 {
   int offset;
   
   dimension = getSize();
   offset = parent.cursor_posi - left_posi;
   if( offset < 0 )
   {
     drawing_position = -1;   // out range
   }
   else
   {
     drawing_position = offset;
     drawing_position *= scale;
     drawing_position /= 256;
     
     if( ( drawing_position ) > dimension.width )
     {
       drawing_position = -1;   // out range
     }
   }
 }
 
 public void clear_cursor()
 {
   this.removeAll();
   parent.clear_cursor_data();
 }
 
  private void draw_cursor(Graphics g ) {
      Graphics2D g2d = (Graphics2D) g;
      g2d.setColor(Color.RED);
      g2d.drawLine( drawing_position, 0, drawing_position, dimension.height );
      parent.cursor_x_posi = drawing_position;
//      Debug.print("drawing_position=", drawing_position, "\n");
    }
     
 //=============================================================================
 //paint()メソッド
 //=============================================================================

    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        //領域のサイズ取得
        dimension = getSize();
        draw_cursor( g );
    }
}
