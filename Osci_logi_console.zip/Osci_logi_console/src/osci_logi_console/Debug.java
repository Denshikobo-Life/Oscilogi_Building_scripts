/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osci_logi_console;

/**
 *
 * @author akira
 */
public class Debug {
      public Debug() {
      }

      public static void print(String s1, Object o, String s2)
      {
        System.out.print(s1);
        System.out.print(o);
        System.out.print(s2);
      }

      public static String string(String s1, Object o, String s2)
      {
        return s1+o.toString()+s2;
      }
}

//new Exception("Stack trace").printStackTrace();



