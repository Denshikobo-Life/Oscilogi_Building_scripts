/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osci_logi_console;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author akira
 */
public class Log_Data implements Cloneable {
    static final int LOGIANA_MAX_CH_COUNT = 10;
    static final int OSCILLO_MAX_CH_COUNT = 4;
    static final int LOGIANA_MAX_DATA_COUNT = 4096;
    static final int OSCILLO_MAX_DATA_COUNT = 8192;
    static final float LOGIANA_MAX_SAMPLING_RATE = (float) 2000000; 
    static final float OSCILLO_MAX_SAMPLING_RATE = (float) 400000;
//    public static short[] logiana_data = new short[LOGIANA_MAX_DATA_COUNT];
//    public static int logiana_sampling_count;
//    public static int logiana_sampling_ch_count;
//    public static float logiana_sampling_rate;
//    public static int logiana_start_point;
//    public static int logiana_end_point;
//    public static int logiana_trigger_point;
//    public static int[] logiana_sampling_ch_list = new int[LOGIANA_MAX_CH_COUNT];
//    public static short[] oscillo_data = new short[OSCILLO_MAX_DATA_COUNT];
//    public static int oscillo_sampling_count;
//    public static int oscillo_sampling_ch_count;
//    public static float oscillo_sampling_rate;
//    public static int oscillo_start_point;
//    public static int oscillo_end_point;
//    public static int oscillo_trigger_point;
//    public static int[] oscillo_sampling_ch_list = new int[OSCILLO_MAX_CH_COUNT];
//    public static int[] oscillo_sampling_posi_list = new int[OSCILLO_MAX_CH_COUNT];
    
//    public static int logiana_data_count;    // sampling ch count
//    public static int oscillo_data_count;    // samplig ch count
       public short[] logiana_data;
       public int logiana_sampling_count;
       public int logiana_sampling_ch_count;
       public float logiana_sampling_rate;
       public int logiana_start_point;
       public int logiana_end_point;
       public int logiana_trigger_point;
       public int logiana_cell_size;
       public int[] logiana_sampling_ch_list;
       public short[] oscillo_data;
       public int oscillo_sampling_count;
       public int oscillo_sampling_ch_count;
       public float oscillo_sampling_rate;
       public int oscillo_start_point;
       public int oscillo_end_point;
       public int oscillo_trigger_point;
       public int oscillo_cell_size;
       public int[] oscillo_sampling_ch_list;
//       public int[] oscillo_sampling_posi_list;
       public short ad_tmr_ps;
       public short ad_tmr_pr;
       public short dma_tmr_ps;
       public short dma_tmr_pr;
       public ArrayList<String> log_param_string;
       public int log_count;
       
    public Log_Data(){
        this.logiana_data = new short[LOGIANA_MAX_DATA_COUNT];
        this.logiana_sampling_ch_list = new int[LOGIANA_MAX_CH_COUNT];
        this.oscillo_data = new short[OSCILLO_MAX_DATA_COUNT];
        this.oscillo_sampling_ch_list = new int[OSCILLO_MAX_CH_COUNT];
//        this.oscillo_sampling_posi_list = new int[OSCILLO_MAX_CH_COUNT];
        log_param_string = new ArrayList<String>();
    }

    public void initialize(){
        log_count = 0;
        double def_angle = Math.PI/256;
        double offset_angle = Math.PI/OSCILLO_MAX_CH_COUNT;
        
        oscillo_sampling_ch_count = 4;
        logiana_sampling_ch_count = 10;
        logiana_sampling_count = LOGIANA_MAX_DATA_COUNT;
        oscillo_sampling_count = OSCILLO_MAX_DATA_COUNT/oscillo_sampling_ch_count;
        oscillo_sampling_rate = OSCILLO_MAX_SAMPLING_RATE/oscillo_sampling_ch_count;
        logiana_sampling_rate = oscillo_sampling_rate;

// start_point <= trigger_point <= end_point        
        oscillo_start_point = 800;
        oscillo_end_point = 792;
        oscillo_trigger_point = 816;
        oscillo_cell_size = 8;
        logiana_start_point = 0;
        logiana_end_point = 8190;
        logiana_trigger_point = 4;
        logiana_cell_size = 2;
        
        for( int i=0;i<OSCILLO_MAX_CH_COUNT;i++)
        {
            oscillo_sampling_ch_list[i] = i;
//            oscillo_sampling_posi_list[i] = i;
        }
        for( int i=0;i<LOGIANA_MAX_CH_COUNT;i++)
        {
            logiana_sampling_ch_list[i] = i;
        }
        
        for( int i=0;i<LOGIANA_MAX_DATA_COUNT;i++)
        {
          logiana_data[i] = (short)i;
        }
        
        for( int i=0;i<OSCILLO_MAX_DATA_COUNT;i+=OSCILLO_MAX_CH_COUNT)
        {
          for( int j=0;j<OSCILLO_MAX_CH_COUNT;j++)
          {
             oscillo_data[i+j] = (short)(Math.sin( i*def_angle + offset_angle*j)*400+512);
          }
        }
        log_out_new();
    }
    
    public void log_out_common(String s)
    {
       int block_size;
       FileOperation log = new FileOperation(s);
       log.comment("LOG PARAMETER");
       for (String param_string : log_param_string) {
             log.comment(param_string);
       }

//        for (int i=0;i<log_param_string.size();i++) {
//            log.comment( log_param_string.get(i) );
//        }
        log.separator();
       
       if( oscillo_sampling_ch_count <= 2 )
       {
           block_size = oscillo_sampling_ch_count;
       }
       else
       {
           block_size = 4;
       }
       
       for( int i=0;i<OSCILLO_MAX_CH_COUNT;i++)
        {
        int ch_num;
        int ch_posi;
            ch_posi = oscillo_sampling_ch_list[i];
            ch_num = i;
//           if(ch_num >= 0 )
           if(ch_posi >= 0 )
           {
             log.comment("CH"+ Integer.toString(ch_num));
             for( int j=ch_posi;j<OSCILLO_MAX_DATA_COUNT;j+=block_size)
             {
               log.append( oscillo_data[j] );
             }
             log.separator();
           }
         }
        log.comment("LOGIANA");
        for( int i=0;i<LOGIANA_MAX_DATA_COUNT;i++)
        {
           log.append(logiana_data[i]);
        }
        log.close();
    }

    private String fn; 
    private int file_count;
    public void log_out_new()
    {
       fn = "/opt/samba/log_data"; 
       file_count = 0;
       log_out_common(fn);
    }
    
    public void log_out_next()
    {
       file_count++;
       log_out_common(fn+"_"+Integer.toString(file_count));
    }

    public void set_up()
    {
        oscillo_sampling_rate = 12000*1000;
        oscillo_sampling_rate /= ad_tmr_ps;
        oscillo_sampling_rate /= ad_tmr_pr;
//        Debug.print("oscillo_sampling_rate=",oscillo_sampling_rate,"\n");
        
        logiana_sampling_rate = 12000*1000;
        logiana_sampling_rate /= dma_tmr_ps;
        logiana_sampling_rate /= dma_tmr_pr;
//        Debug.print("logiana_sampling_rate=",logiana_sampling_rate,"\n");
    }
    
//        public static byte[] oscillo_buff = new byte[OSCILLO_BUFF_SIZE];

    public void debug_dump( byte[] buff )
    {
       FileOperation log = new FileOperation("/opt/samba/dump_data");
       for( int i=0;i<Osci_logi.OSCILLO_BUFF_SIZE;i++)
       {
           log.append( buff[i] );
       }
       log.close();
    }
    
    public int ch_to_bitposi(int ch)
    {
    int posi;
      switch(ch)
      {
        case 0:posi=8;break;
        case 1:posi=9;break;
        case 2:posi=10;break;
        case 3:posi=11;break;
        case 4:posi=13;break;
        case 5:posi=14;break;
        case 6:posi=15;break;
        case 7:posi=5;break;
        case 8:posi=4;break;
        case 9:posi=7;break;
        case 10:posi=0;break;
        case 11:posi=0;break;
        case 12:posi=0;break;
        case 13:posi=0;break;
        case 14:posi=0;break;
//        case 15:posi=8;break;
        default:posi=0;break;
      }
    return posi;
    }
        
    public int bit_to_chposi(int bit)
    {
    int posi;
      switch(bit)
      {
//        case 0:posi=8;break;
//        case 1:posi=9;break;
//        case 2:posi=10;break;
//        case 3:posi=11;break;
//        case 4:posi=13;break;
//        case 5:posi=14;break;
//        case 6:posi=15;break;
//        case 7:posi=5;break;
//        case 8:posi=4;break;
//        case 9:posi=7;break;
//        case 10:posi=0;break;
//        case 11:posi=0;break;
//        case 12:posi=0;break;
//        case 13:posi=0;break;
//        case 14:posi=0;break;
////        case 15:posi=8;break;
//        default:posi=0;break;

        case 0:posi=-1;break;
        case 1:posi=-1;break;
        case 2:posi=-1;break;
        case 3:posi=-1;break;
        case 4:posi=8;break;
        case 5:posi=7;break;
        case 6:posi=-1;break;
        case 7:posi=9;break;
        case 8:posi=0;break;
        case 9:posi=1;break;
        case 10:posi=2;break;
        case 11:posi=3;break;
        case 12:posi=-1;break;
        case 13:posi=4;break;
        case 14:posi=5;break;
//        case 15:posi=6;break;
        default:posi=6;break;
      }
    return posi;
    }        

    public void close()
    {
        try {
            this.finalize();
        } catch (Throwable ex) {
            Logger.getLogger(Log_Data.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
  @Override
  protected void finalize() throws Throwable {
    try {
      super.finalize();
    } finally {
    }
  }

  @Override
  public Log_Data clone() {
      Log_Data c=null;
    try {
      c = (Log_Data)super.clone();
      c.logiana_data = logiana_data.clone();
      c.logiana_sampling_ch_list = logiana_sampling_ch_list.clone();
      c.oscillo_data = oscillo_data.clone();
      c.oscillo_sampling_ch_list = oscillo_sampling_ch_list.clone();
      c.log_param_string = (ArrayList<String>)log_param_string.clone();
    } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Log_Data.class.getName()).log(Level.SEVERE, null, ex);
    }
    return c;
  }
}
