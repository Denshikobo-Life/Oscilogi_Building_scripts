/*
 * Copyright (c) 2012, Oracle and/or its affiliates. All rights reserved.
 */
package osci_logi_console;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
*/
public class Preference implements Serializable {

//  public ArrayList<String> send_text;
  
  public String log_dir;
  public String prefered_dir;
  public Boolean[] oscillo_sampling_ch = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
  public Integer oscillo_sampling_rate;
  public Integer oscillo_sampling_unit;
//  public Integer[] oscillo_trig_max = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Integer[] oscillo_trig_min = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
  public Boolean[] oscillo_trig_ch = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
  public Integer[] oscillo_trig_up_down_off = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
  public Integer[] oscillo_trig_level = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
  public Integer oscillo_trig_cond;
  public Integer oscillo_trigger_mode;

  public Boolean[] logiana_sampling_ch = new Boolean[Log_Data.LOGIANA_MAX_CH_COUNT];
  public Integer logiana_sampling_rate;
  public Integer logiana_sampling_unit;
  public Integer logiana_trig_mode;
  public Integer logiana_trig_bit_pattern;
  public Integer logiana_trig_bit_mask;
  public Integer logiana_trigger_mode;
  
  public Integer trigger_link;
  
//  public Integer lsbt;
//  public Integer lcbt;
//  public Integer lcmk;
//  public Integer lptn;
//  public Integer lpmk;
    
  public Preference() {
    log_dir = "log_dir";
    prefered_dir = System.getProperty("user.dir") + File.separator;
//  public Integer[] oscillo_sampling_ch = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Integer[] oscillo_trig_max = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Integer[] oscillo_trig_min = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Boolean[] oscillo_trig_on = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Boolean[] oscillo_trig_in = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
    for( int i=0;i<Log_Data.OSCILLO_MAX_CH_COUNT;i++)
    {
      oscillo_sampling_ch[i] = true;  
      oscillo_trig_level[i] = 512;
//      oscillo_trig_min[i] = 0;
      oscillo_trig_ch[i] = false;
      oscillo_trig_up_down_off[i] = Osci_logi.SELECT_OFF;
    }
//  public Integer oscillo_sampling_rate;
//  public Integer oscillo_sampling_unit;
//  public Integer oscillo_trig_and_or;
    oscillo_sampling_rate = 100;
    oscillo_sampling_unit = Osci_logi.UNIT_kHZ;
    oscillo_trig_cond = Osci_logi.TRIG_AND;
    
//  public Integer[] logiana_sampling_ch = new Integer[Log_Data.LOGIANA_MAX_CH_COUNT];
    for( int i=0;i<Log_Data.LOGIANA_MAX_CH_COUNT;i++)
    {
      logiana_sampling_ch[i] = true;
    }
    
//  public Integer logiana_sampling_rate;
//  public Integer logiana_sampling_unit;
    logiana_sampling_rate = 100;
    logiana_sampling_unit = Osci_logi.UNIT_kHZ;
    
//  public Integer logiana_trig_mode;
//  public Integer logiana_trig_bit_pattern;
//  public Integer logiana_trig_bit_mask;
    logiana_trig_mode = Osci_logi.TRIG_OFF;
    logiana_trig_bit_pattern = 0;
    logiana_trig_bit_mask = 0;
    
//  public Integer trigger_mode;
//  public Integer trigger_link;
    oscillo_trigger_mode = Osci_logi.START_TRIG;
    logiana_trigger_mode = Osci_logi.START_TRIG;
    trigger_link = Osci_logi.TRIG_OFF;
    
//    lsbt = 0b1111111111;
//    lcbt = 0;
//    lcmk = 0;
//    lptn = 0;
//    lpmk = 0;
    
  }

  String get_log_dir(){
      return log_dir;
  }
  
  public String get_prefered_dir(){
      return prefered_dir;
  }

  public void update_prefered_dir( String new_dir){
      prefered_dir = new_dir;
  }
  
  public void set_oscillo_ch(int ch, boolean flag){
    oscillo_sampling_ch[ch] = flag;
  }
  
  public boolean get_oscillo_ch(int ch){
    return oscillo_sampling_ch[ch];
  }

  public void set_logiana_ch(int ch, boolean flag){
      logiana_sampling_ch[ch] = flag; 
  }
  
  public boolean get_logiana_ch(int ch){
      return logiana_sampling_ch[ch];
  }
  
}
