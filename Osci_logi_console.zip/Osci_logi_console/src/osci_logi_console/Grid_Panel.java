/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package osci_logi_console;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author akira
 */
public class Grid_Panel extends JPanel {
 //=============================================================================
 //フィールド
 //=============================================================================

 //キャンバスの寸法
 Dimension dimension;
 boolean panel_type;
 int logiana_ch;
 int oscillo_ch;
 Window parent;
 
// private static final int LOGIANA_MERGIN = 30;
 
  //グラフ化するデータ 

 //=============================================================================
 //コンストラクタ
 //=============================================================================
 Grid_Panel(Window window)
 {
   super();
   parent = window;
   
   this.setOpaque(false);
   panel_type = Window.LOGIANA_TYPE;
   logiana_ch = 0;
   oscillo_ch = 0;
 }

  public void clear_grid()
 {
   this.removeAll();
 }

  private int v_pitch;
  private int h_pitch;
  private int c_posi;
  private int height;
  private int top;
  private int sub_window_size;

 public void set_grid_parameter( boolean t, int logi, int osci, int sub)
 {
   panel_type = t;
   logiana_ch = logi;
   oscillo_ch = osci;   
   sub_window_size = sub;
 }
  
  private void oscillo_grid_common(Graphics g)
  {
      BasicStroke wideStroke = new BasicStroke(4.0f);
      BasicStroke normalStroke = new BasicStroke(1.0f);
        h_pitch = (dimension.width - 1) / 18;
        v_pitch = h_pitch;
        
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.GRAY);
        
        //x軸
        c_posi = top+height/2;
        g2d.setStroke(wideStroke);
        g2d.drawLine(0, c_posi, dimension.width - 1, c_posi);
        
        g2d.setStroke(normalStroke);
        for(int offset = v_pitch ; c_posi - offset > top; offset+=v_pitch )
        {
          g2d.drawLine( 0, c_posi-offset, dimension.width - 1, c_posi-offset);
          g2d.drawLine( 0, c_posi+offset, dimension.width - 1, c_posi+offset);
        }

        //y軸
        c_posi = dimension.width/2;
        g2d.setStroke(wideStroke);
        g2d.drawLine( c_posi, top, c_posi, top+height);

        g2d.setStroke(normalStroke);
        for(int offset = h_pitch ; c_posi - offset > 0; offset+= h_pitch )
        {
          g2d.drawLine( c_posi-offset, top, c_posi-offset, top+height);
          g2d.drawLine( c_posi+offset, top, c_posi+offset, top+height);
        }
  }
          
  private void draw_oscillo_grid(Graphics g) {

        if( panel_type == Window.OSCILLO_TYPE )
        {
            height = dimension.height - sub_window_size;
            top = 0;
            oscillo_grid_common( g );
        }
        else if( oscillo_ch != 0 )
        {
            height = sub_window_size;
            top = dimension.height - height;
            oscillo_grid_common( g );
        }
    }

    private void draw_logiana_glid(Graphics g) {
        int v_posi;
//        int v_pitch;
//        int height;
//        int top;
        
        if( logiana_ch == 0 )return;
        
        if( panel_type == Window.LOGIANA_TYPE )
        {
            height = dimension.height - sub_window_size;
            top = 0;
            v_pitch = height/logiana_ch;
        }
        else
        {
            height = sub_window_size;
            top = dimension.height - height;
            v_pitch = height/logiana_ch;
        }
        
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.GRAY);
        v_posi = top + height-5;
        for(int count = 0 ; count < logiana_ch ; count++ )
        {
          g2d.drawLine( 0, v_posi, dimension.width - 1, v_posi);
          v_posi -= v_pitch;
        }
    }
  
 //=============================================================================
 //paint()メソッド
 //=============================================================================
static final int X_SCALE = 10;
static final int CH0_SCALE = 1;
static final int CH1_SCALE = 1;

    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        //領域のサイズ取得
        dimension = getSize();
        
        draw_logiana_glid( g );
        draw_oscillo_grid( g );
        
    }
}
