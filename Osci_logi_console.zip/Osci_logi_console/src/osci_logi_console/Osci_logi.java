package osci_logi_console;

import dkl.bcm2835;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class Osci_logi {

   private static String header = "*    OSCILOGI410 v0.12  2015/12/21  *\n";

    public static final int UPDATE_INTERVAL = 50;     // 50ms
    static final int BUFF_SIZE = 32;
    static final int OSCILLO_BUFF_SIZE = 16384;
    static final int LOGIANA_BUFF_SIZE = 8192;
    static final int PARAMETER_BUFF_SIZE = 256;
    static final int CH_SIZE = 8;
    static final int RECEIVE_DATA_SIZE = 20;
    static final byte TERMINATE_CODE = 22;
    static final int READ_STATUS_DELAY = 100;        // 100ms
    
    public static final int TRIG_OFF = 0;
    public static final int TRIG_ON = 1;
    public static final int TRIG_AND = 1;
    public static final int TRIG_OR = 2;
    public static final int PTRN_TRIG = 1;
    public static final int BCHGAND_TRIG = 2;
    public static final int BCHGOR_TRIG = 3;
    public static final int TRIG_HI = 2;
    public static final int TRIG_LOW = 3;
    
    public static final int SELECT_UP = 1;
    public static final int SELECT_DOWN = 2;
    public static final int SELECT_OFF = 3;

    static final int OSCILLO_MAX_LEVEL = 1023;
    static final int OSCILLO_MIN_LEVEL = 0;

//    public static final int RANGE_IN = 1;
//    public static final int RANGE_OUT = 2;
    
    public static boolean IN_FLAG = true;
    public static boolean OUT_FLAG = false;
//    public static final int RANGE_OFF = 0;

    public static final int OFF_TRIG = 1;
    public static final int START_TRIG = 1;
    public static final int END_TRIG = 2;
    public static final int CENTER_TRIG = 3;
    
    static boolean brk_flag;
    static String send_string = "";
    static boolean send_flag = false;
    static boolean repeat_flag = false;
    static boolean log_flag = false;
    static boolean send_brk_flag = false;
    static boolean read_status_flag = false;
    static boolean send_status_command_flag = false;
    static boolean receive_flag = false;
    static boolean current_log_update = false;
    static boolean receive_oscillo_flag = false;
    static boolean receive_logiana_flag = false;
    static boolean receive_parameter_flag = false;
    public static Preference settings_prefer;
//    public static final int UNIT_mHZ = 1;
    public static final int UNIT_HZ = 1;
    public static final int UNIT_kHZ = 1000;
    public static Log_Data current_log;

    public static Main_Frame main_frame;

    static final byte PIN = bcm2835.RPI_GPIO_P1_11;
    
    public static final int LOG_OUT_EVENT = 0;
    public static final int OTHER_EVENT = 1;
    public static final int ANOTHER_EVENT = 2;
    public static final int MAX_EVENT = 10;
    private static Long[] event_array;
    private static Boolean[] event_flag;
   
    public static void set_timer_event(int delay,int event_id )
    {
       event_array[event_id] = current_time+delay;
       event_flag[event_id] = true;
    }

// Receive Format 
// 20 byte data 
//  1 byte check sum
//  1 byte terminate code = 22
    static boolean format_check(byte[] receive_buff) {
        byte c;
        int posi;
        c = 0;
        for (posi = 0; posi < RECEIVE_DATA_SIZE; posi++) {
            c += receive_buff[posi];
        }
        if (c != receive_buff[posi]) {
            System.out.print(" calc sum=" + Byte.toString(c) + " receive sum=" + Byte.toString(receive_buff[posi]) + "\n");
            return false;
        } else if (receive_buff[posi + 1] != TERMINATE_CODE) {
            System.out.print(" receive code=" + Byte.toString(receive_buff[posi + 1]) + "\n");
            return false;
        }
        return true;
    }

    static void show_receive_data(byte[] receive_buff) {
        byte c;
        int posi;
        byte sum;
        sum = 0;
        System.out.print(" receive data = ");
        for (posi = 0; posi < RECEIVE_DATA_SIZE; posi++) {
            c = receive_buff[posi];
            sum += c;
            System.out.print(Byte.toString(c) + " ");
        }
        c = receive_buff[posi++];
        System.out.print(Byte.toString(c) + " ");
        c = receive_buff[posi];
        System.out.print(Byte.toString(c) + " sum = ");

        System.out.print(Byte.toString(sum) + "\n");
    }

    private static int read_posi;

    private static byte read_byte_value() {
        return param_buff[read_posi++];
    }

    private static short read_short_value() {
        short buff1;
        short buff2;
        if( (read_posi & 0x01) != 0 ) read_posi++;
        
        buff1 = (short)(read_byte_value()&0xff);
        buff2 = (short)(read_byte_value()&0xff);
        buff2 <<= 8;
        buff2 += buff1;
        return buff2;
    }

    private static int read_int_value() {
        int buff1;
        int buff2;
        buff1 = (int)(read_short_value()&0xffff);
        buff2 = (int)(read_short_value()&0xffff);
        buff2 <<= 16;
        buff2 += buff1;
        return buff2;
    }

    private static byte Current_Sampling_Status;
    private static void Read_Sampling_Status_Bit()
    {
        Current_Sampling_Status = bcm2835.gpio_lev(PIN);
    }
    
    public static byte[] receive_buff = new byte[BUFF_SIZE];
    public static byte[] i2c_buff = new byte[1024];
    public static byte[] oscillo_buff = new byte[OSCILLO_BUFF_SIZE];
    public static byte[] logiana_buff = new byte[LOGIANA_BUFF_SIZE];
    public static byte[] param_buff = new byte[PARAMETER_BUFF_SIZE];
    public static ArrayList<String> send_text;
    
    private String creat_command_string(String s, String v)
    {
        String base = "SET ";
        base += s;
        base += ":";
        base += v;
        return base;
    }

    private String creat_command_num(String s, Integer n)
    {
        String base = "SET ";
        base += s;
        base += ":";
        base += n.toString();
        return base;
    }
    
    private String creat_command_bit(String s, int n)
    {
        String z = "0000000000000000";
        String base = "SET ";
        base += s;
        base += ":";
        z += Integer.toBinaryString(n);
        base = z.substring( z.length() - 16 );
        return base;
    }
    
    private static String set_logiana_bit_string( int bit_pattern )
    {
        String bit_string = "";
        int pic_pattern;
        
        pic_pattern = 0;
        for( int posi=0;posi<16;posi++)
        {
            if( ( bit_pattern & (1<<posi ) ) != 0  )
            {
              pic_pattern |= (1<<current_log.ch_to_bitposi(posi));
            }
        }
        
//         for(int i=0; i<Log_Data.LOGIANA_MAX_CH_COUNT; i++)
         for(int i=0; i<16; i++)
         {
             if( ( pic_pattern & (1<<i ) ) == 0  )
             {
               bit_string += "0";
             }
             else
             {
               bit_string += "1";
             }
         }
        return bit_string;
    }
    
    private static void set_send_text()
    {
      String command;
      String num;
      int count;
      int pattern;
      send_text.clear();
//　　計測CH: "SET OSCH:0000000000001111"
       command = "SET OSCH:";
       count = 0;
       for(int i=0;i<Log_Data.OSCILLO_MAX_CH_COUNT;i++ )
       {
           if(Osci_logi.settings_prefer.oscillo_sampling_ch[i])
           {
               command += "1";
               count++;
           }
           else
           {
               command += "0";
           }
       }
      send_text.add(command);
//　　計測サンプル数: "SET OSCT:2048"   （4096/8192）
      if( count == 1 )
      {
         send_text.add("SET OSCT:8192");
      }
      else if( count == 2 )
      {
         send_text.add("SET OSCT:4096");
      }
      else
      {
         send_text.add("SET OSCT:2048");
      }
      
//  public Integer oscillo_sampling_rate;
//　　計測レート:"SET OSRT:200"          (1..500)
         send_text.add("SET OSRT:"+Osci_logi.settings_prefer.oscillo_sampling_rate.toString());
      
//  public Integer oscillo_sampling_unit;
//              :"SET OSUT:kHz"          (Hz)
         if( Osci_logi.settings_prefer.oscillo_sampling_unit == Osci_logi.UNIT_HZ )
         {
           send_text.add("SET OSUT:Hz");
         }
         else
         {
           send_text.add("SET OSUT:kHz");
         }
      
//  public Integer[] oscillo_trig_max = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Integer[] oscillo_trig_min = new Integer[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Boolean[] oscillo_trig_ch = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
//  public Boolean[] oscillo_trig_in_out = new Boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
//　　トリガ条件
//　　　レンジ（chごと）
//        LEVEL："SET O0LV:num"     (0..1023)
//　　　　OVER："SET O0RG:UP"
//        UNDER："SET O0RG:DOWN"
//        OFF："SET O0RG:OFF"
       command = "SET O";
       
       for(int i=0; i<Log_Data.OSCILLO_MAX_CH_COUNT;i++ )
       {
           num = Integer.toString(i);
           send_text.add( command+num+"LV:"+Osci_logi.settings_prefer.oscillo_trig_level[i].toString());
           if( Osci_logi.settings_prefer.oscillo_trig_ch[i] )
           {
             if( Osci_logi.settings_prefer.oscillo_trig_up_down_off[i] == Osci_logi.SELECT_UP )
             {
               send_text.add(command+num+"RG:UP");
             }
             else if( Osci_logi.settings_prefer.oscillo_trig_up_down_off[i] == Osci_logi.SELECT_DOWN )
             {
               send_text.add(command+num+"RG:DOWN");
             }
             else
             {
               send_text.add(command+num+"RG:OFF");
             }
           }
           else
           {
             send_text.add(command+num+"RG:OFF");
           }
       }
       
//  public Integer oscillo_trigger_mode;
//　　　モード
//　　　　スタート・トリガ："SET OTMD:STRT"
//　　　　センター・トリガ:"SET OTMD:CNTT"
//　　　　エンド・トリガ:"SET OTMD:ENDT"
         if( Osci_logi.settings_prefer.oscillo_trigger_mode == Osci_logi.START_TRIG )
         {
           send_text.add( "SET OTMD:STRT" );
         }
         else if( Osci_logi.settings_prefer.oscillo_trigger_mode == Osci_logi.CENTER_TRIG )
         {
           send_text.add( "SET OTMD:CNTT" );
         }
         else
         {
           send_text.add( "SET OTMD:ENDT" );
         }

         
//  public Integer oscillo_trig_and_or;
//      CH間リンク
//　　　　AND："SET OLNK:AND"
//        OR："SET OLNK:OR"
       if( settings_prefer.oscillo_trig_cond == Osci_logi.TRIG_AND )
       {
           send_text.add("SET OLNK:AND");
       }
       else if( settings_prefer.oscillo_trig_cond == TRIG_OR )
       {
           send_text.add("SET OLNK:OR");
       }
       else
       {
           send_text.add("SET OLNK:OFF");
       }
       
//  public Boolean[] logiana_sampling_ch = new Boolean[Log_Data.LOGIANA_MAX_CH_COUNT];
//　　計測CH: "SET LSCH:1111111111"
       count = 0;
       pattern = 0;
       for(int i=0; i<Log_Data.LOGIANA_MAX_CH_COUNT;i++ )
       {
         if( settings_prefer.logiana_sampling_ch[i] )
         {
             pattern |= (1<<i);
         }
//         if( Osci_logi.settings_prefer.logiana_sampling_ch[i] )
//           {
//               command += "1";
//           }
//           else
//           {
//               command += "0";
//           }
       }
       command = "SET LSCH:"+set_logiana_bit_string( pattern );
       
      send_text.add(command);
//　　計測サンプル数: "SET LSCT:4096"
      send_text.add("SET LSCT:4096");
      
//  public Integer logiana_sampling_rate;
//  public Integer logiana_sampling_unit;
//　　計測レート："SET LSRT:2000"
//　　　　　　　："SET LSUT:kHz"
         send_text.add("SET LSRT:"+Osci_logi.settings_prefer.logiana_sampling_rate.toString());
         if( Osci_logi.settings_prefer.logiana_sampling_unit == Osci_logi.UNIT_HZ )
         {
           send_text.add("SET LSUT:Hz");
         }
         else
         {
           send_text.add("SET LSUT:kHz");
         }
      
//  public Integer logiana_trig_mode;
//  public Integer logiana_trig_bit_pattern;
//  public Integer logiana_trig_bit_mask;
//　　トリガ条件
//　　　パターン："SET TLGI:PTRN"
//　　　　　　　："SET LPTN:1000000000"
//　　　　　　　："SET LMSK:1111000000");
//
//　　　ビット・チェンジ："SET TLGI:BCHG"
         if( Osci_logi.settings_prefer.logiana_trig_mode == Osci_logi.PTRN_TRIG )
         {
           send_text.add("SET TLGI:PTRN");
           command = "SET LPTN:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_pattern );
           send_text.add( command );
           command = "SET LPMK:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_mask );
//           for(int i=15; i>=0; i--)
//           {
//             int j;
//             j = pic_to_console_posi(i);
//             if( ( Osci_logi.settings_prefer.logiana_trig_bit_mask & (1<<j ) ) == 0  )
//             {
//               command += "0";
//             }
//             else
//             {
//               command += "1";
//             }
//           }
           send_text.add( command );
         }
         else if( Osci_logi.settings_prefer.logiana_trig_mode == Osci_logi.BCHGAND_TRIG )
         {
           send_text.add("SET TLGI:BCHGA");
           command = "SET LBCG:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_pattern );
           send_text.add( command );
           command = "SET LPMK:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_mask );
           send_text.add( command );
         }
         else if( Osci_logi.settings_prefer.logiana_trig_mode == Osci_logi.BCHGOR_TRIG )
         {
           send_text.add("SET TLGI:BCHGO");
           command = "SET LBCG:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_pattern );
           send_text.add( command );
           command = "SET LPMK:"+set_logiana_bit_string( Osci_logi.settings_prefer.logiana_trig_bit_mask );
           send_text.add( command );
         }
         else
         {
           send_text.add("SET TLGI:OFF");
         }

//  public Integer oscillo_trigger_mode;
//　　　モード
//　　　　スタート・トリガ："SET OTMD:STRT"
//　　　　センター・トリガ:"SET OTMD:CNTT"
//　　　　エンド・トリガ:"SET OTMD:ENDT"
         if( Osci_logi.settings_prefer.logiana_trigger_mode == Osci_logi.START_TRIG )
         {
           send_text.add( "SET LTMD:STRT" );
         }
         else if( Osci_logi.settings_prefer.logiana_trigger_mode == Osci_logi.CENTER_TRIG )
         {
           send_text.add( "SET LTMD:CNTT" );
         }
         else
         {
           send_text.add( "SET LTMD:ENDT" );
         }

//  public Integer trigger_link;
//　　　トリガ・リンク
//        AND："SET TLNK:AND"
//        OR："SET TLNK:OR"
//        OFF："SET TLNK:OFF"
         if( Osci_logi.settings_prefer.trigger_link == Osci_logi.TRIG_AND )
         {
           send_text.add( "SET TLNK:AND" );
         }
         else if( Osci_logi.settings_prefer.trigger_link == Osci_logi.TRIG_OR )
         {
           send_text.add( "SET TLNK:OR" );
         }
         else
         {
           send_text.add( "SET TLNK:OFF" );
         }
    }
    
    private static long current_time;
    public static void main(String[] args) {

        long prev_time;
        long update_time;
        long half_sec_interval;
        long read_status_time;
        
        String log_string;
        
        current_log = new Log_Data();

        byte ret = 0;
        int error_count;
        boolean busy_flag = false;
        boolean meas_flag = false;
        boolean send_fail_flag = false;
        send_text = new ArrayList<>();

        event_array = new Long[MAX_EVENT];
        event_flag = new Boolean[MAX_EVENT];
        for(int i=0;i<MAX_EVENT;i++)
        {
          event_flag[i] = false;
        }
        
        try (FileInputStream inFile = new FileInputStream("preference.obj"); ObjectInputStream inObject = new ObjectInputStream(inFile)) {
            settings_prefer = (Preference) inObject.readObject();
        } catch (IOException | ClassNotFoundException e) {
            settings_prefer = new Preference();
        }

//        fope = new FileOperation();
        current_log.initialize();
        
        System.out.print("*************************************\n");
        System.out.print( header );
        System.out.print("*************************************\n");

//        new Exception("Stack trace").printStackTrace();
        
//        Main_Frame main_frame = new Main_Frame();
        main_frame = new Main_Frame();
        
        bcm2835.bi_init(args[0]);
        bcm2835.i2c_begin();
        bcm2835.i2c_setSlaveAddress((byte) 0x31);
        bcm2835.i2c_set_baudrate(100000);
        
        main_frame.Open();
        
        // sampling_status_bit
        bcm2835.gpio_fsel(PIN, bcm2835.BCM2835_GPIO_FSEL_INPT);
//        Read_Sampling_Status_Bit();
        current_time = System.currentTimeMillis();
        half_sec_interval = current_time + 500;
        prev_time = current_time;
        read_status_time = current_time;
        update_time = prev_time + UPDATE_INTERVAL;
        error_count = 0;

        brk_flag = false;
        while (!brk_flag) {
            current_time = System.currentTimeMillis();
            if (send_flag) {
                set_send_text();
                for (String str : send_text) {
                    ret = bcm2835.i2c_write(str + '\0', str.length() + 1);
                    System.out.print(str);
                    System.out.print(" " + (int) ret + "\n");
                    bcm2835.ope_sync();
                }
                send_flag = false;
                log_flag = true;
            } else if (log_flag) {
                ret = bcm2835.i2c_write("LOG" + '\0', 4);
                System.out.print("LOG " + (int) ret + "\n");
                bcm2835.ope_sync();
                log_flag = false;
                meas_flag = true;
                busy_flag = true;
                main_frame.Reset_Canvas();
                current_time = System.currentTimeMillis();
                read_status_time = current_time + 10;
                current_log_update = false;
            }
            else if (send_brk_flag) 
            {
                if( send_fail_flag == false)
                {
                  ret = bcm2835.i2c_write("BRK" + '\0', 4);
                  System.out.print("BRK=");
                  System.out.print(ret);
                  System.out.print("\n");
                  bcm2835.ope_sync();
                  if( ret == 0 )
                  {
                    send_brk_flag = false;
                    busy_flag = false;
                    meas_flag = false;
                  }
                  else
                  {
                      send_fail_flag = true;
                  }
                }
            }
            
            if ( busy_flag ) 
            {
              if( read_status_time <= current_time )
              {
                read_status_time = current_time + 50;
                Read_Sampling_Status_Bit();
                busy_flag = ( Current_Sampling_Status == 1);
//                System.out.print("READ STATUS TIME="+current_time+"\n");
//                System.out.print("     STATUS     ="+busy_flag+"\n");
              }
            }

            if (current_time >= half_sec_interval) 
            {
                half_sec_interval = current_time + 500;
                
                if (busy_flag) {
                    main_frame.keisoku_flicker();
                } else {
                    main_frame.keisoku_off();
                }
                send_fail_flag = false;
            }
            
            if (current_time >= update_time) {
                update_time = current_time + UPDATE_INTERVAL;

                if ((meas_flag) && (!busy_flag)) {
                    receive_flag = true;
                    receive_oscillo_flag = true;
                    receive_logiana_flag = true;
                    receive_parameter_flag = true;
                    meas_flag = false;
                }
            }

            if (receive_flag) {
                int i, j;
                int count;
                int ch_posi;
                int bit_posi;
                int temp_ch_buff;
                
                if (receive_parameter_flag) {
                    int b;
                    byte check_byte;
                    
                    ret = bcm2835.i2c_write("RCV 2" + '\0', 6);
                    bcm2835.ope_sync();
                    if (ret == 0) {
                        ret = bcm2835.i2c_read(i2c_buff, PARAMETER_BUFF_SIZE);
                        if (ret == 0) {
                            System.arraycopy(i2c_buff, 0, param_buff, 0, PARAMETER_BUFF_SIZE);
                            read_posi = 0;
                            check_byte = 0;
                            for(int t=0;t<PARAMETER_BUFF_SIZE;t++ )
                            {
                                if( ( read_posi%16 ) == 0 )
                                {
                                  System.out.print( "\n" );
                                }
                                else if( ( read_posi%8 ) == 0 )
                                {
                                  System.out.print( " " );
                                }
                                b =  read_byte_value() & 0x0ff;
                                check_byte |= b;
                                System.out.printf("%02x", b );
                                System.out.print( " " );
                            }
                            System.out.print( "\n" );
                            
                            current_log.log_param_string.clear();
                            
                            read_posi = 0;
                            current_log.ad_tmr_ps = read_short_value();
                            current_log.ad_tmr_pr = read_short_value();
                            current_log.dma_tmr_ps = read_short_value();
                            current_log.dma_tmr_pr = read_short_value();

                            current_log.log_param_string.add( Debug.string("ad_tmr_ps=",current_log.ad_tmr_ps,"") );
                            current_log.log_param_string.add(Debug.string("ad_tmr_pr=",current_log.ad_tmr_pr,"") );
                            current_log.log_param_string.add(Debug.string("dma_tmr_ps=",current_log.dma_tmr_ps,"") );
                            current_log.log_param_string.add(Debug.string("dma_tmr_pr=",current_log.dma_tmr_pr,"") );
                            
                            current_log.logiana_start_point = read_short_value();
                            current_log.logiana_trigger_point = read_short_value();
                            current_log.logiana_end_point = read_short_value();
                            current_log.logiana_cell_size = read_short_value();
                            
                            current_log.log_param_string.add( Debug.string("ch0_start_point=",current_log.logiana_start_point,"") );
                            current_log.log_param_string.add( Debug.string("ch0_trig_point=",current_log.logiana_trigger_point,"") );
                            current_log.log_param_string.add( Debug.string("ch0_end_point=",current_log.logiana_end_point,"") );
                            current_log.log_param_string.add( Debug.string("ch0_cell_size=",current_log.logiana_cell_size,"") );

                            current_log.oscillo_start_point = read_short_value();
                            current_log.oscillo_trigger_point = read_short_value();
                            current_log.oscillo_end_point = read_short_value();
                            current_log.oscillo_cell_size = read_short_value();
                            current_log.log_param_string.add( Debug.string("ch1_start_point=",current_log.oscillo_start_point,"") );
                            current_log.log_param_string.add( Debug.string("ch1_trig_point=",current_log.oscillo_trigger_point,"") );
                            current_log.log_param_string.add( Debug.string("ch1_end_point=",current_log.oscillo_end_point,"") );
                            current_log.log_param_string.add( Debug.string("ch1_cell_size=",current_log.oscillo_cell_size,"") );

                            current_log.log_param_string.add( "--------------------------" );
                            current_log.oscillo_sampling_count = read_short_value();

                            current_log.log_param_string.add( Debug.string("oscillo sampling_count=",current_log.oscillo_sampling_count,"") );

                            current_log.log_param_string.add( "oscillo limit_level="
                                    + String.valueOf(read_short_value())+" "
                                    + String.valueOf(read_short_value())+" "
                                    + String.valueOf(read_short_value())+" "
                                    + String.valueOf(read_short_value()) );

                            current_log.log_param_string.add( Debug.string("oscillo sampling_rate=",read_short_value(),"") );

                            current_log.oscillo_sampling_ch_count = read_short_value();
                            current_log.log_param_string.add( Debug.string("oscillo sampling_ch_count=",current_log.oscillo_sampling_ch_count,"") );

                            current_log.log_param_string.add( Debug.string("oscillo sampling_unit=",read_byte_value(),"") );

                            log_string = "oscillo sampling_ch=";

                            ch_posi = 0;
                            for( i=0;i<Log_Data.OSCILLO_MAX_CH_COUNT;i++)
                            {
                                if( read_byte_value() == 0 )
                                {
                                  current_log.oscillo_sampling_ch_list[i] = -1;
                                }
                                else
                                {
                                  current_log.oscillo_sampling_ch_list[i] = ch_posi;
                                  ch_posi++;
                                }

                                log_string += " "+Integer.toString(current_log.oscillo_sampling_ch_list[i]);
                            }
                            current_log.log_param_string.add( log_string );

                            log_string = "oscillo trig_cond=";
                            for( i=0;i<Log_Data.OSCILLO_MAX_CH_COUNT;i++)
                            {
                                log_string += " "+ Integer.toHexString(read_byte_value());
                            }
                            current_log.log_param_string.add( log_string );
                            
                            current_log.log_param_string.add( Debug.string("oscillo trig_and_or=",Integer.toHexString(read_byte_value()),"") );
                            current_log.log_param_string.add( Debug.string("oscillo trig_mode=",Integer.toHexString(read_byte_value()),"") );
                            current_log.log_param_string.add( "--------------------------" );
                            
                            current_log.logiana_sampling_count = read_short_value();
                            current_log.log_param_string.add( Debug.string("logiana sampling_count=",current_log.logiana_sampling_count,"") );
                            current_log.log_param_string.add( Debug.string("logiana pattern=",read_short_value(),"") );
                            current_log.log_param_string.add( Debug.string("logiana mask=",read_short_value(),"") );
                            current_log.log_param_string.add( Debug.string("logiana sampling_rate=",read_short_value(),"") );
//                            System.out.print("logiana sampling_count=" + String.valueOf(current_log.logiana_sampling_count) + "\n");
//                            System.out.print("logiana pattern=" + String.valueOf(read_short_value()) + "\n");
//                            System.out.print("logiana mask=" + String.valueOf(read_short_value()) + "\n");
//                            System.out.print("logiana sampling_rate=" + String.valueOf(read_short_value()) + "\n");
                            current_log.logiana_sampling_ch_count = read_short_value();
                            current_log.log_param_string.add( Debug.string("logiana sampling_ch_count=",current_log.logiana_sampling_ch_count,"") );
//                            System.out.print("logiana sampling_ch_count=" + String.valueOf(current_log.oscillo_sampling_ch_count) + "\n");

                            current_log.log_param_string.add( Debug.string("logiana sampling_unit=",Integer.toHexString(read_byte_value()),"") );
//                            System.out.printf("logiana sampling_unit=%02x\n",read_byte_value() & 0xff);

                            ch_posi = 0;
                            for( i=0;i<16;i++)
                            {
                                temp_ch_buff = read_byte_value();
                                bit_posi = current_log.bit_to_chposi(i);
                                if( bit_posi != -1 )
                                {
                                  if( temp_ch_buff != 0 )
                                  {
                                    current_log.logiana_sampling_ch_list[bit_posi] = ch_posi;
                                    ch_posi++;
                                  }
                                  else
                                  {
                                    current_log.logiana_sampling_ch_list[bit_posi] = -1;
                                  }
                                }
                            }
                            
                            log_string = "logiana sampling_ch=";
                            for( i=0;i<Log_Data.LOGIANA_MAX_CH_COUNT;i++)
                            {
                                log_string += " "+ Integer.toString(current_log.logiana_sampling_ch_list[i]);
                            }
                            current_log.log_param_string.add( log_string );
//                            System.out.printf("logiana sampling_ch=");
//                            for( i=0;i<Log_Data.LOGIANA_MAX_CH_COUNT;i++)
//                            {
//                                System.out.print(current_log.logiana_sampling_ch_list[i]);
//                            }
//                            System.out.print("\n");
                            
                            current_log.log_param_string.add( Debug.string("logiana trig_mode=","0x"+Integer.toHexString(read_byte_value()),"") );
                            current_log.log_param_string.add( "--------------------------");
//                            System.out.printf("logiana trig_mode=%02x\n",read_byte_value() & 0xff);
//                            System.out.print("--------------------------\n");
                            current_log.log_param_string.add( Debug.string("oscillo delay_loop_count=",read_short_value(),"") );
                            current_log.log_param_string.add( Debug.string("logiana delay_loop_count=",read_short_value(),"") );
                            current_log.log_param_string.add( Debug.string("check_type=","0x"+Integer.toHexString(read_byte_value()),"") );
                            current_log.log_param_string.add( Debug.string("osci_logi_link=","0x"+Integer.toHexString(read_byte_value()),"") );
//                            System.out.print("oscillo delay_loop_count=" + String.valueOf(read_short_value()) + "\n");
//                            System.out.print("logiana delay_loop_count=" + String.valueOf(read_short_value()) + "\n");
//                            System.out.printf("check_type=%02x\n",read_byte_value() & 0xff);
//                            System.out.printf("osci_logi_link=%02x\n",read_byte_value() & 0xff);
//                            System.out.print("--------------------------\n");
//                            System.out.print("LOG PARAM LIST\n");
//                            for (String log_param_string : current_log.log_param_string) {
//                                System.out.print(log_param_string + "\n");
//                            }
                            if( check_byte != 0 )
                            {
                              receive_parameter_flag = false;
                            }
                        }
                    }
                } else if (receive_oscillo_flag) {
                    ret = bcm2835.i2c_write("RCV 1" + '\0', 6);
                    System.out.print("RCV 1 " + (int) ret + "\n");
                    bcm2835.ope_sync();
                    for (int offset = 0; offset < OSCILLO_BUFF_SIZE;) {
                        ret = bcm2835.i2c_read(i2c_buff, 1024);
                        if (ret != 0) {
                            break;
                        }
                        for (int o = 0; o < 1024; o++) {
                            oscillo_buff[offset++] = i2c_buff[o];
                        }
                        ret = bcm2835.i2c_write("RCV N" + '\0', 6);
                    }
                    
                    if (ret == 0) {
                        System.out.print("receive_data=oscillo data\n");
                        count = 0;
                        for (int offset = 0; offset < OSCILLO_BUFF_SIZE; offset += 2) {
                            i = (int) oscillo_buff[offset];
                            j = (int) oscillo_buff[offset + 1];
                            i &= 0x00ff;
                            j &= 0x00ff;
                            j *= 256;
                            j += i;
                            current_log.oscillo_data[count++] = (short)j;
                        }
                    } else {
                        System.out.print("i2c_read =" + (int) ret + "\n");
                    }
                    receive_oscillo_flag = false;
                } else if (receive_logiana_flag) {
                    ret = bcm2835.i2c_write("RCV 0" + '\0', 6);
                    System.out.print("RCV 0 " + (int) ret + "\n");
                    bcm2835.ope_sync();
                    for (int offset = 0; offset < LOGIANA_BUFF_SIZE;) {
                        ret = bcm2835.i2c_read(i2c_buff, 1024);
                        if (ret != 0) {
                            break;
                        }
                        for (int o = 0; o < 1024; o++) {
                            logiana_buff[offset++] = i2c_buff[o];
                        }
                        ret = bcm2835.i2c_write("RCV N" + '\0', 6);
                    }
                    if (ret == 0) {
                        count = 0;
                        for (int offset = 0; offset < LOGIANA_BUFF_SIZE; offset += 2) {
                            i = (int) logiana_buff[offset];
                            j = (int) logiana_buff[offset + 1];
                            i &= 0x00ff;
                            j &= 0x00ff;
                            j *= 256;
                            j += i;
                            current_log.logiana_data[count++] = (short) j;
                        }
                        current_log.logiana_sampling_count = count;
                        System.out.print("receive_data=logiana data\n");
                    } else {
                        System.out.print("i2c_read =" + (int) ret + "\n");
                    }
                    receive_logiana_flag = false;
                } else {
                    current_log_update = true;
                    current_log.log_count++;
                    Debug.print("receive_flag = false log_count=",current_log.log_count,"\n");
                    receive_flag = false;
                    Main_Frame.meas_on_flag = false;
                    bcm2835.i2c_write("STS" + '\0', 4);
                    bcm2835.ope_sync();
                }
            }
            
            if( main_frame.update_canvas )
            {
               main_frame.View_Canvas();
               main_frame.update_canvas = false;
            }
            
            for(int i=0; i<MAX_EVENT;i++ )
             {
                if( event_flag[i] )
                {
                    if( current_time >= event_array[i] )
                    {
                        switch(i)
                        {
                               case LOG_OUT_EVENT:
                                   main_frame.log_out_done();
                                   break;
                               case OTHER_EVENT:
                               case ANOTHER_EVENT:
                               default:
                                   break;
                        }
                        event_flag[i] = false;
                    }
               }
            }
        }
        System.out.print("error_count = " + Integer.toString(error_count) + "\n");
        main_frame.Close();
        bcm2835.i2c_end();
        bcm2835.bi_close();

        try (FileOutputStream outFile = new FileOutputStream("preference.obj"); ObjectOutputStream outObject = new ObjectOutputStream(outFile)) {
            outObject.writeObject(settings_prefer);
        } catch (IOException e) {
            System.out.println(e);
        }
        System.exit(0);
    }
}
