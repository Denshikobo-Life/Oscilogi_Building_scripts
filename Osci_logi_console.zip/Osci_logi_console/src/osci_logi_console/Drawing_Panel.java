/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package osci_logi_console;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author akira
 */
public class Drawing_Panel extends JPanel {
 //=============================================================================
 //フィールド
 //=============================================================================

 //キパネルの寸法
 Dimension dimension;
 boolean panel_type;
 int logiana_data_ch;
 int logiana_data_count;
 float logiana_data_rate;
 float logiana_interval;
 int logiana_draw_ch_cnt;
 int oscillo_data_ch;
 int oscillo_draw_ch_cnt;
 int oscillo_data_count;
 float oscillo_data_rate;
 float oscillo_interval;
 public float drawing_start_time;
 public float drawing_end_time;
 public float drawing_scale;
 public float drawing_interval;
 public float oscillo_start_time;
 public float oscillo_end_time;
 public float logiana_start_time;
 public float logiana_end_time;

// private int[] logiana_draw_ch;
// private int[] oscillo_draw_ch;
// private int v_pitch;
// private int h_pitch;
// private int c_posi;
 private int top;     // 描画範囲最上部
 private int drawing_height;  // 描画範囲高さ
 private int sub_window_height;
 private int display_start_position;
 private float display_start_time;
 private float display_end_time;
 private Window parent;
 
 //=============================================================================
 //コンストラクタ
 //=============================================================================
 Drawing_Panel(Window window)
 {
   super();   
   this.setOpaque(false);
   parent = window;
   
   panel_type = Window.LOGIANA_TYPE;
   logiana_data_ch = 0;
   logiana_draw_ch_cnt = 0;
   oscillo_draw_ch_cnt = 0;
   oscillo_data_ch = 0;
   display_start_position = 0;
 }
 
// public void clear()
// {
//   this.removeAll();
// }
 
 private float calc_sampling_time( float interval, int t_posi, int posi )
 {
 float t;
   t = posi - t_posi;
   t *= interval;
   return t;
 }

// int max_calc_posi;
// float max_time;
// int min_calc_posi;
// float min_time;
// 
// private void reset_calc_posi()
// {
//   max_calc_posi = 0;
//   min_calc_posi = 100000;
// }
 
 private int calc_sampling_posi( float interval, float sampling_time, int t_posi, int max )
 {
 int posi;
 
   posi = (int) (sampling_time / interval);
// Debug.print("interval=", interval," ");
// Debug.print("sampling_time=", sampling_time," ");
// Debug.print("t_posi=", t_posi,"\n");
   posi += t_posi;
   if( posi < 0 ) posi += max;
   while( posi >= max )posi -= max;
   return posi;
 }
 

// public void set_data_parameter( int logi_data, int osci_data )
// private Log_Data log_data;
 
// public void set_data_parameter(Log_Data window_log_data)
 public void set_data_parameter()
 {
   parent.log_data.set_up();
       logiana_data_ch = parent.log_data.logiana_sampling_ch_count;
       logiana_data_count = parent.log_data.logiana_sampling_count;
       logiana_data_rate  = parent.log_data.logiana_sampling_rate;
       logiana_interval = ((float)1.0/logiana_data_rate);
       oscillo_data_ch = parent.log_data.oscillo_sampling_ch_count;
       oscillo_data_count= parent.log_data.oscillo_sampling_count;
       oscillo_data_rate = parent.log_data.oscillo_sampling_rate;
       oscillo_interval = ((float)1.0/oscillo_data_rate);

       Debug.print("oscillo_data_ch=",oscillo_data_ch,"\n");
       Debug.print("parent.log_data=",parent.log_data,"\n");
   
       logiana_start_time = calc_sampling_time( logiana_interval,parent.logiana_trigger_point,parent.logiana_start_point);
       logiana_end_time = calc_sampling_time( logiana_interval,parent.logiana_trigger_point,parent.logiana_end_point);
       oscillo_start_time = calc_sampling_time( oscillo_interval,parent.oscillo_trigger_point,parent.oscillo_start_point);
       oscillo_end_time = calc_sampling_time( oscillo_interval,parent.oscillo_trigger_point,parent.oscillo_end_point);
  
Debug.print("logiana_start_time=",logiana_start_time," ");
Debug.print("logiana_end_time=",logiana_end_time,"\n");
Debug.print("oscillo_start_time=",oscillo_start_time," ");
Debug.print("oscillo_end_time=",oscillo_end_time,"\n");

 }

 public void set_draw_parameter( boolean t, int logi, int osci, int sub, int left_posi, int scale )
 {
   panel_type = t;
   logiana_draw_ch_cnt = logi;
   oscillo_draw_ch_cnt = osci;   
   sub_window_height = sub;
   display_start_position = left_posi;
   drawing_scale = scale;
   drawing_scale /= 256;
//   Debug.print("display_start_position=", display_start_position, "\n");
 }

 private void calc_display_time()
 {
   float interval;
   
   if( panel_type == Window.OSCILLO_TYPE )
   {
     interval = oscillo_interval;
   }
   else
   {
     interval = logiana_interval;
   }
   drawing_interval = interval /  drawing_scale;

   display_start_time = display_start_position * interval;
   display_end_time =  display_start_time + ( dimension.width - 1 ) * drawing_interval;
   Debug.print("display_start_time=", display_start_time, "\n");
   Debug.print("display_end_time=", display_end_time, "\n");
 }
 
static final int X_SCALE = 1;
static final int CH_SCALE = 1;
int oscillo_data_block_size;

public short get_oscillo_data(int sampling_posi,int sampling_ch )
{
short oscillo_data;
int ch_posi;
int posi;
int limit_posi;
    oscillo_data = -1;
          
//    ch_posi = log_data.oscillo_sampling_posi_list[sampling_ch];
    ch_posi = parent.log_data.oscillo_sampling_ch_list[sampling_ch];
    limit_posi = oscillo_data_count*oscillo_data_ch;
          
    if( ch_posi != -1 )
    {
         posi = ch_posi+oscillo_data_block_size*sampling_posi;
         if( posi < limit_posi )
         {
           oscillo_data = parent.log_data.oscillo_data[posi];
         }
    }
    return oscillo_data;
}

  private void oscillo_draw_common(Graphics g, int sampling_ch, int ch_posi )
  {
//        h_pitch = (dimension.width - 1) / 18;
//        v_pitch = h_pitch;
   // 0..1023 ==> 0..drawing_height
   float y_scale;
   int drawing_height_offset;
   int sampling_posi;
   int prev_sampling_posi;
   int sampling_data;
   
   float y_posi1,y_posi2, s_posiy;
   int x_posi1,x_posi2, s_posix;
   float drawing_time;
   int posi;
   int skip_count;
//   int limit_posi;
   
        skip_count = 0;
        y_scale = drawing_height;
        y_scale /= 1024;
        
        drawing_height_offset = drawing_height + top;
        
        Debug.print("oscillo_data_count=",oscillo_data_count,"\n");
        sampling_posi = calc_sampling_posi( oscillo_interval, drawing_start_time, parent.oscillo_trigger_point, oscillo_data_count );
        prev_sampling_posi = sampling_posi - 1;
//        limit_posi = oscillo_data_count*oscillo_data_ch;
        
//        Debug.print("sampling_posi=",sampling_posi,"\n");
//        Debug.print("oscillo_data_ch=",oscillo_data_ch,"\n");

        Graphics2D g2d = (Graphics2D) g;
          posi = ch_posi+oscillo_data_block_size*sampling_posi;
          sampling_data = parent.log_data.oscillo_data[posi];
          y_posi1 = sampling_data * y_scale;
          x_posi1 = (int) (( drawing_start_time - display_start_time )/oscillo_interval);
          x_posi2 = x_posi1;
          s_posix = x_posi1 + 5;
          s_posiy = y_posi1;
          g2d.setColor(Color.ORANGE);
          g2d.drawString("CH"+Integer.toString(sampling_ch), s_posix, (int)( -s_posiy+drawing_height_offset) );
          parent.set_oscillo_cursor_y_posi(sampling_ch, (int)( -s_posiy+drawing_height_offset));

          drawing_time = display_start_time;
        //グラフ描画
          for (int i = 0; i <= dimension.width ; i++) {

            if( ( drawing_start_time <= drawing_time ) && ( drawing_time <= drawing_end_time ) )
            {
              sampling_posi = calc_sampling_posi( oscillo_interval, drawing_time, parent.oscillo_trigger_point, oscillo_data_count );
              x_posi2+=1;
              if( prev_sampling_posi != sampling_posi)
              {
                posi = ch_posi+oscillo_data_block_size*sampling_posi;
//                if( posi < limit_posi )
//                {
                  sampling_data = parent.log_data.oscillo_data[posi];
                  y_posi2 = sampling_data * y_scale;
                  g2d.drawLine(x_posi1 , (int) (-y_posi1 + drawing_height_offset), x_posi2, (int) (-y_posi2 + drawing_height_offset));
                  y_posi1 = y_posi2;
                  x_posi1 = x_posi2;
                  prev_sampling_posi = sampling_posi;
//                }
//                else
//                {
//                  skip_count++;
//                }
              }
            }
            drawing_time += drawing_interval;
          }
//          Debug.print("skip_count=",skip_count,"\n");
    }
          
  private void draw_oscillo(Graphics g) {

//Debug.print("display_start_time=",display_start_time," ");
//Debug.print("display_end_time=",display_end_time,"\n");

      if( display_start_time >= oscillo_end_time )return;
      if( display_end_time <= oscillo_start_time )return;
      
      if( display_start_time <= oscillo_start_time )
      {
          drawing_start_time = oscillo_start_time;
      }
      else
      {
          drawing_start_time = display_start_time;
      }

      if( display_end_time < oscillo_end_time )
      {
          drawing_end_time = display_end_time;
      }
      else
      {
          drawing_end_time = oscillo_end_time;
      }
      
//Debug.print("drawing_start_time=",drawing_start_time," ");
//Debug.print("drawing_end_time=",drawing_end_time,"\n");

      if( panel_type == Window.OSCILLO_TYPE )
      {
            drawing_height = dimension.height - sub_window_height;
            top = 0;
      }
      else
      {
          drawing_height = sub_window_height;
          top = dimension.height - drawing_height;
      }
        
      if( oscillo_data_ch <= 2 )
      {
        oscillo_data_block_size = oscillo_data_ch;
      }
      else
      {
        oscillo_data_block_size = 4;
      }
        
//        reset_calc_posi();

        for(int count = 0 ; count < oscillo_draw_ch_cnt ; count++ )
        {
        int ch_posi;
        int ch;
        
          ch = parent.oscillo_draw_ch[count];
          
//          if( ch >= 0 )ch_posi = log_data.oscillo_sampling_posi_list[ch];
          if( ch >= 0 )ch_posi = parent.log_data.oscillo_sampling_ch_list[ch];
          else  ch_posi = -1;
          
          if( ch_posi != -1 )
          {
            oscillo_draw_common( g, ch, ch_posi );
          }
        }
    }

    private void draw_logiana_ch( Graphics g,int ch,int v_posi, int offset )
    {
      int bit_flag;
      int sampling_posi;
      float drawing_time;
   
      bit_flag = 1<<parent.log_data.ch_to_bitposi(ch);
      
      g.setColor(Color.ORANGE);
      g.drawString("CH"+Integer.toString(ch), 5, (int)( v_posi - offset) );
      parent.set_logiana_cursor_y_posi( ch, (int)( v_posi - offset));

      drawing_time = display_start_time;
      if( drawing_interval == logiana_interval )
      {
        boolean c,n;
  //      Debug.print("drawing_interval == logiana_interval", " ", "\n");
          c = n = false;
          for (int i = 0; i <= dimension.width; i++) 
          {
              if ((drawing_start_time <= drawing_time) && (drawing_time <= drawing_end_time))
              {
                  sampling_posi = calc_sampling_posi(logiana_interval, drawing_time, parent.logiana_trigger_point, logiana_data_count);
                  if( sampling_posi < parent.log_data.logiana_data.length )
                  {
                    c = ((parent.log_data.logiana_data[sampling_posi] & bit_flag) != 0);
                    if( ( sampling_posi+1 ) < parent.log_data.logiana_data.length)
                    {
                      n = ((parent.log_data.logiana_data[sampling_posi + 1] & bit_flag) != 0);
                    }
                    else
                    {
                      n = ((parent.log_data.logiana_data[0] & bit_flag) != 0);
                    }
                    if ((!c) && (!n)) {
                      g.drawLine(i, v_posi, i + 1, v_posi);
                    } else if ((!c) && (n)) {
                      g.drawLine(i, v_posi, i + 1, v_posi);
                      g.drawLine(i + 1, v_posi, i + 1, v_posi - offset);
                    } else if ((c) && (!n)) {
                      g.drawLine(i, v_posi - offset, i + 1, v_posi - offset);
                      g.drawLine(i + 1, v_posi - offset, i + 1, v_posi);
                    } else if ((c) && (n)) {
                      g.drawLine(i, v_posi - offset, i + 1, v_posi - offset);
                    }
                    c = n;
                } else if (!n) {
                  g.drawLine(i, v_posi, i + 1, v_posi);
                } else {
                  g.drawLine(i, v_posi - offset, i + 1, v_posi - offset);
                }
                drawing_time += drawing_interval;
              }
          }
        }
      else if( drawing_interval < logiana_interval )
      {
        boolean c;
        int prev;
        int repeat_count;
        int skip_count;
//        Debug.print("drawing_interval < logiana_interval", " ", "\n");
          c = false;
          prev = v_posi;
          repeat_count = (int) (logiana_interval / drawing_interval);
          skip_count = 0;
          for (int i = 1; i <= dimension.width; i++)
          {
              if ((drawing_start_time <= drawing_time) && (drawing_time <= drawing_end_time))
              {
                g.drawLine(i - 1, prev, i, prev );
                  if( (++skip_count) < repeat_count )
                  {
                    skip_count = 0;
                    sampling_posi = calc_sampling_posi(logiana_interval, drawing_time, parent.logiana_trigger_point, logiana_data_count);
                    c = ((parent.log_data.logiana_data[sampling_posi] & bit_flag) != 0);
                    if ( !c )
                    {
                       g.drawLine( i, prev , i, v_posi);
                       prev = v_posi;
                    } 
                    else
                    {
                       g.drawLine( i, prev, i, v_posi - offset);
                       prev = v_posi - offset;
                    }
                  }
              }
              drawing_time += drawing_interval;
          }
      }
      else    //  drawing_interval > logiana_interval 
      {
        int repeat_count;
        boolean c,p;
        int prev;
//        Debug.print("drawing_interval > logiana_interval", " ", "\n");
          c = p = false;
          repeat_count = (int) (drawing_interval / logiana_interval);
          prev = v_posi;
//        Debug.print("repeat_count =", repeat_count, "\n");
          for (int i = 1; i <= dimension.width;i++) {
          {
            if ((drawing_start_time <= drawing_time) && (drawing_time <= drawing_end_time))
            {
              g.drawLine(i - 1, prev, i, prev );
              sampling_posi = calc_sampling_posi(logiana_interval, drawing_time, parent.logiana_trigger_point, logiana_data_count);
              for( int loop = 0; loop < repeat_count; loop++)
              {
                  c = ((parent.log_data.logiana_data[sampling_posi] & bit_flag) != 0);
                  if ( c != p )
                  {
                    if ( !c )
                    {
                      g.drawLine(i, prev, i, v_posi);
                      prev = v_posi;
                    }
                    else
                    {
                      g.drawLine(i, prev, i, v_posi - offset);
                      prev = v_posi - offset;
                    }
                      
                  }
                  sampling_posi++;
                  p = c;
                  if( sampling_posi >= logiana_data_count )break;
              }
            }
            drawing_time += drawing_interval;
          }
      
        }
      }
    }
  
    private void draw_logiana(Graphics g) {
        int v_posi;
        int v_pitch;

        if( logiana_draw_ch_cnt == 0 )return;
        
        if( display_start_time >= logiana_end_time )return;
        if( display_end_time <= logiana_start_time )return;
      
        if( display_start_time <= logiana_start_time )
        {
          drawing_start_time = logiana_start_time;
        }
        else
        {
          drawing_start_time = display_start_time;
        }

        if( display_end_time < logiana_end_time )
        {
          drawing_end_time = display_end_time;
        }
        else
        {
          drawing_end_time = logiana_end_time;
        }
        
        if( panel_type == Window.LOGIANA_TYPE )
        {
            drawing_height = dimension.height - sub_window_height;
            top = 0;
        }
        else
        {
            drawing_height = sub_window_height;
            top = dimension.height - sub_window_height;
        }
        
        v_pitch = drawing_height/logiana_draw_ch_cnt;
        v_posi = top + drawing_height-5;

        for(int count = 0 ; count < logiana_draw_ch_cnt ; count++ )
        {
          draw_logiana_ch(g,parent.logiana_draw_ch[count],v_posi, v_pitch/3);                      
          v_posi -= v_pitch;
        }
    }
      
    public void clear_draw()
    {
       this.removeAll();
    }
    
    public int calc_cursor_sampling_posi( boolean type )
    {
    int sampling_posi;
        
      if( type == Window.LOGIANA_TYPE)
      {
          if( logiana_data_count != 0 )
          {
            sampling_posi = calc_sampling_posi(logiana_interval, parent.cursor_time_posi, parent.logiana_trigger_point, logiana_data_count);
          }
          else
          {
            sampling_posi = 0;
          }
      }
      else
      {
          if( oscillo_data_count != 0 )
          {
            sampling_posi = calc_sampling_posi(oscillo_interval, parent.cursor_time_posi, parent.oscillo_trigger_point, oscillo_data_count);
          }
          else
          {
            sampling_posi = 0;
          }
      }
      return sampling_posi;
    }
    
 //=============================================================================
 //paint()メソッド
 //=============================================================================

    @Override
    public void paintComponent(Graphics g) {

          super.paintComponent(g);
        //領域のサイズ取得
          dimension = getSize();
          
          parent.show_window_name();
          calc_display_time();
        
          draw_logiana( g );
          draw_oscillo( g );
          parent.show_cursor_data();
          Debug.print("log_count=",parent.log_data.log_count,"\n");
    }
}
