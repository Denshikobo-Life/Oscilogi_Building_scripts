/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osci_logi_console;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author akira
 */
public class FileOperation {
   private PrintWriter pw;
   
   public  FileOperation()
   {
       fn = "test";
       common( fn+".txt");
   }

   private String fn = "";
   private int num;
   public  FileOperation(String s)
   {
       fn = fn.concat(s);
       num = 0;
       common( fn+".txt" );
   }
   
   private void common(String f_name)
   {
//      System.out.println("ファイル:"+f_name+"をオープンします\n");
      try{
      File file = new File( f_name );
      file.createNewFile();

      if (checkBeforeWritefile(file)){
        pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
        pw.println(LocalDateTime.now());
      }else{
        System.out.println("ファイルに書き込めません");
      }
    }catch(IOException e){
      System.out.println(e);
    }
  }

  private static boolean checkBeforeWritefile(File file){
    if (file.exists()){
      if (file.isFile() && file.canWrite()){
        return true;
      }
    }

    return false;
  }
  
  public void append( short data[])
  {
      for(int  i=0;i<data.length;i++)
      {
        pw.println( data[i] );
      }
  }

  public void append( short data )
  {
      pw.println( data );
  }

   public void separator()
  {
      pw.println("---------------------------------------------------------------");
  }
  
   public void comment( String s)
  {
      pw.println( s );
  }

   public void close()
  {
     pw.close();
//     System.out.println("ファイル:"+fn+".txtをクローズしました\n");
       try {
           this.finalize();
       } catch (Throwable ex) {
           Logger.getLogger(FileOperation.class.getName()).log(Level.SEVERE, null, ex);
       }
  }
   
  @Override
  protected void finalize() throws Throwable {
    try {
      super.finalize();
    } finally {
//      System.out.print("Destroy FileOperation\n");
    }
  }
}
