package osci_logi_console;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

/**
 *
 * @author akira
 */
public class Main_Frame extends javax.swing.JFrame implements DocumentListener{
//     Oscillo_Panel oscillo;
//     Logiana_Panel logiana;

     Window window1;
     Window window2;
     Window window3;
     Window window4;
     Window window;
    
     int canvas_width;
     int canvas_height;
          
     public boolean update_canvas;
     public boolean skip_flag;
     
     public final static Color CANVAS_COLOR  = new Color(0, 51, 51);
     
     public static boolean[] oscillo_ch_selectable = new boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
     public static boolean[] logiana_ch_selectable = new boolean[Log_Data.LOGIANA_MAX_CH_COUNT];
     
     public static boolean meas_on_flag;
     
     class Main_Frame_Timer implements ActionListener{
       private static final long serialVersionUID = 1L;
      javax.swing.Timer timer;
      int count;

      public Main_Frame_Timer()
      {
        count = 0;
        // Timer Thread の設定
        timer = new javax.swing.Timer( 1000, this );
      }
    
      public void start()
      {
        timer.start();
      }

      public void stop()
      {
        timer.stop();
      }
      
      private void window_update_common(Window w)
      {
        if( !w.hold_flag )
        {
            w.update_s_t_e();
            w.set_draw_parameter();
        }
      }

      @Override
      public void actionPerformed(ActionEvent ae) {
        if( Osci_logi.current_log_update )
        {
          window_update_common(window1);
          window_update_common(window2);
          window_update_common(window3);
          window_update_common(window4);
          
          if(( window != null )&&(!window.hold_flag))
          {
            window.set_ch_selectable_flag();
            select_flag_update();
            update_slider();
          }
//          check_redraw();
          View_Canvas();
          Osci_logi.current_log_update = false;
        }
      }
   }
     
    /**
     * Creates new form Oscil_ogi_Comm
     */
    public Main_Frame() {
        skip_flag = true;
        meas_on_flag = false;
        initComponents();
        remove_Console_Panel();
        window1 = new Window(Canvas.getWidth(),Canvas.getHeight(),"Window1");
        window2 = new Window("Window2");
        window3 = new Window("Window3");
        window4 = new Window("Window4");
        
//        ButtonGroup group0 = new ButtonGroup();
        ButtonGroup group1 = new ButtonGroup();
        ButtonGroup group2 = new ButtonGroup();

//        group0.add(jRB_CH_Up);
//        group0.add(jRB_CH_Down);
        
        group1.add(RB_S14);
        group1.add(RB_S12);
        group1.add(RB_S11);
        
        group2.add(RB_POSI_U);
        group2.add(RB_POSI_UM);
        group2.add(RB_POSI_LM);
        group2.add(RB_POSI_L);
        
        canvas_width = Canvas.getWidth();
        canvas_height = Canvas.getHeight();
        Main_Frame_Timer main_frame_timer = new Main_Frame_Timer();
        main_frame_timer.start();
        skip_flag = false;
    }

    // scaling
    // 横軸
    // sample data ==> oscillo.getWidth()
    // 全体表示 ==>　間引き  データ数/oscillo.getWidth()
    //  8192/width
    // 拡大表示 ==>  部分      
    // 縦軸
    // 0..1023 <==> o..height
    // ad_value * height / 1024

    public void Reset_Canvas()
    {
        if( !window1.hold_flag ){
          Canvas.remove(window1);
        }
        if( !window2.hold_flag ){
          Canvas.remove(window2);
        }
        if( !window3.hold_flag ){
          Canvas.remove(window3);
        }
        if( !window4.hold_flag ){
          Canvas.remove(window4);
        }
        
        Canvas.revalidate();
        Canvas.repaint();
    }

    public void Redraw_Window()
    {
        if( window == null )return;
        
        if( window.v_flag ){
            window.setup();
            Canvas.add(window, new AbsoluteConstraints(window.x_posi, window.y_posi, -1, -1));
        }
        else
        {
          Canvas.remove(window);
        }
        Canvas.revalidate();
        Canvas.repaint();
    }
    
    public void View_Canvas()
    {
        if( window == null )return;
        
        Canvas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        if( window1.v_flag ){
          window1.setup();
          if( !window1.hold_flag ){
            Canvas.add(window1, new AbsoluteConstraints(window1.x_posi, window1.y_posi, -1, -1));
          }
        }
        else
        {
          Canvas.remove(window1);
        }
        
        if( window2.v_flag ){
          if( !window2.hold_flag ){
            window2.setup();
            Canvas.add(window2, new AbsoluteConstraints(window2.x_posi, window2.y_posi, -1, -1));
          }
        }
        else
        {
          Canvas.remove(window2);
        }

        if( window3.v_flag ){
          if( !window3.hold_flag ){
            window3.setup();
            Canvas.add(window3, new AbsoluteConstraints(window3.x_posi, window3.y_posi, -1, -1));
          }
        }
        else
        {
          Canvas.remove(window3);
        }

        if( window4.v_flag ){
          if( !window1.hold_flag ){
            window4.setup();
            Canvas.add(window4, new AbsoluteConstraints(window4.x_posi, window4.y_posi, -1, -1));
          }
        }
        else
        {
          Canvas.remove(window4);
        }
        Canvas.revalidate();
        Canvas.repaint();
    }

    private boolean flicker_flag;
    public void keisoku_flicker() {
        if( flicker_flag )
        {
            B_keisoku.setForeground( Color.ORANGE );
            flicker_flag = false;
        }
        else
        {
          B_keisoku.setForeground( Color.BLACK );
          flicker_flag = true;
        }
    }
    
    public void keisoku_off() {
          B_keisoku.setForeground( Color.BLACK );
    }
    

    private String command_string;

   
    private void show_send_command()
    {
//         send_command_view.setText("");
        System.out.print("*********************************\n");
        System.out.print("send_command\n");
        for (String str : Osci_logi.send_text) {
            System.out.print(str+"\n");
        }
    }

    private int get_value(String s, int e )
    {
      int ret;  
      try {
	// 処理
        ret = Integer.parseInt( s );
      } catch (Exception exp) {
	// 処理
          Debug.print("Caution!\n==> ",s," isn't numeric string\n");
          ret = e;
      } finally {
	// 処理
      }
      return ret;
    }

//    private int get_value()
//    {
//      String[] sub_string = command_string.split(":");
//      return Integer.parseInt( sub_string[sub_string.length - 1]);
//    }
//    
//    private int get_bit_pattern(int bit_ch )
//    {
//        int bit_pattern;
//        switch( bit_ch )
//        {
//            case 0:
//                bit_pattern = 0x0001;
//                break;
//            case 1:
//                bit_pattern = 0x0002;
//                break;
//            case 2:
//                bit_pattern = 0x0010;
//                break;
//            case 3:
//                bit_pattern = 0x0020;
//                break;
//            case 4:
//                bit_pattern = 0x0080;
//                break;
//            case 5:
//            default:
//                bit_pattern = 0x0100;
//                break;
//        }
//        return bit_pattern;
//    }
    
//    public void Init(){
//    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Window_console = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        RB_OCH1 = new javax.swing.JRadioButton();
        RB_OCH0 = new javax.swing.JRadioButton();
        RB_LCH0 = new javax.swing.JRadioButton();
        RB_LCH2 = new javax.swing.JRadioButton();
        RB_LCH1 = new javax.swing.JRadioButton();
        RB_LCH3 = new javax.swing.JRadioButton();
        RB_LCH6 = new javax.swing.JRadioButton();
        RB_LCH4 = new javax.swing.JRadioButton();
        RB_LCH7 = new javax.swing.JRadioButton();
        RB_LCH8 = new javax.swing.JRadioButton();
        RB_LCH9 = new javax.swing.JRadioButton();
        RB_LCH5 = new javax.swing.JRadioButton();
        Window_Label = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        RB_S14 = new javax.swing.JRadioButton();
        RB_S12 = new javax.swing.JRadioButton();
        RB_S11 = new javax.swing.JRadioButton();
        RB_POSI_U = new javax.swing.JRadioButton();
        RB_POSI_UM = new javax.swing.JRadioButton();
        RB_POSI_LM = new javax.swing.JRadioButton();
        RB_POSI_L = new javax.swing.JRadioButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        B_H_LEFT = new javax.swing.JButton();
        R_H_RIGHT = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        TF_H = new javax.swing.JTextField();
        B_VIEW = new javax.swing.JButton();
        B_Type = new javax.swing.JButton();
        RB_OCH2 = new javax.swing.JRadioButton();
        RB_OCH3 = new javax.swing.JRadioButton();
        jLabel24 = new javax.swing.JLabel();
        TF_Disp_Posi_Min = new javax.swing.JTextField();
        TF_Disp_Posi_Max = new javax.swing.JTextField();
        Display_Position = new javax.swing.JSlider();
        TF_Cursor_Posi = new javax.swing.JTextField();
        Cursor_Position = new javax.swing.JSlider();
        jB_Data_Display = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jB_update = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        B_logout = new javax.swing.JButton();
        Oscillo_console = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hBar = new javax.swing.JSlider();
        B_or5 = new javax.swing.JButton();
        B_och0 = new javax.swing.JButton();
        B_or1 = new javax.swing.JButton();
        B_or2 = new javax.swing.JButton();
        B_och1 = new javax.swing.JButton();
        B_or10 = new javax.swing.JButton();
        B_or20 = new javax.swing.JButton();
        B_or200 = new javax.swing.JButton();
        B_or100 = new javax.swing.JButton();
        B_or50 = new javax.swing.JButton();
        B_okHz = new javax.swing.JButton();
        B_oHz = new javax.swing.JButton();
        B_otrigupdown = new javax.swing.JButton();
        B_otrigcond = new javax.swing.JButton();
        B_otrigmode = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        T_o_sample = new javax.swing.JTextField();
        B_och2 = new javax.swing.JButton();
        B_och3 = new javax.swing.JButton();
        jTrigger_CB = new javax.swing.JComboBox();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        T_otriglevel = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        B_otriglink = new javax.swing.JButton();
        B_or500 = new javax.swing.JButton();
        Logiana_console = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        B_lr2 = new javax.swing.JButton();
        B_ltrig0 = new javax.swing.JButton();
        B_lr10 = new javax.swing.JButton();
        B_lr5 = new javax.swing.JButton();
        B_lch0 = new javax.swing.JButton();
        B_lch5 = new javax.swing.JButton();
        B_lr20 = new javax.swing.JButton();
        B_lch3 = new javax.swing.JButton();
        B_lch4 = new javax.swing.JButton();
        B_lch2 = new javax.swing.JButton();
        B_lch1 = new javax.swing.JButton();
        B_lr1 = new javax.swing.JButton();
        B_lr50 = new javax.swing.JButton();
        B_lr100 = new javax.swing.JButton();
        B_lr200 = new javax.swing.JButton();
        B_lr500 = new javax.swing.JButton();
        B_lr1000 = new javax.swing.JButton();
        B_ltrig1 = new javax.swing.JButton();
        B_ltrig2 = new javax.swing.JButton();
        B_ltrig3 = new javax.swing.JButton();
        B_ltrig4 = new javax.swing.JButton();
        B_ltrig5 = new javax.swing.JButton();
        B_ltrigcond = new javax.swing.JButton();
        B_lHz = new javax.swing.JButton();
        B_lkHz = new javax.swing.JButton();
        T_l_sample = new javax.swing.JTextField();
        B_lch6 = new javax.swing.JButton();
        B_lch7 = new javax.swing.JButton();
        B_lch8 = new javax.swing.JButton();
        B_lch9 = new javax.swing.JButton();
        B_ltrig6 = new javax.swing.JButton();
        B_ltrig7 = new javax.swing.JButton();
        B_ltrig8 = new javax.swing.JButton();
        B_ltrig9 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        B_ltriglink = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        B_ltrigmode = new javax.swing.JButton();
        Base_pannel = new javax.swing.JPanel();
        B_hannpuku = new javax.swing.JButton();
        B_shuuryou = new javax.swing.JButton();
        B_keisoku = new javax.swing.JButton();
        B_tyuudan = new javax.swing.JButton();
        Canvas = new javax.swing.JPanel();
        Console_Panel = new javax.swing.JPanel();
        Toppanel = new javax.swing.JPanel();
        Console_labal = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Oscillo_Button = new javax.swing.JButton();
        Logiana_Button = new javax.swing.JButton();
        Window_1_Button = new javax.swing.JButton();
        Window_2_Button = new javax.swing.JButton();
        Window_3_Button = new javax.swing.JButton();
        Window_4_Button = new javax.swing.JButton();

        Window_console.setBackground(new java.awt.Color(153, 153, 0));
        Window_console.setPreferredSize(new java.awt.Dimension(540, 555));
        Window_console.setRequestFocusEnabled(false);

        jLabel13.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel13.setText("ロジアナ");

        jLabel14.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel14.setText("オシロ");

        RB_OCH1.setText("CH1");
        RB_OCH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_OCH1ActionPerformed(evt);
            }
        });

        RB_OCH0.setText("CH0");
        RB_OCH0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_OCH0ActionPerformed(evt);
            }
        });

        RB_LCH0.setText("CH0");
        RB_LCH0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH0ActionPerformed(evt);
            }
        });

        RB_LCH2.setText("CH2");
        RB_LCH2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH2ActionPerformed(evt);
            }
        });

        RB_LCH1.setText("CH1");
        RB_LCH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH1ActionPerformed(evt);
            }
        });

        RB_LCH3.setText("CH3");
        RB_LCH3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH3ActionPerformed(evt);
            }
        });

        RB_LCH6.setText("CH6");
        RB_LCH6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH6ActionPerformed(evt);
            }
        });

        RB_LCH4.setText("CH4");
        RB_LCH4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH4ActionPerformed(evt);
            }
        });

        RB_LCH7.setText("CH7");
        RB_LCH7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH7ActionPerformed(evt);
            }
        });

        RB_LCH8.setText("CH8");
        RB_LCH8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH8ActionPerformed(evt);
            }
        });

        RB_LCH9.setText("CH9");
        RB_LCH9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH9ActionPerformed(evt);
            }
        });

        RB_LCH5.setText("CH5");
        RB_LCH5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_LCH5ActionPerformed(evt);
            }
        });

        Window_Label.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        Window_Label.setText("Window1");
        Window_Label.setMaximumSize(new java.awt.Dimension(85, 19));
        Window_Label.setMinimumSize(new java.awt.Dimension(85, 19));
        Window_Label.setPreferredSize(new java.awt.Dimension(41, 19));

        jLabel17.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel17.setText("サイズ");

        RB_S14.setText("1/4");
        RB_S14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_S14ActionPerformed(evt);
            }
        });

        RB_S12.setText("1/2");
        RB_S12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_S12ActionPerformed(evt);
            }
        });

        RB_S11.setText("1/1");
        RB_S11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_S11ActionPerformed(evt);
            }
        });

        RB_POSI_U.setText("上");
        RB_POSI_U.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_POSI_UActionPerformed(evt);
            }
        });

        RB_POSI_UM.setText("中上");
        RB_POSI_UM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_POSI_UMActionPerformed(evt);
            }
        });

        RB_POSI_LM.setText("中下");
        RB_POSI_LM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_POSI_LMActionPerformed(evt);
            }
        });

        RB_POSI_L.setText("下");
        RB_POSI_L.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_POSI_LActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel19.setText("垂直位置");

        jLabel20.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel20.setText("Hスケール");

        B_H_LEFT.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        B_H_LEFT.setText("◀");
        B_H_LEFT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_H_LEFTActionPerformed(evt);
            }
        });

        R_H_RIGHT.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        R_H_RIGHT.setText("▶");
        R_H_RIGHT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                R_H_RIGHTActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel21.setText("カーソル");

        TF_H.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        TF_H.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TF_H.setText("１／１");
        TF_H.setPreferredSize(new java.awt.Dimension(100, 25));

        B_VIEW.setText("表示");
        B_VIEW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_VIEWActionPerformed(evt);
            }
        });

        B_Type.setText("表示TYPE");
        B_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_TypeActionPerformed(evt);
            }
        });

        RB_OCH2.setText("CH2");
        RB_OCH2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_OCH2ActionPerformed(evt);
            }
        });

        RB_OCH3.setText("CH3");
        RB_OCH3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_OCH3ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel24.setText("表示位置");
        jLabel24.setName(""); // NOI18N

        TF_Disp_Posi_Min.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        TF_Disp_Posi_Min.setText("０");
        TF_Disp_Posi_Min.setMaximumSize(new java.awt.Dimension(70, 19));
        TF_Disp_Posi_Min.setMinimumSize(new java.awt.Dimension(70, 19));
        TF_Disp_Posi_Min.setName(""); // NOI18N
        TF_Disp_Posi_Min.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF_Disp_Posi_MinActionPerformed(evt);
            }
        });

        TF_Disp_Posi_Max.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        TF_Disp_Posi_Max.setText("500");
        TF_Disp_Posi_Max.setMaximumSize(new java.awt.Dimension(70, 19));
        TF_Disp_Posi_Max.setMinimumSize(new java.awt.Dimension(70, 19));
        TF_Disp_Posi_Max.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF_Disp_Posi_MaxActionPerformed(evt);
            }
        });

        Display_Position.setMaximum(1000);
        Display_Position.setMinorTickSpacing(100);
        Display_Position.setPaintTicks(true);
        Display_Position.setValue(0);
        Display_Position.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                Display_PositionStateChanged(evt);
            }
        });

        TF_Cursor_Posi.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        TF_Cursor_Posi.setText("0");
        TF_Cursor_Posi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF_Cursor_PosiActionPerformed(evt);
            }
        });

        Cursor_Position.setMaximum(1000);
        Cursor_Position.setMinorTickSpacing(100);
        Cursor_Position.setPaintTicks(true);
        Cursor_Position.setValue(0);
        Cursor_Position.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                Cursor_PositionStateChanged(evt);
            }
        });

        jB_Data_Display.setText("ＯＦＦ");
        jB_Data_Display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_Data_DisplayActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel25.setText("データ表示");

        jB_update.setText("UPDATE");
        jB_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_updateActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel29.setText("データ出力");

        B_logout.setText("出力");
        B_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_logoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Window_consoleLayout = new javax.swing.GroupLayout(Window_console);
        Window_console.setLayout(Window_consoleLayout);
        Window_consoleLayout.setHorizontalGroup(
            Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Window_consoleLayout.createSequentialGroup()
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Window_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Window_consoleLayout.createSequentialGroup()
                        .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Window_consoleLayout.createSequentialGroup()
                                        .addComponent(RB_LCH0)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH3))
                                    .addGroup(Window_consoleLayout.createSequentialGroup()
                                        .addComponent(RB_LCH5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RB_LCH8)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(RB_LCH4)
                                    .addComponent(RB_LCH9)))
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addComponent(RB_OCH0)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_OCH1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_OCH2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_OCH3)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(Window_consoleLayout.createSequentialGroup()
                        .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Cursor_Position, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addComponent(B_VIEW)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_Type, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jB_update))
                            .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(Window_consoleLayout.createSequentialGroup()
                                    .addComponent(TF_Disp_Posi_Min, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(TF_Disp_Posi_Max, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(Display_Position, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addComponent(B_H_LEFT)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TF_H, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(R_H_RIGHT))
                            .addComponent(TF_Cursor_Posi, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addComponent(RB_S14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_S12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_S11))
                            .addGroup(Window_consoleLayout.createSequentialGroup()
                                .addComponent(RB_POSI_U)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_POSI_UM)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_POSI_LM)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RB_POSI_L, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(B_logout, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jB_Data_Display, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)))
                        .addGap(0, 125, Short.MAX_VALUE))))
        );

        Window_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {RB_LCH0, RB_LCH1, RB_LCH2, RB_LCH3, RB_LCH4, RB_LCH5, RB_LCH6, RB_LCH7, RB_LCH8, RB_LCH9, RB_OCH0, RB_OCH1});

        Window_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel13, jLabel14, jLabel17, jLabel19, jLabel20, jLabel21});

        Window_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {RB_POSI_L, RB_POSI_LM, RB_POSI_U, RB_POSI_UM, RB_S11, RB_S12, RB_S14});

        Window_consoleLayout.setVerticalGroup(
            Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Window_consoleLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Window_Label, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_VIEW)
                    .addComponent(B_Type)
                    .addComponent(jB_update))
                .addGap(14, 14, 14)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RB_OCH0)
                    .addComponent(RB_OCH1)
                    .addComponent(RB_OCH2)
                    .addComponent(RB_OCH3)
                    .addComponent(jLabel14))
                .addGap(14, 14, 14)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RB_LCH0)
                    .addComponent(RB_LCH1)
                    .addComponent(RB_LCH2)
                    .addComponent(RB_LCH3)
                    .addComponent(RB_LCH4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RB_LCH6)
                    .addComponent(RB_LCH7)
                    .addComponent(RB_LCH8)
                    .addComponent(RB_LCH9)
                    .addComponent(RB_LCH5))
                .addGap(15, 15, 15)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(RB_S14)
                    .addComponent(RB_S12)
                    .addComponent(RB_S11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(RB_POSI_U)
                    .addComponent(RB_POSI_UM)
                    .addComponent(RB_POSI_LM)
                    .addComponent(RB_POSI_L))
                .addGap(18, 18, 18)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(TF_Disp_Posi_Min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TF_Disp_Posi_Max, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Display_Position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(B_H_LEFT)
                    .addComponent(TF_H, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(R_H_RIGHT))
                .addGap(29, 29, 29)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TF_Cursor_Posi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Cursor_Position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_Data_Display)
                    .addComponent(jLabel25))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Window_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(B_logout))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        Window_consoleLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {RB_LCH0, RB_LCH1, RB_LCH2, RB_LCH3, RB_LCH4, RB_LCH5, RB_LCH6, RB_LCH7, RB_LCH8, RB_LCH9});

        Oscillo_console.setBackground(new java.awt.Color(195, 109, 58));
        Oscillo_console.setFocusCycleRoot(true);
        Oscillo_console.setPreferredSize(new java.awt.Dimension(540, 555));

        jLabel4.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel4.setText("オシロ");
        jLabel4.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel5.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel5.setText("計測CH");
        jLabel5.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel7.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel7.setText("計測レート");
        jLabel7.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel7.setRequestFocusEnabled(false);

        jLabel9.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel9.setText("トリガLvl");
        jLabel9.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel9.setRequestFocusEnabled(false);

        jLabel10.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("AND/OR");
        jLabel10.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel10.setRequestFocusEnabled(false);

        hBar.setMaximum(1023);
        hBar.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                hBarStateChanged(evt);
            }
        });
        hBar.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                hBarCaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
            }
        });

        B_or5.setText("5");
        B_or5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or5ActionPerformed(evt);
            }
        });

        B_och0.setText("CH0");
        B_och0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och0ActionPerformed(evt);
            }
        });

        B_or1.setText("1");
        B_or1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or1ActionPerformed(evt);
            }
        });

        B_or2.setText("2");
        B_or2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or2ActionPerformed(evt);
            }
        });

        B_och1.setText("CH1");
        B_och1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och1ActionPerformed(evt);
            }
        });

        B_or10.setText("10");
        B_or10.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or10.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or10ActionPerformed(evt);
            }
        });

        B_or20.setText("20");
        B_or20.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or20.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or20ActionPerformed(evt);
            }
        });

        B_or200.setText("200");
        B_or200.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or200.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or200.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or200ActionPerformed(evt);
            }
        });

        B_or100.setText("100");
        B_or100.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or100.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or100ActionPerformed(evt);
            }
        });

        B_or50.setText("50");
        B_or50.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or50.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or50ActionPerformed(evt);
            }
        });

        B_okHz.setText("kHz");
        B_okHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_okHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_okHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_okHzActionPerformed(evt);
            }
        });

        B_oHz.setText("Hz");
        B_oHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_oHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_oHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_oHzActionPerformed(evt);
            }
        });

        B_otrigupdown.setText("OFF");
        B_otrigupdown.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrigupdown.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrigupdown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrigupdownActionPerformed(evt);
            }
        });

        B_otrigcond.setText("AND");
        B_otrigcond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrigcond.setMaximumSize(new java.awt.Dimension(100, 21));
        B_otrigcond.setMinimumSize(new java.awt.Dimension(100, 21));
        B_otrigcond.setName(""); // NOI18N
        B_otrigcond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrigcond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrigcondActionPerformed(evt);
            }
        });

        B_otrigmode.setText("OFF");
        B_otrigmode.setAutoscrolls(true);
        B_otrigmode.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrigmode.setMaximumSize(new java.awt.Dimension(100, 21));
        B_otrigmode.setMinimumSize(new java.awt.Dimension(100, 21));
        B_otrigmode.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrigmode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrigmodeActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel12.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel12.setRequestFocusEnabled(false);

        T_o_sample.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_o_sample.setText("sample");
        T_o_sample.setPreferredSize(new java.awt.Dimension(62, 21));
        T_o_sample.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_o_sampleActionPerformed(evt);
            }
        });

        B_och2.setText("CH2");
        B_och2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och2ActionPerformed(evt);
            }
        });

        B_och3.setText("CH3");
        B_och3.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och3.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och3ActionPerformed(evt);
            }
        });

        jTrigger_CB.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "CH0", "CH1", "CH2", "CH3" }));
        jTrigger_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTrigger_CBActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel22.setText("トリガCH");
        jLabel22.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel22.setRequestFocusEnabled(false);

        jLabel23.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel23.setText("モード");
        jLabel23.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel23.setRequestFocusEnabled(false);

        T_otriglevel.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_otriglevel.setText("1023");
        T_otriglevel.setPreferredSize(new java.awt.Dimension(62, 21));
        T_otriglevel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                T_otriglevelFocusGained(evt);
            }
        });
        T_otriglevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_otriglevelActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel27.setText("リンク");
        jLabel27.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel27.setRequestFocusEnabled(false);

        B_otriglink.setText("OFF");
        B_otriglink.setAutoscrolls(true);
        B_otriglink.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otriglink.setMaximumSize(new java.awt.Dimension(100, 21));
        B_otriglink.setMinimumSize(new java.awt.Dimension(100, 21));
        B_otriglink.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otriglink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otriglinkActionPerformed(evt);
            }
        });

        B_or500.setText("500");
        B_or500.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or500.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or500.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or500ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Oscillo_consoleLayout = new javax.swing.GroupLayout(Oscillo_console);
        Oscillo_console.setLayout(Oscillo_consoleLayout);
        Oscillo_consoleLayout.setHorizontalGroup(
            Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(413, Short.MAX_VALUE))
            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                        .addComponent(B_och0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_och1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_och2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(T_o_sample, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(B_och3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                                .addComponent(B_or1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_or2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                                .addComponent(B_or10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_or20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(B_or50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(B_or5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                        .addComponent(B_or100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_or200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_or500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                        .addComponent(B_oHz, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_okHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(T_otriglevel, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(133, Short.MAX_VALUE))
                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTrigger_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(hBar, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(B_otrigupdown, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(B_otrigcond, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otrigmode, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otriglink, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        Oscillo_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {B_och0, B_or1, B_or50});

        Oscillo_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {B_oHz, B_or100, B_or2, T_otriglevel, jTrigger_CB});

        Oscillo_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {B_och1, B_okHz, B_or200, B_or5});

        Oscillo_consoleLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {B_or10, B_or20, T_o_sample});

        Oscillo_consoleLayout.setVerticalGroup(
            Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_o_sample, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_or50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_or500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_okHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_oHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(B_otrigupdown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTrigger_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Oscillo_consoleLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(T_otriglevel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(hBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrigcond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrigmode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Oscillo_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otriglink, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(99, Short.MAX_VALUE))
        );

        Logiana_console.setBackground(new java.awt.Color(204, 255, 204));
        Logiana_console.setEnabled(false);
        Logiana_console.setPreferredSize(new java.awt.Dimension(540, 555));

        jLabel1.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel1.setText("ロジアナ");
        jLabel1.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel3.setText("CH選択");
        jLabel3.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel2.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel2.setText("レート");
        jLabel2.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel2.setRequestFocusEnabled(false);

        jLabel8.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel8.setText("トリガ");
        jLabel8.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel8.setRequestFocusEnabled(false);

        B_lr2.setText("2");
        B_lr2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr2ActionPerformed(evt);
            }
        });

        B_ltrig0.setText("--");
        B_ltrig0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig0ActionPerformed(evt);
            }
        });

        B_lr10.setText("10");
        B_lr10.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr10.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr10ActionPerformed(evt);
            }
        });

        B_lr5.setText("5");
        B_lr5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr5ActionPerformed(evt);
            }
        });

        B_lch0.setText("CH0");
        B_lch0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch0ActionPerformed(evt);
            }
        });

        B_lch5.setText("CH5");
        B_lch5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch5ActionPerformed(evt);
            }
        });

        B_lr20.setText("20");
        B_lr20.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr20.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr20ActionPerformed(evt);
            }
        });

        B_lch3.setText("CH3");
        B_lch3.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch3.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch3ActionPerformed(evt);
            }
        });

        B_lch4.setText("CH4");
        B_lch4.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch4.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch4ActionPerformed(evt);
            }
        });

        B_lch2.setText("CH2");
        B_lch2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch2ActionPerformed(evt);
            }
        });

        B_lch1.setText("CH1");
        B_lch1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch1ActionPerformed(evt);
            }
        });

        B_lr1.setText("1");
        B_lr1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr1ActionPerformed(evt);
            }
        });

        B_lr50.setText("50");
        B_lr50.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr50.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr50ActionPerformed(evt);
            }
        });

        B_lr100.setText("100");
        B_lr100.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr100.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr100ActionPerformed(evt);
            }
        });

        B_lr200.setText("200");
        B_lr200.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr200.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr200.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr200ActionPerformed(evt);
            }
        });

        B_lr500.setText("500");
        B_lr500.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr500.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr500.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr500ActionPerformed(evt);
            }
        });

        B_lr1000.setText("1000");
        B_lr1000.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr1000.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr1000.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr1000ActionPerformed(evt);
            }
        });

        B_ltrig1.setText("--");
        B_ltrig1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig1ActionPerformed(evt);
            }
        });

        B_ltrig2.setText("--");
        B_ltrig2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig2ActionPerformed(evt);
            }
        });

        B_ltrig3.setText("--");
        B_ltrig3.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig3.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig3ActionPerformed(evt);
            }
        });

        B_ltrig4.setText("--");
        B_ltrig4.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig4.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig4ActionPerformed(evt);
            }
        });

        B_ltrig5.setText("--");
        B_ltrig5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig5ActionPerformed(evt);
            }
        });

        B_ltrigcond.setText("OFF");
        B_ltrigcond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrigcond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrigcond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrigcondActionPerformed(evt);
            }
        });

        B_lHz.setText("Hz");
        B_lHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lHzActionPerformed(evt);
            }
        });

        B_lkHz.setText("kHz");
        B_lkHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lkHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lkHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lkHzActionPerformed(evt);
            }
        });

        T_l_sample.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        T_l_sample.setText("sample");
        T_l_sample.setPreferredSize(new java.awt.Dimension(62, 21));
        T_l_sample.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_l_sampleActionPerformed(evt);
            }
        });

        B_lch6.setText("CH6");
        B_lch6.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch6.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch6ActionPerformed(evt);
            }
        });

        B_lch7.setText("CH7");
        B_lch7.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch7.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch7ActionPerformed(evt);
            }
        });

        B_lch8.setText("CH8");
        B_lch8.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch8.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch8ActionPerformed(evt);
            }
        });

        B_lch9.setText("CH9");
        B_lch9.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch9.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch9ActionPerformed(evt);
            }
        });

        B_ltrig6.setText("--");
        B_ltrig6.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig6.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig6ActionPerformed(evt);
            }
        });

        B_ltrig7.setText("--");
        B_ltrig7.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig7.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig7ActionPerformed(evt);
            }
        });

        B_ltrig8.setText("--");
        B_ltrig8.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig8.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig8ActionPerformed(evt);
            }
        });

        B_ltrig9.setText("--");
        B_ltrig9.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig9.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig9ActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel26.setText("リンク");
        jLabel26.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel26.setRequestFocusEnabled(false);

        B_ltriglink.setText("OFF");
        B_ltriglink.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltriglink.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltriglink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltriglinkActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel28.setText("モード");
        jLabel28.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel28.setRequestFocusEnabled(false);

        B_ltrigmode.setText("OFF");
        B_ltrigmode.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrigmode.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrigmode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrigmodeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Logiana_consoleLayout = new javax.swing.GroupLayout(Logiana_console);
        Logiana_console.setLayout(Logiana_consoleLayout);
        Logiana_consoleLayout.setHorizontalGroup(
            Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(B_lch0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(B_lch5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lch8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(T_l_sample, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(B_lch4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(B_lch9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(B_lr50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr1000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(B_lr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lr20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(B_lHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_lkHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(B_ltrig5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(B_ltrig0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(B_ltrigcond, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addComponent(B_ltrig6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(B_ltrigmode, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(B_ltriglink, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        Logiana_consoleLayout.setVerticalGroup(
            Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Logiana_consoleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Logiana_consoleLayout.createSequentialGroup()
                        .addComponent(T_l_sample, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lch5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lr50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr1000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lkHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_ltrig0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_ltrig5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(B_ltrigcond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrigmode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Logiana_consoleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltriglink, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 204, 51));
        setBounds(new java.awt.Rectangle(10, 20, 5, 10));

        Base_pannel.setBackground(new java.awt.Color(51, 102, 0));
        Base_pannel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 51), 5, true));
        Base_pannel.setDoubleBuffered(false);
        Base_pannel.setPreferredSize(new java.awt.Dimension(1000, 750));

        B_hannpuku.setText("反復");
        B_hannpuku.setFocusable(false);
        B_hannpuku.setPreferredSize(new java.awt.Dimension(72, 57));
        B_hannpuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_hannpukuActionPerformed(evt);
            }
        });

        B_shuuryou.setText("終了");
        B_shuuryou.setPreferredSize(new java.awt.Dimension(72, 57));
        B_shuuryou.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_shuuryouActionPerformed(evt);
            }
        });

        B_keisoku.setText("計測");
        B_keisoku.setPreferredSize(new java.awt.Dimension(72, 57));
        B_keisoku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_keisokuActionPerformed(evt);
            }
        });

        B_tyuudan.setText("中断");
        B_tyuudan.setPreferredSize(new java.awt.Dimension(72, 57));
        B_tyuudan.setRolloverEnabled(false);
        B_tyuudan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_tyuudanActionPerformed(evt);
            }
        });

        Canvas.setBackground(new java.awt.Color(102, 102, 0));
        Canvas.setPreferredSize(new java.awt.Dimension(750, 700));
        Canvas.setRequestFocusEnabled(false);
        Canvas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Console_Panel.setBackground(new java.awt.Color(0, 153, 255));
        Console_Panel.setPreferredSize(new java.awt.Dimension(550, 570));
        Console_Panel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        Toppanel.setBackground(new java.awt.Color(0, 0, 0));
        Toppanel.setPreferredSize(new java.awt.Dimension(550, 99));

        Console_labal.setBackground(new java.awt.Color(0, 0, 0));
        Console_labal.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        Console_labal.setForeground(new java.awt.Color(255, 255, 255));
        Console_labal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Console_labal.setText("Osci_Logi_Console");
        Console_labal.setFocusable(false);
        Console_labal.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Console_labal.setOpaque(true);
        Console_labal.setPreferredSize(new java.awt.Dimension(480, 70));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Ver.1.2");

        Oscillo_Button.setBackground(new java.awt.Color(204, 255, 153));
        Oscillo_Button.setText("オシロ");
        Oscillo_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Oscillo_ButtonActionPerformed(evt);
            }
        });

        Logiana_Button.setBackground(new java.awt.Color(204, 255, 153));
        Logiana_Button.setText("ロジアナ");
        Logiana_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Logiana_ButtonActionPerformed(evt);
            }
        });

        Window_1_Button.setBackground(new java.awt.Color(204, 255, 153));
        Window_1_Button.setText("１");
        Window_1_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Window_1_ButtonActionPerformed(evt);
            }
        });

        Window_2_Button.setBackground(new java.awt.Color(204, 255, 153));
        Window_2_Button.setText("２");
        Window_2_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Window_2_ButtonActionPerformed(evt);
            }
        });

        Window_3_Button.setBackground(new java.awt.Color(204, 255, 153));
        Window_3_Button.setText("３");
        Window_3_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Window_3_ButtonActionPerformed(evt);
            }
        });

        Window_4_Button.setBackground(new java.awt.Color(204, 255, 153));
        Window_4_Button.setText("４");
        Window_4_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Window_4_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ToppanelLayout = new javax.swing.GroupLayout(Toppanel);
        Toppanel.setLayout(ToppanelLayout);
        ToppanelLayout.setHorizontalGroup(
            ToppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ToppanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(ToppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(ToppanelLayout.createSequentialGroup()
                        .addComponent(Oscillo_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Logiana_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Window_1_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Window_2_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Window_3_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Window_4_Button))
                    .addComponent(Console_labal, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 129, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        ToppanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {Logiana_Button, Oscillo_Button});

        ToppanelLayout.setVerticalGroup(
            ToppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ToppanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ToppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(Oscillo_Button)
                    .addComponent(Logiana_Button)
                    .addComponent(Window_1_Button)
                    .addComponent(Window_2_Button)
                    .addComponent(Window_3_Button)
                    .addComponent(Window_4_Button))
                .addContainerGap())
            .addGroup(ToppanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Console_labal, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        ToppanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {Logiana_Button, Oscillo_Button, Window_1_Button, Window_2_Button, Window_3_Button, Window_4_Button});

        javax.swing.GroupLayout Base_pannelLayout = new javax.swing.GroupLayout(Base_pannel);
        Base_pannel.setLayout(Base_pannelLayout);
        Base_pannelLayout.setHorizontalGroup(
            Base_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Base_pannelLayout.createSequentialGroup()
                .addGroup(Base_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(Base_pannelLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(B_shuuryou, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(99, 99, 99)
                        .addComponent(B_keisoku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(B_tyuudan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(B_hannpuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Console_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Toppanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Canvas, javax.swing.GroupLayout.DEFAULT_SIZE, 653, Short.MAX_VALUE)
                .addContainerGap())
        );
        Base_pannelLayout.setVerticalGroup(
            Base_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Base_pannelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Base_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Canvas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(Base_pannelLayout.createSequentialGroup()
                        .addComponent(Toppanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Console_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(Base_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(B_tyuudan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_hannpuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_keisoku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_shuuryou, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Base_pannel, javax.swing.GroupLayout.PREFERRED_SIZE, 1232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Base_pannel, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public void insertUpdate(DocumentEvent e) {
        System.out.print("insertUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        System.out.print("removeUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        System.out.print("changedUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    class Command {
        Integer  command_index;
        String command;
//        String receive_param;
        String set_type;
        String set_data;
        String command_string;
        
        public Command()
        {
            command_index = 0;
            command = "SET";
//            receive_param = "";
            set_type = "";
            set_data = "";
        }
    }
    
    Command command = new Command();

    public void updateSendText()
    {
        // STS SET LOG BRK RCV
       command_string = command.command;
       command_string += " "+command.set_type+":"+command.set_data;
       Osci_logi.send_string = command_string;
    }
    
    private void b_setteiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_setteiActionPerformed
        // TODO add your handling code here:
        Osci_logi.send_flag = true;
    }//GEN-LAST:event_b_setteiActionPerformed

    private void c_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_typeActionPerformed
        // TODO add your handling code here:
//        command.set_type = (String)c_type.getSelectedItem();
        
        updateSendText();
    }//GEN-LAST:event_c_typeActionPerformed

//    private void tourokuAction_common( ) { 
//        int index;
//        int check_cond;
//        // TODO add your handling code here:
//        if( command.set_type.equals("OSCH") )index = 0;
//        else if( command.set_type.equals("OSCT") )index = 1;
//        else if( command.set_type.equals("OSRT") )index = 2;
//        else if( command.set_type.equals("OSUT") )index = 3;
//        else if( command.set_type.equals("LSBT") )index = 4;
//        else if( command.set_type.equals("LSCT") )index = 5;
//        else if( command.set_type.equals("LSRT") )index = 6;
//        else if( command.set_type.equals("LSUT") )index = 7;
//        else if( command.set_type.equals("TLGI") )index = 8;
//        else if( command.set_type.equals("TOSC") )index = 9;
//        else if( command.set_type.equals("TTMR") )index = 10;
//        else if( command.set_type.equals("TMOD") )index = 11;
//        else if( command.set_type.equals("O0LL") )index = 12;
//        else if( command.set_type.equals("O0UL") )index = 13;
//        else if( command.set_type.equals("O1LL") )index = 14;
//        else if( command.set_type.equals("O1UL") )index = 15;
//        else if( command.set_type.equals("LCBT") )index = 16;
//        else if( command.set_type.equals("LCMK") )index = 17;
//        else if( command.set_type.equals("LPTN") )index = 18;
//        else if( command.set_type.equals("LPMK") )index = 19;
//        else if( command.set_type.equals("TDLY") )index = 20;
//        else if( command.set_type.equals("TDUT") )index = 21;
//        else index = -1;
//        
//        if( index == -1 )
//        {
//            System.out.print( command.set_type+" "+command.set_data);
//            return;        
//        }
//       
//        command_string = command.command;
//        command_string += " "+command.set_type+":"+command.set_data;
//        
//       if( ( index == 12 )||( index == 14 ) ) // "O0LL" || O1LL"
//       {
//         check_cond = otrigcond;  //"O0LL"
//         if( index == 14 ) 
//         {
//            check_cond = otrigcond; // "O1LL"      
//         }
//         if( check_cond == TRIG_OFF )
//         {
//           command_string += ":OFF";
//         }
//         else if( check_cond == RANGE_IN)
//         {
//           command_string += ":IN";
//         }
//         else
//         {
//           command_string += ":OUT";
//         }
//       }
//       
//        Osci_logi.send_string = command_string;
//        Osci_logi.send_text.set(index, command_string);
//        // コマンドに応じた調整
//        check_command_string();
//    }                                         
    
          
    private void B_lch0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch0.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }                                           

  private void B_lch1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch1.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
  }
  
  private void B_lch2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch2.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
  }                                           

    private void B_lch3ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch3.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }
  
    private void B_lch4ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch4.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }
    
    private void B_lch5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( B_lch5.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }                                           

    private void lr_select_clear() {
     B_lr1.setForeground( Color.BLACK );
     B_lr2.setForeground( Color.BLACK );
     B_lr5.setForeground( Color.BLACK );
     B_lr10.setForeground( Color.BLACK );
     B_lr20.setForeground( Color.BLACK );
     B_lr50.setForeground( Color.BLACK );
     B_lr100.setForeground( Color.BLACK );
     B_lr200.setForeground( Color.BLACK );
     B_lr500.setForeground( Color.BLACK );
     B_lr1000.setForeground( Color.BLACK );
//     B_lr2000.setForeground( Color.BLACK );
  }

  private void show_lr_select() {
      switch( Osci_logi.settings_prefer.logiana_sampling_rate )
      {
          case 1: B_lr1.setForeground( Color.ORANGE );break;
          case 2: B_lr2.setForeground( Color.ORANGE );break;
          case 5: B_lr5.setForeground( Color.ORANGE );break;
          case 10: B_lr10.setForeground( Color.ORANGE );break;
          case 20: B_lr20.setForeground( Color.ORANGE );break;
          case 50: B_lr50.setForeground( Color.ORANGE );break;
          case 100: B_lr100.setForeground( Color.ORANGE );break;
          case 200: B_lr200.setForeground( Color.ORANGE );break;
          case 500: B_lr500.setForeground( Color.ORANGE );break;
//          case 1000: B_lr1000.setForeground( Color.ORANGE );break;
          default:B_lr1000.setForeground( Color.ORANGE );break;
      }
  }

//  private int l_rate;
//  private int l_unit;

   private void B_lr1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 1;
           show_lr_select();

//           command.set_type = "LSRT";
//           command.set_data = "1";
//           tourokuAction_common();
   }                                           

  private void B_lr2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 2;
           show_lr_select();
//           B_lr2.setForeground( Color.ORANGE );

//           l_trigger_common();
//           command.set_type = "LSRT";
//           command.set_data = "2";
//           tourokuAction_common(); 
    }
    
  private void B_lr5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 5;
           show_lr_select();
//           B_lr5.setForeground( Color.ORANGE );

//           l_trigger_common();
//           command.set_type = "LSRT";
//           command.set_data = "5";
//           tourokuAction_common(); 
  }                                           

  private void B_lr10ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 10;
           show_lr_select();
//           B_lr10.setForeground( Color.ORANGE );
  }                                           

  private void B_lr20ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 20;
           show_lr_select();
//           B_lr20.setForeground( Color.ORANGE );
    }                                           


    private void B_lr50ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 50;
           show_lr_select();
//           B_lr50.setForeground( Color.ORANGE );
    }                                           

  private void B_lr100ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 100;
           show_lr_select();
//           B_lr100.setForeground( Color.ORANGE );
    }                                           
  
    private void B_lr200ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 200;
           show_lr_select();
//           B_lr200.setForeground( Color.ORANGE );
    }                                           
  
    private void B_lr500ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 500;
           show_lr_select();
//           B_lr500.setForeground( Color.ORANGE );
    }                                           

    
  private void B_lr1000ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 1000;
           show_lr_select();
//           B_lr1000.setForeground( Color.ORANGE );
    }                                           

  private void B_lr2000ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_clear();
           Osci_logi.settings_prefer.logiana_sampling_rate = 2000;
           show_lr_select();
//           B_lr2000.setForeground( Color.ORANGE );
    }                                           
  
  private String bit_string;
  private void bit_string_ope( int posi, char l)
  {
      String front = "";
      String rear = "";
      if( posi == 0)
      {
        front = "";
        rear = bit_string.substring( 1 );
      }
      if( posi == 15)
      {
        front = bit_string.substring( 0, 15 );
        rear = "";
      }
      else
      {
        front = bit_string.substring( 0, posi );
        rear = bit_string.substring( posi+1 );
      }
      bit_string = front.concat(String.valueOf(l));
      bit_string = bit_string.concat(rear);
  }
  
//  private int bit_posi( int l_ch )
//  {
////      0   1  2  3  4  5 
////   RB 0   1  4  5  7  8 9 15
////      15 14 11 10  8  7 6  0
//      int ret;
//      switch( l_ch )
//      {
//          case 0: ret = 15; break;
//          case 1: ret = 14; break;
//          case 2: ret = 11; break;
//          case 3: ret = 10; break;
//          case 4: ret = 8; break;
//          case 5: ret = 7; break;
//          case 6: ret = 6; break;
//          case 7:
//          default : ret = 0; break;
//      }
//      System.out.print( String.valueOf(l_ch) + " " + String.valueOf(ret)+"\n" );
//      return ret;
//  }

//  private void set_trig_timer()
//  {
//    command.set_type = "TTMR";
//    if( l_trig_cond == TRIG_OFF )
//    {
//        if( ( otrigcond != TRIG_OFF )||( otrigcond != TRIG_OFF ) )
//        {
//          command.set_data = "OSCI";
//        }
//        else
//        {
//          command.set_data = "NULL";
//        }
//    }
//    else if( ( otrigcond != TRIG_OFF )||( otrigcond != TRIG_OFF ) )
//    {
//      long l,o;
//      
//      l = Osci_logi.settings_prefer.logiana_sampling_rate;
//      l *= Osci_logi.settings_prefer.logiana_sampling_unit;
//      o = Osci_logi.settings_prefer.oscillo_sampling_rate;
//      o *= Osci_logi.settings_prefer.oscillo_sampling_unit;
//
//      if( l > o )
//      {
//        command.set_data = "LOGI";
//      }
//      else
//      {
//        command.set_data = "OSCI";
//      }
//    }
//    else
//    {
//      command.set_data = "LOGI";
//    }
//    tourokuAction_common();
//  }
  
//  private int trig_bit = 0;
//  private int mask_bit = 0;

//  private void l_trigger_common()
//  {
//    int bit_pattern;
//    
//        switch( Osci_logi.settings_prefer.logiana_sampling_rate )
//        {
//            case 1: B_lr1.setForeground( Color.ORANGE ); break;
//            case 2: B_lr2.setForeground( Color.ORANGE ); break;
//            case 5: B_lr5.setForeground( Color.ORANGE ); break;
//            case 10: B_lr10.setForeground( Color.ORANGE ); break;
//            case 20: B_lr20.setForeground( Color.ORANGE ); break;
//            case 50: B_lr50.setForeground( Color.ORANGE ); break;
//            case 100: B_lr100.setForeground( Color.ORANGE ); break;
//            case 200: B_lr200.setForeground( Color.ORANGE ); break;
//            case 500: B_lr500.setForeground( Color.ORANGE ); break;
//            case 1000: B_lr1000.setForeground( Color.ORANGE ); break;
//            case 2000: B_lr2000.setForeground( Color.ORANGE ); break;
//        }
//        
//        if( Osci_logi.settings_prefer.logiana_sampling_unit == Osci_logi.UNIT_kHZ )
//        {
//            B_lkHz.setForeground( Color.ORANGE );
//        }
//        else
//        {
//            B_lHz.setForeground( Color.ORANGE );
//        }
//    
//    if( l_trig_cond == Osci_logi.TRIG_OFF )
//    {
//        
//    }
//    else if( l_trig_cond == Osci_logi.PTRN_TRIG )
//    {
//      bit_string = "0000000000000000";
//      mask_bit = 0;
//      trig_bit = 0;
//      if( l_trig_0 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(0) , '1' );
//        bit_pattern = get_bit_pattern( 0 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_1 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(1) , '1' );
//        bit_pattern = get_bit_pattern( 1 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_2 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(2) , '1' );
//        bit_pattern = get_bit_pattern( 2 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_3 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(3) , '1' );
//        bit_pattern = get_bit_pattern( 3 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_4 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(4) , '1' );
//        bit_pattern = get_bit_pattern( 4 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_5 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(5) , '1' );
//        bit_pattern = get_bit_pattern( 5 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
////      command.set_type = "LPTN";
////      command.set_data = bit_string;
////      tourokuAction_common(); 
//      System.out.print("LPTN"+bit_string+"\n");
//      bit_string = "0000000000000000";
//      if( l_trig_0 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(0) , '1' );
//        bit_pattern = get_bit_pattern( 0 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_1 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(1) , '1' );
//        bit_pattern = get_bit_pattern( 1 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_2 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(2) , '1' );
//        bit_pattern = get_bit_pattern( 2 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_3 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(3) , '1' );
//        bit_pattern = get_bit_pattern( 3 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_4 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(4) , '1' );
//        bit_pattern = get_bit_pattern( 4 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_5 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(5) , '1' );
//        bit_pattern = get_bit_pattern( 5 );
//        mask_bit |= bit_pattern;
//      }
//      command.set_type = "LPMK";
//      command.set_data = bit_string;
//       
//       Osci_logi.settings_prefer.lptn  = trig_bit;
//       Osci_logi.settings_prefer.lpmk = mask_bit;
//    }
//    else   // l_trig_cond == BCHG_TRIG
//    {
////      bit_string = "abcdefghijklmnop";
//      bit_string = "0000000000000000";
//    if( l_trig_0 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(0) , '1' );
//        bit_pattern = get_bit_pattern( 0 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_1 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(1) , '1' );
//        bit_pattern = get_bit_pattern( 1 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_2 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(2) , '1' );
//        bit_pattern = get_bit_pattern( 2 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_3 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(3) , '1' );
//        bit_pattern = get_bit_pattern( 3 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_4 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(4) , '1' );
//        bit_pattern = get_bit_pattern( 4 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
//      if( l_trig_5 == TRIG_HI )
//      {
//        bit_string_ope( bit_posi(5) , '1' );
//        bit_pattern = get_bit_pattern( 5 );
//        mask_bit |= bit_pattern;
//        trig_bit |= bit_pattern;
//      }
////      command.set_type = "LCBT";
////      command.set_data = bit_string;
////      tourokuAction_common(); 
////      System.out.print("LCBT"+bit_string+"\n");
//
////      bit_string = "abcdefghijklmnop";
//      bit_string = "0000000000000000";
//    if( l_trig_0 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(0) , '1' );
//        bit_pattern = get_bit_pattern( 0 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_1 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(1) , '1' );
//        bit_pattern = get_bit_pattern( 1 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_2 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(2) , '1' );
//        bit_pattern = get_bit_pattern( 2 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_3 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(3) , '1' );
//        bit_pattern = get_bit_pattern( 3 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_4 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(4) , '1' );
//        bit_pattern = get_bit_pattern( 4 );
//        mask_bit |= bit_pattern;
//      }
//      if( l_trig_5 != Osci_logi.TRIG_OFF )
//      {
//        bit_string_ope( bit_posi(5) , '1' );
//        bit_pattern = get_bit_pattern( 5 );
//        mask_bit |= bit_pattern;
//      }
//
//    
//       Osci_logi.settings_prefer.lcbt = trig_bit;
//       Osci_logi.settings_prefer.lcmk = mask_bit;
//    }
////    set_trig_timer();
//  }

  private void logiana_trig_bit_operation(int ch, int hi_low)
  {
      int pattern;
      
      pattern = (1<<ch);
      
      if( ( hi_low == Osci_logi.TRIG_HI ) || ( hi_low == Osci_logi.TRIG_ON ) )
      {
        Osci_logi.settings_prefer.logiana_trig_bit_pattern |= pattern;
        Osci_logi.settings_prefer.logiana_trig_bit_mask &= ~pattern;
      }
      else if( hi_low == Osci_logi.TRIG_LOW )
      {
        Osci_logi.settings_prefer.logiana_trig_bit_pattern &= ~pattern;
        Osci_logi.settings_prefer.logiana_trig_bit_mask &= ~pattern;
      }
      else
      {
        Osci_logi.settings_prefer.logiana_trig_bit_pattern &= ~pattern;
        Osci_logi.settings_prefer.logiana_trig_bit_mask |= pattern;
      }
  }

  private int check_logiana_trig_bit(int ch )
  {
    int bit;
      
    bit = (1<<ch);
    
    if( l_trig_cond == Osci_logi.PTRN_TRIG )
    {
      if( ( Osci_logi.settings_prefer.logiana_trig_bit_mask & bit ) != 0 )
      {
        return Osci_logi.TRIG_OFF;
      }
      else if( ( Osci_logi.settings_prefer.logiana_trig_bit_pattern & bit ) != 0 )
      {
        return Osci_logi.TRIG_HI;
      }
      else
      {
        return Osci_logi.TRIG_LOW;
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGAND_TRIG )
    {
      if( ( Osci_logi.settings_prefer.logiana_trig_bit_mask & bit ) != 0 )
      {
        return Osci_logi.TRIG_OFF;
      }
      else
      {
        return Osci_logi.TRIG_ON;
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGOR_TRIG )
    {
      if( ( Osci_logi.settings_prefer.logiana_trig_bit_mask & bit ) != 0 )
      {
        return Osci_logi.TRIG_OFF;
      }
      else
      {
        return Osci_logi.TRIG_ON;
      }
    }
    else
    {
       return Osci_logi.TRIG_OFF;
    }
  }
  
  private void show_logiana_trig_bit( int ch )
  {
    javax.swing.JButton b_ltrig;
    int cond;
    
    switch( ch )
    {
        case 0:b_ltrig = B_ltrig0;break;
        case 1:b_ltrig = B_ltrig1;break;
        case 2:b_ltrig = B_ltrig2;break;
        case 3:b_ltrig = B_ltrig3;break;
        case 4:b_ltrig = B_ltrig4;break;
        case 5:b_ltrig = B_ltrig5;break;
        case 6:b_ltrig = B_ltrig6;break;
        case 7:b_ltrig = B_ltrig7;break;
        case 8:b_ltrig = B_ltrig8;break;
//        case 9:b_ltrig = B_ltrig9;break;
        default:b_ltrig = B_ltrig9;break;
    }
    
    cond = check_logiana_trig_bit( ch );
    if( l_trig_cond == Osci_logi.PTRN_TRIG )
    {
      if( cond == Osci_logi.TRIG_OFF )
      {
        b_ltrig.setText("Off");
      }
      else if(  cond == Osci_logi.TRIG_HI )
      {
        b_ltrig.setText("Hi");
      }
      else
      {
        b_ltrig.setText("Lo");
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGAND_TRIG )
    {
      if( cond  == Osci_logi.TRIG_OFF )
      {
        b_ltrig.setText("Off");
      }
      else
      {
        b_ltrig.setText("On");
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGOR_TRIG )
    {
      if( cond  == Osci_logi.TRIG_OFF )
      {
        b_ltrig.setText("Off");
      }
      else
      {
        b_ltrig.setText("On");
      }
    }
    else
    {
      b_ltrig.setText("----");
    }
  }

  private void show_logiana_trig_bit_all()
  {
     for( int i=0; i<Log_Data.LOGIANA_MAX_CH_COUNT; i++ )
     {
        show_logiana_trig_bit( i );
     }
  }
  
  private void ltrig_common( int ch )
  {
    int l_trig_mode;
    
    l_trig_mode = check_logiana_trig_bit( ch );
    if( l_trig_cond == Osci_logi.PTRN_TRIG )
    {
      if( l_trig_mode == Osci_logi.TRIG_OFF )
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_HI);
      }
      else if( l_trig_mode == Osci_logi.TRIG_HI )
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_LOW);
      }
      else
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_OFF);
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGAND_TRIG )
    {
      if( l_trig_mode  == Osci_logi.TRIG_OFF )
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_ON);
      }
      else
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_OFF);
      }
    }
    else if( l_trig_cond == Osci_logi.BCHGOR_TRIG )
    {
      if( l_trig_mode  == Osci_logi.TRIG_OFF )
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_ON);
      }
      else
      {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_OFF);
      }
    }
    else
    {
        logiana_trig_bit_operation( ch, Osci_logi.TRIG_OFF);
    }
    show_logiana_trig_bit( ch );
    
//    Debug.print("trig_bit_pattern=", Osci_logi.settings_prefer.logiana_trig_bit_pattern, "\n");
//    Debug.print("trig_bit_mask=", Osci_logi.settings_prefer.logiana_trig_bit_mask, "\n");
  }                                            
 
  private void B_ltrig0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch0.isSelected() )return;

    ltrig_common( 0 );
  }                                           

  private void B_ltrig1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch1 .isSelected() )return;
    ltrig_common( 1 );
  }                                           

  private void B_ltrig2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch2 .isSelected() )return;
    ltrig_common( 2 );
  }                                           

  private void B_ltrig3ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch3 .isSelected() )return;
    ltrig_common( 3 );
  }                                           

  private void B_ltrig4ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch4 .isSelected() )return;
    ltrig_common( 4 );
  }                                           

  private void B_ltrig5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !B_lch5 .isSelected() )return;
    ltrig_common( 5 );
  }                                           

  private int l_trig_cond;
  
  private void show_ltrig_cond()
  {
      if( l_trig_cond == Osci_logi.PTRN_TRIG )
      {
        B_ltrigcond.setText("PTRN");
        show_ltrig_mode();
      }
      else if( l_trig_cond == Osci_logi.BCHGAND_TRIG )
      {
        B_ltrigcond.setText("BCHG*");
        show_ltrig_mode();
      }
      else if( l_trig_cond == Osci_logi.BCHGOR_TRIG )
      {
        B_ltrigcond.setText("BCHG+");
        show_ltrig_mode();
      }
      else
      {
        B_ltrigcond.setText("OFF");
        B_ltrigmode.setText("OFF");
        B_ltriglink.setText("OFF");
      }
      show_logiana_trig_bit_all();
  }
  
  private void B_ltrigcondActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( l_trig_cond == Osci_logi.PTRN_TRIG )
      {
        l_trig_cond = Osci_logi.BCHGAND_TRIG;
      }
      else if( l_trig_cond == Osci_logi.BCHGAND_TRIG )
      {
        l_trig_cond = Osci_logi.BCHGOR_TRIG;
        Osci_logi.settings_prefer.trigger_link = Osci_logi.BCHGOR_TRIG;
      }
      else if( l_trig_cond == Osci_logi.BCHGOR_TRIG )
      {
        l_trig_cond = Osci_logi.TRIG_OFF;
        Osci_logi.settings_prefer.trigger_link = Osci_logi.TRIG_OFF;
      }
      else
      {
        l_trig_cond = Osci_logi.PTRN_TRIG;
        show_ltrig_mode();
        show_ltrig_link();
      }
      Osci_logi.settings_prefer.logiana_trig_mode = l_trig_cond;
      show_ltrig_cond();
  }
  
  private void och_select_common() {
      int count=0;
//      String s="";
      for( int i=0;i<Log_Data.OSCILLO_MAX_CH_COUNT;i++)
      {
      javax.swing.JButton btn;
          
        switch( i )
        {
            case 0: btn = B_och0;break;
            case 1: btn = B_och1;break;
            case 2: btn = B_och2;break;
            case 3:
            default:
                btn = B_och3;break;
        }
        
        if( Osci_logi.settings_prefer.get_oscillo_ch(i) )
        {
//          s += '1';
          count++;
          btn.setSelected(true);
          btn.setForeground( Color.ORANGE );
        }
        else
        {
//          s += '0';        
          btn.setSelected(false);
          btn.setForeground( Color.BLACK );
        }
      }
      if( count == 0 )
      {
        T_o_sample.setText("----");
        Osci_logi.current_log.oscillo_sampling_ch_count = 0; 
      }
      else if( count == 1 )
      {
        T_o_sample.setText("8192");
        Osci_logi.current_log.oscillo_sampling_ch_count = 1; 
      }
      else if( count == 2 )
      {
        T_o_sample.setText("4096");
        Osci_logi.current_log.oscillo_sampling_ch_count = 2; 
      }
      else
      {
        T_o_sample.setText("2048");
        Osci_logi.current_log.oscillo_sampling_ch_count = 4; 
      }
  }

  private void B_och0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( B_och0.isSelected() )
      {
        Osci_logi.settings_prefer.set_oscillo_ch(0,false);
      }
      else
      {
        Osci_logi.settings_prefer.set_oscillo_ch(0,true);
      }
      och_select_common();
    }                                           

  private void B_och1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( B_och1.isSelected() )
      {
        Osci_logi.settings_prefer.set_oscillo_ch(1,false);
      }
      else
      {
        Osci_logi.settings_prefer.set_oscillo_ch(1,true);
      }
      och_select_common();
    }
  
//  private void or_select_clear() {
//     B_or1.setForeground( Color.BLACK );
//     B_or2.setForeground( Color.BLACK );
//     B_or5.setForeground( Color.BLACK );
//     B_or10.setForeground( Color.BLACK );
//     B_or20.setForeground( Color.BLACK );
//     B_or50.setForeground( Color.BLACK );
//     B_or100.setForeground( Color.BLACK );
//     B_or200.setForeground( Color.BLACK );
//  }

    private void show_or_select() {
       B_or1.setForeground( Color.BLACK );
       B_or2.setForeground( Color.BLACK );
       B_or5.setForeground( Color.BLACK );
       B_or10.setForeground( Color.BLACK );
       B_or20.setForeground( Color.BLACK );
       B_or50.setForeground( Color.BLACK );
       B_or100.setForeground( Color.BLACK );
       B_or200.setForeground( Color.BLACK );
       B_or500.setForeground( Color.BLACK );
      switch( Osci_logi.settings_prefer.oscillo_sampling_rate )
      {
          case 1: B_or1.setForeground( Color.ORANGE );break;
          case 2: B_or2.setForeground( Color.ORANGE );break;
          case 5: B_or5.setForeground( Color.ORANGE );break;
          case 10: B_or10.setForeground( Color.ORANGE );break;
          case 20: B_or20.setForeground( Color.ORANGE );break;
          case 50: B_or50.setForeground( Color.ORANGE );break;
          case 100: B_or100.setForeground( Color.ORANGE );break;
          case 200: B_or200.setForeground( Color.ORANGE );break;
//          case 500: B_or500.setForeground( Color.ORANGE );break;
          default:B_or500.setForeground( Color.ORANGE );break;
      }
  }
 

  private int otrig_ch;
  private int otrig_up_down_off;
//  private int otrig_inout;
  private String limit_string;
  private int otrig_mode;

//  private void show_otrig_inout()
//  {
//      if( otrig_inout == Osci_logi.RANGE_IN )
//      {
//        B_otriginout.setText("IN");
//      }
//      else if( otrig_inout == Osci_logi.RANGE_OUT )
//      {
//        B_otriginout.setText("OUT");
//      }
//      else
//      {
//        B_otriginout.setText("OFF");
//      }
//  }

  private void set_otrig_up_down_off()
  {
//      new Exception("Stack trace").printStackTrace();
//      Debug.print("otrig_up_down_off=",otrig_up_down_off,"\n");
          

      if( otrig_up_down_off == Osci_logi.SELECT_OFF )
      {
        Osci_logi.settings_prefer.oscillo_trig_ch[otrig_ch] = false;
        Osci_logi.settings_prefer.oscillo_trig_up_down_off[otrig_ch] = Osci_logi.SELECT_OFF;
        B_otrigupdown.setText("OFF");
      }
      else if( otrig_up_down_off == Osci_logi.SELECT_UP )
      {
        Osci_logi.settings_prefer.oscillo_trig_ch[otrig_ch] = true;
        Osci_logi.settings_prefer.oscillo_trig_up_down_off[otrig_ch] = Osci_logi.SELECT_UP;
        B_otrigupdown.setText("UP");
      }
      else
      {
        Osci_logi.settings_prefer.oscillo_trig_ch[otrig_ch] = true;
        Osci_logi.settings_prefer.oscillo_trig_up_down_off[otrig_ch] = Osci_logi.SELECT_DOWN;
        B_otrigupdown.setText("DOWN");
      }
      set_trig_level_common(Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch]);
//      Debug.print("TEXT ",B_otrigupdown.getText(),"\n");
  }

//  private void B_otriginoutActionPerformed(java.awt.event.ActionEvent evt) {                                            
//        // TODO add your handling code here:
//      if( otrig_inout == Osci_logi.RANGE_IN )
//      {
//        otrig_inout = Osci_logi.RANGE_OUT;
//        Osci_logi.settings_prefer.oscillo_trig_ch[otrigsel_ch] = true;
//        Osci_logi.settings_prefer.oscillo_trig_in_out[otrigsel_ch] = Osci_logi.OUT_FLAG;
//      }
//      else if( otrig_inout == Osci_logi.RANGE_OUT )
//      {
//        otrig_inout = Osci_logi.TRIG_OFF;
//        Osci_logi.settings_prefer.oscillo_trig_ch[otrigsel_ch] = false;
//      }
//      else
//      {
//        otrig_inout = Osci_logi.RANGE_IN;
//        Osci_logi.settings_prefer.oscillo_trig_ch[otrigsel_ch] = true;
//        Osci_logi.settings_prefer.oscillo_trig_in_out[otrigsel_ch] = Osci_logi.IN_FLAG;
//      }
//      show_otrig_inout();
//    }                                           

  private int otrig_cond;
  
  private void show_otrig_cond()
  {
      if( otrig_cond == Osci_logi.TRIG_AND )
      {
        B_otrigcond.setText("AND");
      }
      else if( otrig_cond == Osci_logi.TRIG_OR )
      {
        B_otrigcond.setText("OR");
      }
      else
      {
        B_otrigcond.setText("OFF");
        B_otrigmode.setText("OFF");
        B_otriglink.setText("OFF");
      }
  }
  

  private void show_otrig_mode()
  {
      if( otrig_cond == Osci_logi.TRIG_OFF )
      {
        B_otrigmode.setText("OFF");
      }
      else if( otrig_mode == Osci_logi.START_TRIG )
      {
        B_otrigmode.setText("STRT");
      }
      else if( otrig_mode == Osci_logi.CENTER_TRIG )
      {
        B_otrigmode.setText("CNTR");
      }
      else
      {
        B_otrigmode.setText("END");
      }
  }
 
  private void B_hannpukuActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( Osci_logi.repeat_flag )
      {
        B_hannpuku.setForeground( Color.BLACK );
        Osci_logi.repeat_flag = false;
      }
      else
      {
        B_hannpuku.setForeground( Color.ORANGE );
        Osci_logi.repeat_flag = true;
      }
    }                                           

  private void B_shuuryouActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_jyusinn0ActionPerformed
        // TODO add your handling code here:
              Osci_logi.brk_flag = true;
    }//GEN-LAST:event_jB_jyusinn0ActionPerformed

    private void B_keisokuActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
        if( !meas_on_flag )
        {
          Osci_logi.send_flag = true;
          meas_on_flag = true;
        }
    }                                          

  private void B_tyuudanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_shuuryouActionPerformed
        // TODO add your handling code here:
        Osci_logi.send_brk_flag = true;
        Osci_logi.receive_flag = true;
        Osci_logi.receive_oscillo_flag = true;
        Osci_logi.receive_logiana_flag = true;
        Osci_logi.receive_parameter_flag = true;
    }//GEN-LAST:event_b_shuuryouActionPerformed

//    private void o_trig_common( int trig_sel )
//    {
//        switch( trig_sel )
//        {
//            case SELECT_MAX:
//                command.set_data = T_otrigmax.getText();
//                command.set_type = "O0UL";
//                break;
//            case SELECT_MIN:
//                command.set_data = T_otrigmin.getText();
//                command.set_type = "O1UL";
//                break;
//        }
////        tourokuAction_common(); 
//    }
        
    private void B_lHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lHzActionPerformed
        // TODO add your handling code here:
           B_lkHz.setForeground( Color.BLACK );
           B_lHz.setForeground( Color.ORANGE );
           Osci_logi.settings_prefer.logiana_sampling_unit = Osci_logi.UNIT_HZ;
    }//GEN-LAST:event_B_lHzActionPerformed

    private void B_lkHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lkHzActionPerformed
        // TODO add your handling code here:
           B_lkHz.setForeground( Color.ORANGE );
           B_lHz.setForeground( Color.BLACK );
           Osci_logi.settings_prefer.logiana_sampling_unit = Osci_logi.UNIT_kHZ;
    }//GEN-LAST:event_B_lkHzActionPerformed

//  private void B_otrigselminActionPerformed(java.awt.event.ActionEvent evt) {                                            
//        // TODO add your handling code here:
//      B_otrigselmax.setText("   ");
//      if( otrigsel == CH0_MIN )
//      {
//        otrigsel = CH1_MIN;
//        B_otrigselmin.setText("==>");
//        limit_string = T_otrig1min.getText();
//        set_slider_common();
//      }
//      else if( otrigsel == CH1_MIN )
//      {
//        otrigsel = MIN_OFF;
//        B_otrigselmin.setText("   ");
//      }
//      else
//      {
//        otrigsel = CH0_MIN;
//        B_otrigselmin.setText("<==");
//        limit_string = T_otrig0min.getText();
//        set_slider_common();
//      }
//    }
   
    private void set_slider_common()
    {
      int slider_posi;
      slider_posi = get_value(limit_string,0);
      hBar.setMaximum(1023);
      hBar.setMinimum(0);
      hBar.setValue(slider_posi);
    }
        
    boolean Oscillo_Button_flag;
    boolean Logiana_Button_flag;
    boolean Window_1_Button_flag;
    boolean Window_2_Button_flag;
    boolean Window_3_Button_flag;
    boolean Window_4_Button_flag;
    
    private void remove_operation()
    {
        Console_Panel.removeAll();
        if(Oscillo_Button_flag)
        {
          Oscillo_Button.setForeground(Color.BLACK);
          Oscillo_Button_flag = false;
        }
        else if(Logiana_Button_flag)
        {
          Logiana_Button.setForeground(Color.BLACK);
          Logiana_Button_flag = false;
        }
        else if(Window_1_Button_flag)
        {
          Window_1_Button.setForeground(Color.BLACK);
          Window_1_Button_flag = false;
        }
        else if(Window_2_Button_flag)
        {
          Window_2_Button.setForeground(Color.BLACK);
          Window_2_Button_flag = false;
        }
        else if(Window_3_Button_flag)
        {
          Window_3_Button.setForeground(Color.BLACK);
          Window_3_Button_flag = false;
        }
        else if(Window_4_Button_flag)
        {
          Window_4_Button.setForeground(Color.BLACK);
          Window_4_Button_flag = false;
        }
    }
    
    private void remove_Console_Panel()
    {
       Console_Panel.removeAll();
       Oscillo_Button_flag = false;
       Logiana_Button_flag = false;
       Window_1_Button_flag = false;
       Window_2_Button_flag = false;
       Window_3_Button_flag = false;
       Window_4_Button_flag = false;
    };

    private void Oscillo_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Oscillo_ButtonActionPerformed
        // TODO add your handling code here:
        if( Oscillo_Button_flag )
        {
          Console_Panel.remove(Oscillo_console);
          Oscillo_Button.setForeground(Color.BLACK);
          Oscillo_Button_flag = false;
          Oscillo_console.setVisible(false);
          Console_Panel.revalidate();
          Console_Panel.repaint();
        }
        else
        {
          remove_operation();
          och_select_common();
          
          show_or_select();
          if( Osci_logi.settings_prefer.oscillo_sampling_unit == Osci_logi.UNIT_kHZ )
          {
            B_okHz.setForeground( Color.ORANGE );
            B_oHz.setForeground( Color.BLACK );
          }
          else
          {
            B_okHz.setForeground( Color.BLACK );
            B_oHz.setForeground( Color.ORANGE );
          }

          otrig_ch = 0;
          jTrigger_CB.setSelectedIndex(0);
          otrig_up_down_off = Osci_logi.settings_prefer.oscillo_trig_up_down_off[otrig_ch];
          
          limit_string = Integer.toString(Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch]);
          T_otriglevel.setText(limit_string);
          set_otrig_up_down_off();
//          show_otrig_inout();

          otrig_mode  = Osci_logi.settings_prefer.oscillo_trigger_mode;
          show_otrig_mode();

          otrig_cond = Osci_logi.settings_prefer.oscillo_trig_cond;
          show_otrig_cond();

          
          otrig_link = Osci_logi.settings_prefer.trigger_link;
          show_otrig_link();

          Oscillo_Button.setForeground(Color.ORANGE);
          Oscillo_Button_flag = true;
          
          otrig_up_down_off = Osci_logi.SELECT_UP;
          limit_string = T_otriglevel.getText();
          set_slider_common();        
          Oscillo_console.setVisible(true);
          Console_Panel.add(Oscillo_console);
          Console_Panel.revalidate();
          Console_Panel.repaint();
        }
    }//GEN-LAST:event_Oscillo_ButtonActionPerformed

//    public void update_selectable_ch()
//    {
//        if( window.oscillo_ch_selectable[0] )
//        {
//          window.och0_flag = RB_OCH0.isSelected();
//        }
//        else
//        {
//          RB_OCH0.setSelected(false);
//          window.och0_flag = false;
//        }
//        
//        if( window.oscillo_ch_selectable[1] )
//        {
//          window.och1_flag = RB_OCH1.isSelected();
//        }
//        else
//        {
//          RB_OCH1.setSelected(false);
//          window.och1_flag = false;
//        }
//        
//        if( window.oscillo_ch_selectable[2] )
//        {
//          window.och2_flag = RB_OCH2.isSelected();
//        }
//        else
//        {
//          RB_OCH2.setSelected(false);
//          window.och2_flag = false;
//        }
//        
//        if( window.oscillo_ch_selectable[3] )
//        {
//          window.och3_flag = RB_OCH3.isSelected();
//        }
//        else
//        {
//          RB_OCH3.setSelected(false);
//          window.och3_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[0] )
//        {
//          window.lch0_flag = RB_LCH0.isSelected();
//        }
//        else
//        {
//          RB_LCH0.setSelected(false);
//          window.lch0_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[1] )
//        {
//          window.lch1_flag = RB_LCH1.isSelected();
//        }
//        else
//        {
//          RB_LCH1.setSelected(false);
//          window.lch1_flag = false;
//        }
//
//        if( window.logiana_ch_selectable[2] )
//        {
//          window.lch2_flag = RB_LCH2.isSelected();
//        }
//        else
//        {
//          RB_LCH2.setSelected(false);
//          window.lch2_flag = false;
//        }
//
//        if( window.logiana_ch_selectable[3] )
//        {
//          window.lch3_flag = RB_LCH3.isSelected();
//        }
//        else
//        {
//          RB_LCH3.setSelected(false);
//          window.lch3_flag = false;
//        }
//                
//        if( window.logiana_ch_selectable[4] )
//        {
//          window.lch4_flag = RB_LCH4.isSelected();
//        }
//        else
//        {
//          RB_LCH4.setSelected(false);
//          window.lch4_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[5] )
//        {
//          window.lch5_flag = RB_LCH5.isSelected();
//        }
//        else
//        {
//          RB_LCH5.setSelected(false);
//          window.lch5_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[6] )
//        {
//          window.lch6_flag = RB_LCH6.isSelected();
//        }
//        else
//        {
//          RB_LCH6.setSelected(false);
//          window.lch6_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[7] )
//        {
//          window.lch7_flag = RB_LCH7.isSelected();
//        }
//        else
//        {
//          RB_LCH7.setSelected(false);
//          window.lch7_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[8] )
//        {
//          window.lch8_flag = RB_LCH8.isSelected();
//        }
//        else
//        {
//          RB_LCH8.setSelected(false);
//          window.lch8_flag = false;
//        }
//        
//        if( window.logiana_ch_selectable[9] )
//        {
//          window.lch9_flag = RB_LCH9.isSelected();
//        }
//        else
//        {
//          RB_LCH9.setSelected(false);
//          window.lch9_flag = false;
//        }
//    }
    
    private void RB_OCH0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_OCH0ActionPerformed
        // TODO add your handling code here:
        if( window.oscillo_ch_selectable[0] )
        {
          window.och0_flag = RB_OCH0.isSelected();
        }
        else
        {
          RB_OCH0.setSelected(false);
          window.och0_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_OCH0ActionPerformed

    private void RB_LCH0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH0ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[0] )
        {
          window.lch0_flag = RB_LCH0.isSelected();
        }
        else
        {
          RB_LCH0.setSelected(false);
          window.lch0_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH0ActionPerformed

    private void RB_LCH2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH2ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[2] )
        {
          window.lch2_flag = RB_LCH2.isSelected();
        }
        else
        {
          RB_LCH2.setSelected(false);
          window.lch2_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH2ActionPerformed

    private void RB_LCH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH1ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[1] )
        {
          window.lch1_flag = RB_LCH1.isSelected();
        }
        else
        {
          RB_LCH1.setSelected(false);
          window.lch1_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH1ActionPerformed

    private void RB_LCH3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH3ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[3] )
        {
          window.lch3_flag = RB_LCH3.isSelected();
        }
        else
        {
          RB_LCH3.setSelected(false);
          window.lch3_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH3ActionPerformed

    private void RB_LCH6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH6ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[6] )
        {
          window.lch6_flag = RB_LCH6.isSelected();
        }
        else
        {
          RB_LCH6.setSelected(false);
          window.lch6_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH6ActionPerformed

    private void RB_LCH4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH4ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[4] )
        {
          window.lch4_flag = RB_LCH4.isSelected();
        }
        else
        {
          RB_LCH4.setSelected(false);
          window.lch4_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH4ActionPerformed

    private void RB_LCH7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH7ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[7] )
        {
          window.lch7_flag = RB_LCH7.isSelected();
        }
        else
        {
          RB_LCH7.setSelected(false);
          window.lch7_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH7ActionPerformed

    private void RB_LCH8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH8ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[8] )
        {
          window.lch8_flag = RB_LCH8.isSelected();
        }
        else
        {
          RB_LCH8.setSelected(false);
          window.lch8_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH8ActionPerformed

    private void RB_LCH9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH9ActionPerformed
        // TODO add your handling code here:
        window.lch9_flag = RB_LCH9.isSelected();
        if( window.logiana_ch_selectable[9] )
        {
          window.lch9_flag = RB_LCH9.isSelected();
        }
        else
        {
          RB_LCH9.setSelected(false);
          window.lch9_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH9ActionPerformed

    private void RB_LCH5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_LCH5ActionPerformed
        // TODO add your handling code here:
        if( window.logiana_ch_selectable[5] )
        {
          window.lch5_flag = RB_LCH5.isSelected();
        }
        else
        {
          RB_LCH5.setSelected(false);
          window.lch5_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_LCH5ActionPerformed

    private void Logiana_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Logiana_ButtonActionPerformed
        // TODO add your handling code here:
        if( Logiana_Button_flag )
        {
          Console_Panel.remove(Logiana_console);
          Logiana_console.setVisible(false);
          Console_Panel.revalidate();
          Console_Panel.repaint();

          Logiana_Button.setForeground(Color.BLACK);
          Logiana_Button_flag = false;
        }
        else
        {
          remove_operation();
          if( Osci_logi.settings_prefer.get_logiana_ch( 0 ) )
          {
             Logiana_ALL_ON_OFF( true );
          }
          else
          {
             Logiana_ALL_ON_OFF( false );
          }

          show_lr_select();
          
           if( Osci_logi.settings_prefer.logiana_sampling_unit == Osci_logi.UNIT_kHZ )
           {
              B_lkHz.setForeground( Color.ORANGE );
              B_lHz.setForeground( Color.BLACK );
           }
           else
           {
              B_lkHz.setForeground( Color.BLACK );
              B_lHz.setForeground( Color.ORANGE );
           }

           show_logiana_trig_bit_all();

          l_trig_cond = Osci_logi.settings_prefer.logiana_trig_mode;
          show_ltrig_cond();
          
          ltrig_mode = Osci_logi.settings_prefer.logiana_trigger_mode;
          show_ltrig_mode();

          ltrig_link = Osci_logi.settings_prefer.trigger_link;
          show_ltrig_link();

//          lr_select_common();
//          l_trigger_common();

          Logiana_console.setVisible(true);
          Console_Panel.add(Logiana_console);
          Console_Panel.revalidate();
          Console_Panel.repaint();
          Logiana_Button.setForeground(Color.ORANGE);
          Logiana_Button_flag = true;
        }
    }//GEN-LAST:event_Logiana_ButtonActionPerformed

    public void select_flag_update()
    {
          RB_OCH0.setSelected(window.och0_flag);
          RB_OCH1.setSelected(window.och1_flag);
          RB_OCH2.setSelected(window.och2_flag);
          RB_OCH3.setSelected(window.och3_flag);
          RB_LCH0.setSelected(window.lch0_flag);
          RB_LCH1.setSelected(window.lch1_flag);
          RB_LCH2.setSelected(window.lch2_flag);
          RB_LCH3.setSelected(window.lch3_flag);
          RB_LCH4.setSelected(window.lch4_flag);
          RB_LCH5.setSelected(window.lch5_flag);
          RB_LCH6.setSelected(window.lch6_flag);
          RB_LCH7.setSelected(window.lch7_flag);
          RB_LCH8.setSelected(window.lch8_flag);
          RB_LCH9.setSelected(window.lch9_flag);
    }
    
    private void window_button_common( Window w, String s, javax.swing.JButton b) {
          Window_console.setVisible(true);
          Window_Label.setText( s );
          window = w;
          
          if( window.v_flag )
          {
            B_VIEW.setText("表示");
          }
          else
          {
            B_VIEW.setText("非表示");
          }
          
          if( window.hold_flag )
          {
            jB_update.setText("保持");
          }
          else
          {
            jB_update.setText("更新");
          }
          
          window.set_ch_selectable_flag();
          select_flag_update();
          
          if( window.window_height == Window.Q_SIZE )
          {
              RB_S14.setSelected(true);
          }
          else if( window.window_height == Window.H_SIZE )
          {
              RB_S12.setSelected(true);
          }
          else if( window.window_height == Window.F_SIZE )
          {
              RB_S11.setSelected(true);
          }
          else
          {
              RB_S14.setSelected(true);
              window.window_height = Window.Q_SIZE;
          }
          
          if( window.y_posi == Window.Top_POSI )
          {
            RB_POSI_U.setSelected(true);
          }
          else if( window.y_posi == Window.Snd_POSI )
          {
            RB_POSI_UM.setSelected(true);
          }
          else if( window.y_posi == Window.Trd_POSI )
          {
            RB_POSI_LM.setSelected(true);
          }
          else if( window.y_posi == Window.Btm_POSI )
          {
            RB_POSI_L.setSelected(true);
          }
          else
          {
            RB_POSI_U.setSelected(true);
            window.y_posi = Window.Top_POSI;            
          }
          
          set_TF_H( window.h_scale );
          
          window.update_s_t_e();
          window.set_draw_parameter();
          update_slider();
          set_display_position(window.draw_left_posi);
          set_cursor_position(window.cursor_posi);
          ltrig_link = Osci_logi.settings_prefer.trigger_link;
          show_ltrig_link();
        
          Console_Panel.add(Window_console);
          Console_Panel.revalidate();

          Console_Panel.repaint();
          b.setForeground(Color.ORANGE);
    }
    
    private void Window_1_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Window_1_ButtonActionPerformed
        // TODO add your handling code here:
        remove_operation();
        if( Window_1_Button_flag )
        {
          Window_1_Button_flag = false;
          Console_Panel.remove(Window_console);
          Window_1_Button.setForeground(Color.BLACK);
          Console_Panel.revalidate();
          Console_Panel.repaint();
        }
        else
        {
          window_button_common( window1, "Window1", Window_1_Button);
          Window_1_Button_flag = true;
        }
    }//GEN-LAST:event_Window_1_ButtonActionPerformed

    private void Window_2_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Window_2_ButtonActionPerformed
        // TODO add your handling code here:
        remove_operation();
        if( Window_2_Button_flag )
        {
          Window_2_Button_flag = false;
          Console_Panel.remove(Window_console);
          Window_2_Button.setForeground(Color.BLACK);
          Console_Panel.revalidate();
          Console_Panel.repaint();
        }
        else
        {
          window_button_common( window2, "Window2", Window_2_Button);
          Window_2_Button_flag = true;
        }
    }//GEN-LAST:event_Window_2_ButtonActionPerformed

    private void Window_3_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Window_3_ButtonActionPerformed
        // TODO add your handling code here:
        remove_operation();
        if( Window_3_Button_flag )
        {
          Window_3_Button_flag = false;
          Console_Panel.remove(Window_console);
          Window_3_Button.setForeground(Color.BLACK);
          Console_Panel.revalidate();
          Console_Panel.repaint();

//
//          Console_Panel.remove(Window_console);
//          Window_console.setVisible(true);
//          Window_3_Button.setForeground(Color.BLACK);
//          Window_3_Button_flag = false;
        }
        else
        {
          window_button_common( window3, "Window3", Window_3_Button);
          Window_3_Button_flag = true;
        }
    }//GEN-LAST:event_Window_3_ButtonActionPerformed

    private void Window_4_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Window_4_ButtonActionPerformed
        // TODO add your handling code here:
        remove_operation();
        if( Window_4_Button_flag )
        {
          Window_4_Button_flag = false;
          Console_Panel.remove(Window_console);
          Window_4_Button.setForeground(Color.BLACK);
          Console_Panel.revalidate();
          Console_Panel.repaint();

//          Console_Panel.remove(Window_console);
//          Window_4_Button.setForeground(Color.BLACK);
//          Window_4_Button_flag = false;
        }
        else
        {
          window_button_common( window4, "Window4", Window_4_Button);
          Window_4_Button_flag = true;
        }
    }//GEN-LAST:event_Window_4_ButtonActionPerformed

    private void check_redraw()
    {
      if( window.v_flag )
      {
//        update_canvas = true;
          Redraw_Window();
      }
    }
    
    private void RB_POSI_UActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_POSI_UActionPerformed
        // TODO add your handling code here:
        window.top_posi();
    }//GEN-LAST:event_RB_POSI_UActionPerformed

    private void RB_OCH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_OCH1ActionPerformed
        // TODO add your handling code here:
        if( window.oscillo_ch_selectable[1] )
        {
          window.och1_flag = RB_OCH1.isSelected();
        }
        else
        {
          RB_OCH1.setSelected(false);
          window.och1_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_OCH1ActionPerformed

    private void B_VIEWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_VIEWActionPerformed
        // TODO add your handling code here:
        if( window.v_flag == false )
        {
            window.v_flag = true;
            B_VIEW.setText("表示");
            window.redraw = true;
        }
        else
        {
            window.v_flag = false;
            B_VIEW.setText("非表示");
        }
        update_canvas = true;
    }//GEN-LAST:event_B_VIEWActionPerformed

    private void RB_S14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_S14ActionPerformed
        // TODO add your handling code here:
        window.set_height_14();
        check_redraw();
    }//GEN-LAST:event_RB_S14ActionPerformed

    private void RB_S12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_S12ActionPerformed
        // TODO add your handling code here:
        window.set_height_12();
        check_redraw();
    }//GEN-LAST:event_RB_S12ActionPerformed

    private void RB_S11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_S11ActionPerformed
        // TODO add your handling code here:
        window.set_height_11();
        check_redraw();
    }//GEN-LAST:event_RB_S11ActionPerformed

    private String get_scale_text(int scale)
    {
      String s = "";
      switch(scale){
            case Window.SCALE_1_1: s = "１／１"; break;
            case Window.SCALE_2_1: s = "２／１"; break;
            case Window.SCALE_4_1: s = "４／１"; break;
            case Window.SCALE_8_1: s = "８／１"; break;
            case Window.SCALE_1_2: s = "１／２"; break;
            case Window.SCALE_1_4: s = "１／４"; break;
            case Window.SCALE_1_8: s = "１／８"; break;
      }
      return s;
    }
       
    public void set_TF_H( int scale )
    {
      TF_H.setText(get_scale_text(scale));
    }

    private void B_H_LEFTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_H_LEFTActionPerformed
        // TODO add your handling code here:
        switch( window.h_scale )
        {
            case Window.SCALE_1_1: window.h_scale = Window.SCALE_1_2; break;
            case Window.SCALE_2_1: window.h_scale = Window.SCALE_1_1; break;
            case Window.SCALE_4_1: window.h_scale = Window.SCALE_2_1; break;
            case Window.SCALE_8_1: window.h_scale = Window.SCALE_4_1; break;
            case Window.SCALE_1_2: window.h_scale = Window.SCALE_1_4; break;
            case Window.SCALE_1_4: window.h_scale = Window.SCALE_1_8; break;
            default: window.h_scale = Window.SCALE_1_1; break;
        }
        set_TF_H( window.h_scale );
        window.update_draw_range();
        get_display_position();
        check_redraw();
    }//GEN-LAST:event_B_H_LEFTActionPerformed

    private void R_H_RIGHTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_R_H_RIGHTActionPerformed
        // TODO add your handling code here:
        switch( window.h_scale )
        {
            case Window.SCALE_1_1: window.h_scale = Window.SCALE_2_1; break;
            case Window.SCALE_2_1: window.h_scale = Window.SCALE_4_1; break;
            case Window.SCALE_4_1: window.h_scale = Window.SCALE_8_1; break;
            case Window.SCALE_1_2: window.h_scale = Window.SCALE_1_1; break;
            case Window.SCALE_1_4: window.h_scale = Window.SCALE_1_2; break;
            case Window.SCALE_1_8: window.h_scale = Window.SCALE_1_4; break;
            default: window.h_scale = Window.SCALE_1_1; TF_H.setText("１／１"); break;
        }
        set_TF_H( window.h_scale );
        window.update_draw_range();
        get_display_position();
        check_redraw();
    }//GEN-LAST:event_R_H_RIGHTActionPerformed

    public void update_slider()
    {
        skip_flag = true;
        Cursor_Position.setMaximum(window.draw_max_posi);
        Cursor_Position.setMinimum(window.draw_min_posi);
        
        Display_Position.setMaximum(window.draw_max_posi - window.draw_range);
        Display_Position.setMinimum(window.draw_min_posi);
        skip_flag = false;
    }
    
    
//    private void window_type_common()
//    {
//        if( window.type_flag == Window.LOGIANA_TYPE )
//        {
//            window.draw_logiana_mode();
//        }
//        else
//        {
//            window.draw_oscillo_mode();
//        }
        
//        Cursor_Position.setMaximum(window.draw_max_posi);
//        Cursor_Position.setMinimum(window.draw_min_posi);
//        
//        Display_Position.setMaximum(window.draw_max_posi - window.draw_range);
//        Display_Position.setMinimum(window.draw_min_posi);
//    }

    private void window_type_change()
    {
        if( window.type_flag == Window.LOGIANA_TYPE )
        {
            window.type_flag = Window.OSCILLO_TYPE;
            B_Type.setText("Oscillo Type");
        }
        else
        {
            window.type_flag = Window.LOGIANA_TYPE;
            B_Type.setText("Logiana Type");
        }
        
        window.set_draw_parameter();
        update_slider();
    }

    private void B_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_TypeActionPerformed
        // TODO add your handling code here:
        window_type_change();
        get_display_position();
        check_redraw();
    }//GEN-LAST:event_B_TypeActionPerformed

    private void RB_POSI_UMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_POSI_UMActionPerformed
        // TODO add your handling code here:
        window.second_posi();
        check_redraw();
    }//GEN-LAST:event_RB_POSI_UMActionPerformed

    private void RB_POSI_LMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_POSI_LMActionPerformed
        // TODO add your handling code here:
        window.third_posi();
        check_redraw();
    }//GEN-LAST:event_RB_POSI_LMActionPerformed

    private void RB_POSI_LActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_POSI_LActionPerformed
        // TODO add your handling code here:
        window.bottom_posi();
        check_redraw();
    }//GEN-LAST:event_RB_POSI_LActionPerformed

    private void B_lch6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lch6ActionPerformed
        // TODO add your handling code here:
        if( B_lch6.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }//GEN-LAST:event_B_lch6ActionPerformed

    private void B_lch7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lch7ActionPerformed
        // TODO add your handling code here:
        if( B_lch7.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }//GEN-LAST:event_B_lch7ActionPerformed

    private void B_lch8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lch8ActionPerformed
        // TODO add your handling code here:
        if( B_lch8.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }//GEN-LAST:event_B_lch8ActionPerformed

    private void B_lch9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lch9ActionPerformed
        // TODO add your handling code here:
        if( B_lch9.isSelected() )
        {
           Logiana_ALL_ON_OFF( false );
        }
        else
        {
           Logiana_ALL_ON_OFF( true );
        }
    }//GEN-LAST:event_B_lch9ActionPerformed

    private void Logiana_Color( Color c)
    {
        B_lch0.setForeground( c );
        B_lch1.setForeground( c );
        B_lch2.setForeground( c );
        B_lch3.setForeground( c );
        B_lch4.setForeground( c );
        B_lch5.setForeground( c );
        B_lch6.setForeground( c );
        B_lch7.setForeground( c );
        B_lch8.setForeground( c );
        B_lch9.setForeground( c );
    }
    
    private void Logiana_ALL_ON_OFF(boolean flag)
    {
           B_lch0.setSelected(flag);
           B_lch1.setSelected(flag);
           B_lch2.setSelected(flag);
           B_lch3.setSelected(flag);
           B_lch4.setSelected(flag);
           B_lch5.setSelected(flag);
           B_lch6.setSelected(flag);
           B_lch7.setSelected(flag);
           B_lch8.setSelected(flag);
           B_lch9.setSelected(flag);
           
           Osci_logi.settings_prefer.set_logiana_ch( 0, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 1, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 2, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 3, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 4, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 5, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 6, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 7, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 8, flag);          
           Osci_logi.settings_prefer.set_logiana_ch( 9, flag);          

           if( flag )
           {
               Logiana_Color( Color.ORANGE );
               T_l_sample.setText("4096");
               Osci_logi.current_log.logiana_sampling_ch_count = 10; 
           }           
           else
           {
               Logiana_Color( Color.BLACK );
               T_l_sample.setText("----");
               Osci_logi.current_log.logiana_sampling_ch_count = 0; 
           }
    }
    
    
//     public static boolean[] oscillo_ch_selectable = new boolean[Log_Data.OSCILLO_MAX_CH_COUNT];
//     public static boolean[] logiana_ch_selectable = new boolean[Log_Data.LOGIANA_MAX_CH_COUNT];

//    public void set_logiana_button_selectable(int ch, boolean flag)
//    {
//    switch(ch)
//    {
//        case 0:
//            RB_LCH0.setSelected(flag);
//            break;
//        case 1:
//            RB_LCH1.setSelected(flag);
//            break;
//        case 2:
//            RB_LCH2.setSelected(flag);
//            break;
//        case 3:
//            RB_LCH3.setSelected(flag);
//            break;
//        case 4:
//            RB_LCH4.setSelected(flag);
//            break;
//        case 5:
//            RB_LCH5.setSelected(flag);
//            break;
//        case 6:
//            RB_LCH6.setSelected(flag);
//            break;
//        case 7:
//            RB_LCH7.setSelected(flag);
//            break;
//        case 8:
//            RB_LCH8.setSelected(flag);
//            break;
//        case 9:
//            RB_LCH9.setSelected(flag);
//            break;
//      }
//
//      if( window != null )
//      {
//        window.set_logiana_ch_flag(ch,flag);
//      }
//    }

//    public void set_oscillo_button_selectable(int ch, boolean flag)
//    {
//    switch(ch)
//    {
//        case 0:
//            RB_OCH0.setSelected(flag);
//            break;
//        case 1:
//            RB_OCH1.setSelected(flag);
//            break;
//        case 2:
//            RB_OCH2.setSelected(flag);
//            break;
//        case 3:
//            RB_OCH3.setSelected(flag);
//            break;
//      }
//      if(window != null )
//      {
//        window.set_oscillo_ch_flag(ch,flag);
//      }
//    }
    
    private void B_ltrig6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltrig6ActionPerformed
        // TODO add your handling code here:
        if (!B_lch6.isSelected())return;
        ltrig_common( 6 );
    }//GEN-LAST:event_B_ltrig6ActionPerformed

    private void B_ltrig7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltrig7ActionPerformed
        // TODO add your handling code here:
        if (!B_lch7.isSelected()) return;

        ltrig_common( 7 );
    }//GEN-LAST:event_B_ltrig7ActionPerformed

    private void B_ltrig8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltrig8ActionPerformed
        // TODO add your handling code here:
        if (!B_lch8.isSelected()) {
            return;
        }
        ltrig_common( 8 );
    }//GEN-LAST:event_B_ltrig8ActionPerformed

    private void B_ltrig9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltrig9ActionPerformed
        // TODO add your handling code here:
        if (!B_lch9.isSelected()) {
            return;
        }
        ltrig_common( 9 );
    }//GEN-LAST:event_B_ltrig9ActionPerformed

    private void RB_OCH2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_OCH2ActionPerformed
        // TODO add your handling code here:
        if( window.oscillo_ch_selectable[2] )
        {
          window.och2_flag = RB_OCH2.isSelected();
        }
        else
        {
          RB_OCH2.setSelected(false);
          window.och2_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_OCH2ActionPerformed

    private void RB_OCH3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_OCH3ActionPerformed
        // TODO add your handling code here:
        if( window.oscillo_ch_selectable[3] )
        {
          window.och3_flag = RB_OCH3.isSelected();
        }
        else
        {
          RB_OCH3.setSelected(false);
          window.och3_flag = false;
        }
        check_redraw();
    }//GEN-LAST:event_RB_OCH3ActionPerformed

    private void T_l_sampleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_l_sampleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_l_sampleActionPerformed
    

    private void TF_Disp_Posi_MinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF_Disp_Posi_MinActionPerformed
        // TODO add your handling code here:
//        int i = Integer.parseInt(TF_Disp_Posi_Min.getText());
        int i = get_value(TF_Disp_Posi_Min.getText(),window.draw_left_posi);
        set_left_position( i );
        Display_Position.setValue( window.draw_left_posi );
    }//GEN-LAST:event_TF_Disp_Posi_MinActionPerformed

//    private void update_Min_Max()
//    {
//        TF_Disp_Posi_Min.setText(String.valueOf(window.draw_left_posi));
//        TF_Disp_Posi_Max.setText(String.valueOf(window.draw_right_posi));
//    }
//    
//    private void calc_window_offset()
//    {
//        int value;
//        value = Display_Position.getValue();
//        
//        window.draw_left_posi = value;
//        window.draw_right_posi = value + window.draw_range;
//
//        if( window.draw_left_posi < window.draw_min_posi )
//        {
//          Debug.print("draw_left_posi:", window.draw_left_posi, "<");
//          Debug.print("draw_min_posi:", window.draw_min_posi, "\n");
//            
//          window.draw_left_posi = window.draw_min_posi;
//          window.draw_right_posi = window.draw_left_posi + window.draw_range;
//          if( window.draw_right_posi > window.draw_max_posi )
//          {
//            window.draw_right_posi = window.draw_max_posi;
//          }
//        }
//        else if( window.draw_right_posi > window.draw_max_posi )
//        {
//          Debug.print("draw_right_posi:", window.draw_right_posi, ">");
//          Debug.print("draw_max_posi:", window.draw_max_posi, "\n");
//          window.draw_right_posi = window.draw_max_posi;
//          window.draw_left_posi = window.draw_right_posi - window.draw_range;
//          if( window.draw_left_posi < window.draw_min_posi )
//          {
//            window.draw_left_posi = window.draw_min_posi;
//          }
//        }
//
//    }

    private void check_position()
    {
        if( window.draw_left_posi < window.draw_min_posi )
        {
          window.draw_left_posi = window.draw_min_posi;
          window.draw_right_posi = window.draw_left_posi + window.draw_range;
          if( window.draw_right_posi > window.draw_max_posi )
          {
            window.draw_right_posi = window.draw_max_posi;
          }
        }
        else if( window.draw_right_posi > window.draw_max_posi )
        {
          window.draw_right_posi = window.draw_max_posi;
          window.draw_left_posi = window.draw_right_posi - window.draw_range;
          if( window.draw_left_posi < window.draw_min_posi )
          {
            window.draw_left_posi = window.draw_min_posi;
          }
        }
        TF_Disp_Posi_Min.setText(String.valueOf(window.draw_left_posi));
        TF_Disp_Posi_Max.setText(String.valueOf(window.draw_right_posi));
//        Debug.print("update_data_position", "","\n");
//        Debug.print("draw_left_posi:", window.draw_left_posi, "\n");
//        Debug.print("draw_right_posi:", window.draw_right_posi, "\n");
//        Debug.print("draw_min_posi:", window.draw_min_posi, "\n");
//        Debug.print("draw_max_posi:", window.draw_max_posi, "\n");
//        new Exception("Stack trace").printStackTrace();
    }
    
    
    public void set_right_position(int value)
    {
        window.draw_right_posi = value;
        window.draw_left_posi = value - window.draw_range;
        check_position();
    }        

    public void set_left_position(int value)
    {
        window.draw_left_posi = value;
        window.draw_right_posi = value + window.draw_range;
        check_position();
    }        

    public void get_display_position()
    {
        int value;
        value = Display_Position.getValue();
        set_left_position(value);
    }        

    public void set_display_position(int value)
    {
        Display_Position.setValue(value);
        check_position();
    }        

    private void Display_PositionStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_Display_PositionStateChanged
        // TODO add your handling code here:
        if( !skip_flag )
        {
          get_display_position();
          check_redraw();
        }
    }//GEN-LAST:event_Display_PositionStateChanged

    private void set_cursor_common()
    {
//          window.cursor_to_sampling_posi(window.type_flag);
          TF_Cursor_Posi.setText(String.valueOf(window.cursor_posi));
          if( window.cursor_posi != window.prev_cursor_posi )
          {
            window.show_cursor_data();
            check_redraw();
            window.prev_cursor_posi = window.cursor_posi;
          }
    }
    
    private void set_cursor_position(int value)
    {
      Cursor_Position.setValue(value);
      set_cursor_common();
    }
    
    
    private void Cursor_PositionStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_Cursor_PositionStateChanged
        // TODO add your handling code here:
        if( !skip_flag )
        {
          window.cursor_posi = Cursor_Position.getValue();
          set_cursor_common();
        }
    }//GEN-LAST:event_Cursor_PositionStateChanged

    private int ltrig_link;
    private void show_ltrig_link()
    {
        if(l_trig_cond == Osci_logi.TRIG_OFF )
        {
            B_ltriglink.setText("OFF");
        }
        else if( ltrig_link == Osci_logi.TRIG_AND )
        {
            B_ltriglink.setText("AND");
        }
        else if( ltrig_link == Osci_logi.TRIG_OR )
        {
            B_ltriglink.setText("OR");
        }
        else
        {
            B_ltriglink.setText("OFF");
        }
    }
    
    private void B_ltriglinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltriglinkActionPerformed
        // TODO add your handling code here:
        if(l_trig_cond == Osci_logi.TRIG_OFF )return;
        
        if( ltrig_link == Osci_logi.TRIG_AND )
        {
            ltrig_link = Osci_logi.TRIG_OR;
        }
        else if( ltrig_link == Osci_logi.TRIG_OR )
        {
            ltrig_link = Osci_logi.TRIG_OFF;
        }
        else
        {
            ltrig_link = Osci_logi.TRIG_AND;
        }
        Osci_logi.settings_prefer.trigger_link = ltrig_link;
        show_ltrig_link();
    }//GEN-LAST:event_B_ltriglinkActionPerformed

    private int otrig_link;
    private void show_otrig_link()
    {
        if( otrig_cond == Osci_logi.TRIG_OFF )
        {
            B_otriglink.setText("OFF");
        }
        else if( otrig_link == Osci_logi.TRIG_AND )
        {
            B_otriglink.setText("AND");
        }
        else if( otrig_link == Osci_logi.TRIG_OR )
        {
            B_otriglink.setText("OR");
        }
        else
        {
            B_otriglink.setText("OFF");
        }
    }
    
    private int ltrig_mode;
    private void show_ltrig_mode()
    {
      if(l_trig_cond == Osci_logi.TRIG_OFF )
      {
        B_ltrigmode.setText("OFF");
      }
      else if( ltrig_mode == Osci_logi.START_TRIG )
      {
        B_ltrigmode.setText("STRT");
      }
      else if( ltrig_mode == Osci_logi.CENTER_TRIG )
      {
        B_ltrigmode.setText("CNTR");
      }
      else if( ltrig_mode == Osci_logi.END_TRIG )
      {
        B_ltrigmode.setText("END");
      }
    }
    
    private void B_ltrigmodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_ltrigmodeActionPerformed
        // TODO add your handling code here:
      if(l_trig_cond == Osci_logi.TRIG_OFF )return;

      if( ltrig_mode == Osci_logi.START_TRIG )
      {
        ltrig_mode = Osci_logi.CENTER_TRIG;
      }
      else if( ltrig_mode == Osci_logi.CENTER_TRIG )
      {
        ltrig_mode = Osci_logi.END_TRIG;
      }
      else if( ltrig_mode == Osci_logi.END_TRIG )
      {
        ltrig_mode = Osci_logi.START_TRIG;
      }
      Osci_logi.settings_prefer.logiana_trigger_mode = ltrig_mode;
      show_ltrig_mode();
    }//GEN-LAST:event_B_ltrigmodeActionPerformed

    private void jB_Data_DisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_Data_DisplayActionPerformed
        // TODO add your handling code here:
        if( window.data_display_flag )
        {
          window.data_display_flag = false;
          jB_Data_Display.setText("OFF");
          window.data_display.close();
        }
        else
        {
          window.data_display_flag = true;
          jB_Data_Display.setText("ON");
          window.data_display.open();
        }
    }//GEN-LAST:event_jB_Data_DisplayActionPerformed

    private void TF_Cursor_PosiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF_Cursor_PosiActionPerformed
        // TODO add your handling code here:
//          window.cursor_posi = Integer.parseInt(TF_Cursor_Posi.getText());
          window.cursor_posi = get_value(TF_Cursor_Posi.getText(),window.cursor_posi);
          set_cursor_common();
          Cursor_Position.setValue(window.cursor_posi);
    }//GEN-LAST:event_TF_Cursor_PosiActionPerformed

    private void jB_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_updateActionPerformed
        // TODO add your handling code here:
        if( window.hold_flag )
        {
          jB_update.setText("更新");
          window.hold_off();
          select_flag_update();
        }
        else
        {
          jB_update.setText("保持");
          window.hold_on();
        }
    }//GEN-LAST:event_jB_updateActionPerformed

    private void TF_Disp_Posi_MaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF_Disp_Posi_MaxActionPerformed
        // TODO add your handling code here:
//        int i = Integer.parseInt(TF_Disp_Posi_Max.getText());
        int i = get_value(TF_Disp_Posi_Max.getText(),window.draw_right_posi);
        set_right_position( i );
        Display_Position.setValue( window.draw_left_posi );
    }//GEN-LAST:event_TF_Disp_Posi_MaxActionPerformed

    private void B_or500ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or500ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 500;
        show_or_select();
    }//GEN-LAST:event_B_or500ActionPerformed

    private void B_otriglinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_otriglinkActionPerformed
        // TODO add your handling code here:
        if( Osci_logi.settings_prefer.oscillo_trig_cond == Osci_logi.TRIG_OFF ) return;

        if( otrig_link == Osci_logi.TRIG_AND )
        {
            otrig_link = Osci_logi.TRIG_OR;
        }
        else if( otrig_link == Osci_logi.TRIG_OR )
        {
            otrig_link = Osci_logi.TRIG_OFF;
        }
        else
        {
            otrig_link = Osci_logi.TRIG_AND;
        }
        Osci_logi.settings_prefer.trigger_link = otrig_link;
        show_otrig_link();
    }//GEN-LAST:event_B_otriglinkActionPerformed

    private void T_otriglevelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_T_otriglevelFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_T_otriglevelFocusGained

    private void jTrigger_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTrigger_CBActionPerformed
        int level;
        // TODO add your handling code here:
        otrig_ch = jTrigger_CB.getSelectedIndex();
        otrig_up_down_off = Osci_logi.settings_prefer.oscillo_trig_up_down_off[otrig_ch];
        level = Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch];
        limit_string = Integer.toString(level);
        T_otriglevel.setText(limit_string);

        set_slider_common();
        set_otrig_up_down_off();
    }//GEN-LAST:event_jTrigger_CBActionPerformed

    private void B_och3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_och3ActionPerformed
        // TODO add your handling code here:
        if( B_och3.isSelected() )
        {
            Osci_logi.settings_prefer.set_oscillo_ch(3,false);
        }
        else
        {
            Osci_logi.settings_prefer.set_oscillo_ch(3,true);
        }
        och_select_common();
    }//GEN-LAST:event_B_och3ActionPerformed

    private void B_och2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_och2ActionPerformed
        // TODO add your handling code here:
        if( B_och2.isSelected() )
        {
            Osci_logi.settings_prefer.set_oscillo_ch(2,false);
        }
        else
        {
            Osci_logi.settings_prefer.set_oscillo_ch(2,true);
        }
        och_select_common();
    }//GEN-LAST:event_B_och2ActionPerformed

    private void T_o_sampleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_o_sampleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_o_sampleActionPerformed

    private void B_otrigmodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_otrigmodeActionPerformed
        // TODO add your handling code here:
      if( Osci_logi.settings_prefer.oscillo_trig_cond == Osci_logi.TRIG_OFF ) return;

      if( otrig_mode == Osci_logi.START_TRIG )
      {
        otrig_mode = Osci_logi.CENTER_TRIG;
      }
      else if( otrig_mode == Osci_logi.CENTER_TRIG )
      {
        otrig_mode = Osci_logi.END_TRIG;
      }
      else if( otrig_mode == Osci_logi.END_TRIG )
      {
        otrig_mode = Osci_logi.OFF_TRIG;
      }
      else
      {
        otrig_mode = Osci_logi.START_TRIG;
      }
      Osci_logi.settings_prefer.oscillo_trigger_mode = otrig_mode;
      show_otrig_mode();
    }//GEN-LAST:event_B_otrigmodeActionPerformed
    
    private void B_otrigcondActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_otrigcondActionPerformed
        // TODO add your handling code here:
      if( otrig_cond == Osci_logi.TRIG_AND )
      {
        otrig_cond = Osci_logi.TRIG_OR;
      }
      else if( otrig_cond == Osci_logi.TRIG_OR )
      {
        otrig_cond = Osci_logi.TRIG_OFF;
        Osci_logi.settings_prefer.trigger_link = Osci_logi.TRIG_OFF;
      }
      else
      {
        otrig_cond = Osci_logi.TRIG_AND;
        show_otrig_mode();
        show_otrig_link();
      }
      Osci_logi.settings_prefer.oscillo_trig_cond = otrig_cond;
      show_otrig_cond();
    }//GEN-LAST:event_B_otrigcondActionPerformed
    
    private void B_otrigupdownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_otrigupdownActionPerformed
        // TODO add your handling code here:
      if( otrig_up_down_off == Osci_logi.SELECT_OFF )
      {
        otrig_up_down_off = Osci_logi.SELECT_UP;
      }
      else if( otrig_up_down_off == Osci_logi.SELECT_UP )
      {
        otrig_up_down_off = Osci_logi.SELECT_DOWN;
      }
      else
      {
        otrig_up_down_off = Osci_logi.SELECT_OFF;
      }
      set_otrig_up_down_off();
    }//GEN-LAST:event_B_otrigupdownActionPerformed

    private void B_oHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_oHzActionPerformed
        // TODO add your handling code here:
        B_okHz.setForeground( Color.BLACK );
        B_oHz.setForeground( Color.ORANGE );
        Osci_logi.settings_prefer.oscillo_sampling_unit = Osci_logi.UNIT_HZ;
    }//GEN-LAST:event_B_oHzActionPerformed

    private void B_okHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_okHzActionPerformed
        // TODO add your handling code here:
        B_okHz.setForeground( Color.ORANGE );
        B_oHz.setForeground( Color.BLACK );
        Osci_logi.settings_prefer.oscillo_sampling_unit = Osci_logi.UNIT_kHZ;
    }//GEN-LAST:event_B_okHzActionPerformed

    private void B_or50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or50ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 50;
        show_or_select();
    }//GEN-LAST:event_B_or50ActionPerformed

    private void B_or100ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or100ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 100;
        show_or_select();
    }//GEN-LAST:event_B_or100ActionPerformed

    private void B_or200ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or200ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 200;
        show_or_select();
    }//GEN-LAST:event_B_or200ActionPerformed

    private void B_or20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or20ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 20;
        show_or_select();
    }//GEN-LAST:event_B_or20ActionPerformed

    private void B_or10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or10ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 10;
        show_or_select();
    }//GEN-LAST:event_B_or10ActionPerformed

    private void B_or2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or2ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 2;
        show_or_select();
    }//GEN-LAST:event_B_or2ActionPerformed

    private void B_or1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or1ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 1;
        show_or_select();
    }//GEN-LAST:event_B_or1ActionPerformed


    private void B_or5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_or5ActionPerformed
        // TODO add your handling code here:
        Osci_logi.settings_prefer.oscillo_sampling_rate = 5;
        show_or_select();

    }//GEN-LAST:event_B_or5ActionPerformed

    private void hBarCaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_hBarCaretPositionChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_hBarCaretPositionChanged

    private void set_trig_level_common(int level)
    {
        if( otrig_up_down_off == Osci_logi.SELECT_UP )
        {
            limit_string = String.valueOf(level);
            T_otriglevel.setText(limit_string);
            Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch] = level;
        }
        else if( otrig_up_down_off == Osci_logi.SELECT_DOWN )
        {
            limit_string = String.valueOf(level);
            T_otriglevel.setText(limit_string);
            Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch] = level;
        }
        else
        {
            limit_string = null;
            T_otriglevel.setText("----");
//            Osci_logi.settings_prefer.oscillo_trig_level[otrig_ch] = 0;
        }
    }        
    
    private void hBarStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_hBarStateChanged
        // TODO add your handling code here:
        set_trig_level_common( hBar.getValue() );
    }//GEN-LAST:event_hBarStateChanged

    private void T_otriglevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_otriglevelActionPerformed
        // TODO add your handling code here:
        int trig_level;
        trig_level = get_value( T_otriglevel.getText(), 0 );
        if( trig_level >= Osci_logi.OSCILLO_MAX_LEVEL )
        {
          trig_level = Osci_logi.OSCILLO_MAX_LEVEL;
        }
        else if( trig_level < Osci_logi.OSCILLO_MIN_LEVEL )
        {
          trig_level = Osci_logi.OSCILLO_MIN_LEVEL;
        }
        set_trig_level_common(trig_level);
    }//GEN-LAST:event_T_otriglevelActionPerformed

    public void log_out_done()
    {
        B_logout.setForeground(Color.BLACK);
    }
    
    private void B_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_logoutActionPerformed
        // TODO add your handling code here:
        B_logout.setForeground(Color.ORANGE);
        window.log_data.log_out_next();
        Osci_logi.set_timer_event(1000, Osci_logi.LOG_OUT_EVENT);
    }//GEN-LAST:event_B_logoutActionPerformed
      
/**
     * @param args the command line arguments
     */
    public void Osci_logi_Comm_main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
    }

    public void Open(){
        setVisible(true);
    }
    
    public void Close(){
        setVisible(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B_H_LEFT;
    private javax.swing.JButton B_Type;
    private javax.swing.JButton B_VIEW;
    private javax.swing.JButton B_hannpuku;
    private javax.swing.JButton B_keisoku;
    private javax.swing.JButton B_lHz;
    private javax.swing.JButton B_lch0;
    private javax.swing.JButton B_lch1;
    private javax.swing.JButton B_lch2;
    private javax.swing.JButton B_lch3;
    private javax.swing.JButton B_lch4;
    private javax.swing.JButton B_lch5;
    private javax.swing.JButton B_lch6;
    private javax.swing.JButton B_lch7;
    private javax.swing.JButton B_lch8;
    private javax.swing.JButton B_lch9;
    private javax.swing.JButton B_lkHz;
    private javax.swing.JButton B_logout;
    private javax.swing.JButton B_lr1;
    private javax.swing.JButton B_lr10;
    private javax.swing.JButton B_lr100;
    private javax.swing.JButton B_lr1000;
    private javax.swing.JButton B_lr2;
    private javax.swing.JButton B_lr20;
    private javax.swing.JButton B_lr200;
    private javax.swing.JButton B_lr5;
    private javax.swing.JButton B_lr50;
    private javax.swing.JButton B_lr500;
    private javax.swing.JButton B_ltrig0;
    private javax.swing.JButton B_ltrig1;
    private javax.swing.JButton B_ltrig2;
    private javax.swing.JButton B_ltrig3;
    private javax.swing.JButton B_ltrig4;
    private javax.swing.JButton B_ltrig5;
    private javax.swing.JButton B_ltrig6;
    private javax.swing.JButton B_ltrig7;
    private javax.swing.JButton B_ltrig8;
    private javax.swing.JButton B_ltrig9;
    private javax.swing.JButton B_ltrigcond;
    private javax.swing.JButton B_ltriglink;
    private javax.swing.JButton B_ltrigmode;
    private javax.swing.JButton B_oHz;
    private javax.swing.JButton B_och0;
    private javax.swing.JButton B_och1;
    private javax.swing.JButton B_och2;
    private javax.swing.JButton B_och3;
    private javax.swing.JButton B_okHz;
    private javax.swing.JButton B_or1;
    private javax.swing.JButton B_or10;
    private javax.swing.JButton B_or100;
    private javax.swing.JButton B_or2;
    private javax.swing.JButton B_or20;
    private javax.swing.JButton B_or200;
    private javax.swing.JButton B_or5;
    private javax.swing.JButton B_or50;
    private javax.swing.JButton B_or500;
    private javax.swing.JButton B_otrigcond;
    private javax.swing.JButton B_otriglink;
    private javax.swing.JButton B_otrigmode;
    private javax.swing.JButton B_otrigupdown;
    private javax.swing.JButton B_shuuryou;
    private javax.swing.JButton B_tyuudan;
    private javax.swing.JPanel Base_pannel;
    private javax.swing.JPanel Canvas;
    private javax.swing.JPanel Console_Panel;
    private javax.swing.JLabel Console_labal;
    private javax.swing.JSlider Cursor_Position;
    private javax.swing.JSlider Display_Position;
    private javax.swing.JButton Logiana_Button;
    private javax.swing.JPanel Logiana_console;
    private javax.swing.JButton Oscillo_Button;
    private javax.swing.JPanel Oscillo_console;
    private javax.swing.JRadioButton RB_LCH0;
    private javax.swing.JRadioButton RB_LCH1;
    private javax.swing.JRadioButton RB_LCH2;
    private javax.swing.JRadioButton RB_LCH3;
    private javax.swing.JRadioButton RB_LCH4;
    private javax.swing.JRadioButton RB_LCH5;
    private javax.swing.JRadioButton RB_LCH6;
    private javax.swing.JRadioButton RB_LCH7;
    private javax.swing.JRadioButton RB_LCH8;
    private javax.swing.JRadioButton RB_LCH9;
    private javax.swing.JRadioButton RB_OCH0;
    private javax.swing.JRadioButton RB_OCH1;
    private javax.swing.JRadioButton RB_OCH2;
    private javax.swing.JRadioButton RB_OCH3;
    private javax.swing.JRadioButton RB_POSI_L;
    private javax.swing.JRadioButton RB_POSI_LM;
    private javax.swing.JRadioButton RB_POSI_U;
    private javax.swing.JRadioButton RB_POSI_UM;
    private javax.swing.JRadioButton RB_S11;
    private javax.swing.JRadioButton RB_S12;
    private javax.swing.JRadioButton RB_S14;
    private javax.swing.JButton R_H_RIGHT;
    private javax.swing.JTextField TF_Cursor_Posi;
    private javax.swing.JTextField TF_Disp_Posi_Max;
    private javax.swing.JTextField TF_Disp_Posi_Min;
    private javax.swing.JTextField TF_H;
    private javax.swing.JTextField T_l_sample;
    private javax.swing.JTextField T_o_sample;
    private javax.swing.JTextField T_otriglevel;
    private javax.swing.JPanel Toppanel;
    private javax.swing.JButton Window_1_Button;
    private javax.swing.JButton Window_2_Button;
    private javax.swing.JButton Window_3_Button;
    private javax.swing.JButton Window_4_Button;
    private javax.swing.JLabel Window_Label;
    private javax.swing.JPanel Window_console;
    private javax.swing.JSlider hBar;
    private javax.swing.JButton jB_Data_Display;
    private javax.swing.JButton jB_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JComboBox jTrigger_CB;
    // End of variables declaration//GEN-END:variables
}
