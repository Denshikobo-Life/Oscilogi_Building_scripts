/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osci_logi_console;

import static java.awt.Dialog.ModalityType.MODELESS;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author akira
 */

public class Message_dialog extends javax.swing.JDialog{
  private javax.swing.JPanel Message_panel;
  private javax.swing.JTextArea Message_text;
  private javax.swing.JScrollPane jScrollPane;
//    public Message_dialog( javax.swing.JFrame owner , String title) {
    public Message_dialog(String title) {
        this.setTitle(title);
        setBounds(64, 64, 256, 256);
        setDefaultCloseOperation(javax.swing.JDialog.DO_NOTHING_ON_CLOSE);
//        setUndecorated(true);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("closing...");
                //do something...
            }
            
            @Override
                public void windowActivated(WindowEvent e) {
    // TODO Auto-generated method stub
    System.out.println("windowActivated");
    }
    
            @Override
    public void windowClosed(WindowEvent e) {
    // TODO Auto-generated method stub
    System.out.println("windowClosed");
    }


            @Override
            public void windowDeactivated(WindowEvent e) {
// TODO Auto-generated method stub
System.out.println("windowDeactivated");
}

            @Override
            public void windowDeiconified(WindowEvent e) {
// TODO Auto-generated method stub
System.out.println("windowDeiconified");
}

            @Override
public void windowIconified(WindowEvent e) {
// TODO Auto-generated method stub
System.out.println("windowIconified");
}
            @Override
public void windowOpened(WindowEvent e) {
// TODO Auto-generated method stub
System.out.println("windowOpened");
} 

        });
        
        this.setModalityType(MODELESS);
        Message_panel = new javax.swing.JPanel();
        jScrollPane = new javax.swing.JScrollPane();
        Message_text = new javax.swing.JTextArea();
        
        Message_panel.setBackground(new java.awt.Color(204, 204, 255));

        Message_text.setColumns(20);
        Message_text.setRows(5);
//        Message_text.append( dialog_name+"\n\n");
//
//        Message_text.append("message1\n");
//        Message_text.append("message2\n");
//        Message_text.append("message3\n");
//        Message_text.append("message4\n");
//        Message_text.append("message5\n");
//        Message_text.append("message6\n");
        jScrollPane.setViewportView(Message_text);
        
        javax.swing.GroupLayout Message_panelLayout = new javax.swing.GroupLayout(Message_panel);
        Message_panel.setLayout(Message_panelLayout);
        Message_panelLayout.setHorizontalGroup(
            Message_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Message_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
                .addContainerGap())
        );
        Message_panelLayout.setVerticalGroup(
            Message_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Message_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                .addContainerGap())
        );
        
        javax.swing.GroupLayout Message_dialogLayout = new javax.swing.GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(Message_dialogLayout);
        Message_dialogLayout.setHorizontalGroup(
            Message_dialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Message_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Message_dialogLayout.setVerticalGroup(
            Message_dialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Message_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        this.setAlwaysOnTop(true);
        this.setVisible(false);
    }


    public void open()
    {
      this.setVisible(true);
    }
    
    public void close()
    {
      this.setVisible(false);
    }
    
    public void Message_dialog_clear()
    {
      Message_text.setText("");
    }

    public void Message_dialog_add(String s)
    {
      Message_text.append(s);
    }
}
