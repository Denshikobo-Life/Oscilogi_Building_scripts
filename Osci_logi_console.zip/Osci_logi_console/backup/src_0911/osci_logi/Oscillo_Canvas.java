/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package osci_logi;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 *
 * @author akira
 */
public class Oscillo_Canvas extends Canvas {
 //=============================================================================
 //フィールド
 //=============================================================================

 //キャンバスの寸法
 Dimension dimension;

 //グラフ化するデータ 
 double[] ch0;
 double[] ch1;
    private int i;



 //=============================================================================
 //コンストラクタ
 //=============================================================================
 Oscillo_Canvas(int width,int height)
 {
  //領域のサイズ設定
  setSize(width,height);

  //領域のサイズ取得
  dimension = getSize();

  //data[]のインスタンス生成
  ch0 = new double[dimension.width];
  ch1 = new double[dimension.width];
  //グラフエリアを灰色に設定
//  setBackground(Color.lightGray);
  setBackground(Osci_logi_Window.CANVAS_COLOR);
 }

 //=============================================================================
 //paint()メソッド
 //=============================================================================
 public void paint(Graphics g)
 {
  //領域のサイズ取得
  dimension = getSize();

  //軸の色は黒
//  g.setColor(Color.black);
  g.setColor(Color.GRAY);
  //x軸
  g.drawLine(0,dimension.height/2,dimension.width-1,dimension.height/2);
  //y軸
  g.drawLine(dimension.width/2,0,dimension.width/2,dimension.height-1);


  //グラフ線の色は青に設定
//  g.setColor(Color.blue);
  g.setColor(Color.ORANGE);

  //グラフ描画
  for(int i=0;i<dimension.width-2;i++)
  {
   g.drawLine( i, (int)( -ch0[i] + dimension.height/2 ), i+1, (int)( -ch0[i+1] + dimension.height/2 ) );
  }
  for(int i=0;i<dimension.width-2;i++)
  {
   g.drawLine( i, (int)( -ch1[i] + dimension.height/2 ), i+1, (int)( -ch1[i+1] + dimension.height/2 ) );
  }
//  for(int i=0;i<dimension.width-2;i++)
//  {
//   System.out.print( i );
//   System.out.print(" ");
//   System.out.print( ch0[i] );
//   System.out.print(" ");
//   System.out.print( ch1[i] );
//   System.out.print("\n");
//  }

 }

    
}
