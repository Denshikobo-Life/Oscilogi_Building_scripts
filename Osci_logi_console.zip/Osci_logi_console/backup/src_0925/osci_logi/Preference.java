/*
 * Copyright (c) 2012, Oracle and/or its affiliates. All rights reserved.
 */
package osci_logi;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
*/
public class Preference implements Serializable {

  public ArrayList<String> send_text;
  
  public String log_dir;
  public String prefered_dir;
  public Integer ch0_trig_max;
  public Integer ch0_trig_min;
  public Integer ch1_trig_max;
  public Integer ch1_trig_min;
  public Integer lsbt;
  public Integer lcbt;
  public Integer lcmk;
  public Integer lptn;
  public Integer lpmk;
  
  public Preference() {
    log_dir = "log_dir";
    prefered_dir = System.getProperty("user.dir") + File.separator;
    send_text = new ArrayList<>();
    send_text.add("SET OSCH:BOTH");
    send_text.add("SET OSCT:4096");
    send_text.add("SET OSRT:500");
    send_text.add("SET OSUT:kHz");
    send_text.add("SET LSBT:BOTH");
    send_text.add("SET LSCT:4096");
    send_text.add("SET LSRT:2000");
    send_text.add("SET LSUT:kHz");

    send_text.add("SET TLGI:BCHG");
    send_text.add("SET TOSC:NULL");
    send_text.add("SET TTMR:LOGI");
    send_text.add("SET TMOD:STRT");

    send_text.add("SET O0LL:NULL");
    send_text.add("SET O0UL:NULL");
    send_text.add("SET O1LL:NULL");
    send_text.add("SET O1UL:NULL");
    send_text.add("SET LCBT:000000000000000");
    send_text.add("SET LCMK:000000000000000");
    send_text.add("SET LPTN:NULL");
    send_text.add("SET LPMK:NULL");
    send_text.add("SET TDLY:NULL");
    send_text.add("SET TDUT:NULL");
    ch0_trig_max = 1023;
    ch0_trig_min = 0;
    ch1_trig_max = 1023;
    ch1_trig_min = 0;
    lsbt = 0;
    lcbt = 0;
    lcmk = 0;
    lptn = 0;
    lpmk = 0;
  }

  String get_log_dir(){
      return log_dir;
  }
  
  public String get_prefered_dir(){
      return prefered_dir;
  }

  public void update_prefered_dir( String new_dir){
      prefered_dir = new_dir;
  }
  
}
