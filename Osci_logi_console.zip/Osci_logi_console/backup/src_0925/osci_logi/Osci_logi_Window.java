package osci_logi;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JScrollBar;
import javax.swing.JViewport;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author akira
 */
public class Osci_logi_Window extends javax.swing.JFrame implements DocumentListener {
     Oscillo_Canvas oscillo;
     Logiana_Canvas logiana;

     public final static Color CANVAS_COLOR  = new Color(0, 51, 51);
    /**
     * Creates new form Oscil_ogi_Comm
     */
    public Osci_logi_Window() {
        initComponents();
//        t_variable.getDocument().addDocumentListener(this);
    }

    // scaling
    // 横軸
    // sample data ==> oscillo.getWidth()
    // 全体表示 ==>　間引き  データ数/oscillo.getWidth()
    //  8192/width
    // 拡大表示 ==>  部分      
    // 縦軸
    // 0..1023 <==> o..height
    // ad_value * height / 1024
    
    
    public void show_oscillo() {
        int height;
        int width;

        if( oscillo == null ) {
           oscillo = new Oscillo_Canvas(740,368);
           jP_Oscillo.add( oscillo );
        }
        height = oscillo.getHeight();
        width = oscillo.getWidth();

        for(int i=0;i<width;i++)
        {
           oscillo.ch0[i] =  ( Osci_logi.ch0[ i*4 ] - 512 ) * height / 1024;
           oscillo.ch1[i] =  ( Osci_logi.ch1[ i*4 ] - 512 ) * height / 1024;
//           System.out.print(i);
//           System.out.print(" ");
//           System.out.print(oscillo.ch0[i]);
//           System.out.print(" ");
//           System.out.print(oscillo.ch1[i]);
//           System.out.print("\n");
        }
        oscillo.repaint();
    }

    private boolean flicker_flag;
    public void keisoku_flicker() {
        if( flicker_flag )
        {
            B_keisoku.setForeground( Color.ORANGE );
            flicker_flag = false;
        }
        else
        {
          B_keisoku.setForeground( Color.BLACK );
          flicker_flag = true;
        }
    }
    
    public void keisoku_off() {
          B_keisoku.setForeground( Color.BLACK );
    }
    
    public void show_logiana() {
//        int height;
        int width;

        if( logiana == null ) {
           logiana = new Logiana_Canvas(740,358);
           jP_Logiana.add( logiana );
        }
//        height = logiana.getHeight();
        width = logiana.getWidth();

        for(int i=0;i<width;i++)
        {
           logiana.bit0[i] = Osci_logi.logiana[i*4] & 0x10;
           logiana.bit1[i] = Osci_logi.logiana[i*4] & 0x20;
           logiana.bit2[i] = Osci_logi.logiana[i*4] & 0x80;
           logiana.bit3[i] = Osci_logi.logiana[i*4] & 0x100;
           logiana.bit4[i] = Osci_logi.logiana[i*4] & 0x200;
        }
        logiana.repaint();
    }
    
//    private boolean scroll_flag = false;

//    public void scroll_up()
//    {
//    }

    private String command_string;

    private void check_command_string()
    {
        if( command_string.equals("SET TLGI:NULL") ) {
             Osci_logi.settings_prefer.send_text.set(16, "SET LCBT:NULL" );
             Osci_logi.settings_prefer.send_text.set(17, "SET LCMK:NULL" );
             Osci_logi.settings_prefer.send_text.set(18, "SET LPTN:NULL" );
             Osci_logi.settings_prefer.send_text.set(19, "SET LPMK:NULL" );
        }
       else if( command_string.equals("SET LSBT:BOTH") ) {
             Osci_logi.settings_prefer.send_text.set( 5, "SET LSCT:4096" );
       }
       else if( command_string.equals("SET LSBT:UPPR") ) {
             Osci_logi.settings_prefer.send_text.set( 5, "SET LSCT:8192" );
       }
       else if( command_string.equals("SET LSBT:LOWR") ) {
             Osci_logi.settings_prefer.send_text.set( 5, "SET LSCT:8192" );
       }
        else if( command_string.equals("SET OSCH:BOTH") ) {
             Osci_logi.settings_prefer.send_text.set( 1, "SET OSCT:4096" );
         }
         else if( command_string.equals("SET OSCH:CH0") ) {
             Osci_logi.settings_prefer.send_text.set( 1, "SET OSCT:8192" );
         }
         else if( command_string.equals("SET OSCH:CH1") ) {
             Osci_logi.settings_prefer.send_text.set( 1, "SET OSCT:8192" );
         }
//         update_send_command();
    }
    
//    private void update_send_command()
//    {
//         send_command_view.setText("");
//        for (String str : Osci_logi.settings_prefer.send_text) {
//            send_command_view.append(str+"\n");
//        }
//    }
    
    private void show_send_command()
    {
//         send_command_view.setText("");
        System.out.print("*********************************\n");
        System.out.print("send_command\n");
        for (String str : Osci_logi.settings_prefer.send_text) {
            System.out.print(str+"\n");
        }
    }
    
    private int get_value()
    {
      String[] sub_string = command_string.split(":");
      return Integer.parseInt( sub_string[sub_string.length - 1]);
    }
    
    private int get_bit_pattern(int bit_ch )
    {
        int bit_pattern;
        switch( bit_ch )
        {
            case 0:
                bit_pattern = 0x0001;
                break;
            case 1:
                bit_pattern = 0x0002;
                break;
            case 2:
                bit_pattern = 0x0010;
                break;
            case 3:
                bit_pattern = 0x0020;
                break;
            case 4:
                bit_pattern = 0x0080;
                break;
            case 5:
            default:
                bit_pattern = 0x0100;
                break;
        }
        return bit_pattern;
    }
    
    public void Init(){
        int index;
        int bit_pattern;

//        update_send_command();

        command_string = Osci_logi.settings_prefer.send_text.get(0);  // OSCH
        if( command_string.matches("(.*)CH0"))
        {
//          System.out.print("match CH0");
          och0_selected = true;
          B_och0.setForeground( Color.ORANGE );
          och1_selected = false;
//          B_och1.setForeground( Color.BLACK );
          T_o_sample.setText("8192");
//          B_or500.setForeground( Color.BLACK );
        }
        else if( command_string.matches("(.*)CH1") )
        {
//          System.out.print("match CH1");
          och1_selected = true;
          B_och1.setForeground( Color.ORANGE );
          och0_selected = false;
//          B_och0.setForeground( Color.BLACK );
          T_o_sample.setText("8192");
//          B_or500.setForeground( Color.BLACK );
        }
        else if( command_string.matches("(.*)BOTH") )
        {
//          System.out.print("match BOTH");
          och0_selected = true;
          B_och0.setForeground( Color.ORANGE );
          och1_selected = true;
          B_och1.setForeground( Color.ORANGE );
          T_o_sample.setText("4096");
          B_or500.setForeground( Color.GRAY );
        }
        else
        {
//          System.out.print("match NULL");
          och0_selected = false;
          B_och0.setForeground( Color.BLACK );
          och1_selected = false;
          B_och1.setForeground( Color.BLACK );
        }

//        command_string = Osci_logi.settings_prefer.send_text.get(1); // OSCT
        
        command_string = Osci_logi.settings_prefer.send_text.get(2); // OSRT
        o_rate = get_value();
        switch( o_rate )
        {
            case 1:
               B_or1.setForeground( Color.ORANGE );
               break;
            case 2:
               B_or2.setForeground( Color.ORANGE );
               break;
            case 5:
               B_or5.setForeground( Color.ORANGE );
               break;
            case 10:
               B_or10.setForeground( Color.ORANGE );
               break;
            case 20:
               B_or20.setForeground( Color.ORANGE );
               break;
            case 50:
               B_or50.setForeground( Color.ORANGE );
               break;
            case 100:
               B_or100.setForeground( Color.ORANGE );
               break;
            case 200:
               B_or200.setForeground( Color.ORANGE );
               break;
            case 500:
               B_or500.setForeground( Color.ORANGE );
               break;
        }
        
        command_string = Osci_logi.settings_prefer.send_text.get(3); // OSUT
        if( command_string.matches("(.*)mHz"))
        {
            o_unit = UNIT_mHZ;
            B_omHz.setForeground( Color.ORANGE );
        }
        else if( command_string.matches("(.*)kHz"))
        {
            o_unit = UNIT_kHZ;
            B_okHz.setForeground( Color.ORANGE );
        }
        else
        {
            o_unit = UNIT_HZ;
            B_oHz.setForeground( Color.ORANGE );
        }
        
        command_string = Osci_logi.settings_prefer.send_text.get(4); // LSBT
//        command_string = Osci_logi.settings_prefer.send_text.get(5); // LSCT
        if( command_string.matches("(.*)LOWR"))
        {
           T_l_sample.setText("8192");
        }
        else if( command_string.matches("(.*)UPER"))
        {
           T_l_sample.setText("8192");
        }
        else if( command_string.matches("(.*)BOTH"))
        {
           T_l_sample.setText("4096");
        }
        else
        {
           T_l_sample.setText("----");
        }
        
        lch0_selected = false;
        lch1_selected = false;
        lch2_selected = false;
        lch3_selected = false;
        lch4_selected = false;
        lch5_selected = false;

        log_bit  = Osci_logi.settings_prefer.lsbt;
        if( ( log_bit & 0x0001 ) != 0 )
        {
          B_lch0.setForeground( Color.ORANGE );
          lch0_selected = true;
        }
        if ( ( log_bit & 0x0002 ) != 0 )
        {
          B_lch1.setForeground( Color.ORANGE );
          lch1_selected = true;
        }
        if ( ( log_bit & 0x0010 ) != 0 )
        {
          B_lch2.setForeground( Color.ORANGE );
          lch2_selected = true;
        }
        if ( ( log_bit & 0x0020 ) != 0 )
        {
          B_lch3.setForeground( Color.ORANGE );
          lch3_selected = true;
        }
        if ( ( log_bit & 0x0080 ) != 0 )
        {
          B_lch4.setForeground( Color.ORANGE );
          lch4_selected = true;
        }
        if ( ( log_bit & 0x0100 ) != 0 )
        {
          B_lch5.setForeground( Color.ORANGE );
          lch5_selected = true;
        }
  
        command_string = Osci_logi.settings_prefer.send_text.get(6); // LSRT
        l_rate = get_value();
        switch( l_rate )
        {
            case 1:
               B_lr1.setForeground( Color.ORANGE );
               break;
            case 2:
               B_lr2.setForeground( Color.ORANGE );
               break;
            case 5:
               B_lr5.setForeground( Color.ORANGE );
               break;
            case 10:
               B_lr10.setForeground( Color.ORANGE );
               break;
            case 20:
               B_lr20.setForeground( Color.ORANGE );
               break;
            case 50:
               B_lr50.setForeground( Color.ORANGE );
               break;
            case 100:
               B_lr100.setForeground( Color.ORANGE );
               break;
            case 200:
               B_lr200.setForeground( Color.ORANGE );
               break;
            case 500:
               B_lr500.setForeground( Color.ORANGE );
               break;
            case 1000:
               B_lr1000.setForeground( Color.ORANGE );
               break;
            case 2000:
               B_lr2000.setForeground( Color.ORANGE );
               break;
        }
        
        command_string = Osci_logi.settings_prefer.send_text.get(7); // LSUT
        if( command_string.matches("(.*)mHz"))
        {
            l_unit = UNIT_mHZ;
            B_lmHz.setForeground( Color.ORANGE );
        }
        else if( command_string.matches("(.*)kHz"))
        {
            l_unit = UNIT_kHZ;
            B_lkHz.setForeground( Color.ORANGE );
        }
        else
        {
            l_unit = UNIT_HZ;
            B_lHz.setForeground( Color.ORANGE );
        }

        command_string = Osci_logi.settings_prefer.send_text.get(8); // TLGI
        if( command_string.matches("(.*)BCHG"))
        {
          l_trig_cond = BCHG_TRIG;
          B_ltrigcond.setText("BCHG");
          for( int bit_ch=0;bit_ch<=5;bit_ch++)
          {
            bit_pattern = get_bit_pattern( bit_ch );
            if( ( Osci_logi.settings_prefer.lcmk &  bit_pattern ) == 0 )
            {
              trig_logi_bit( bit_ch, TRIG_OFF );
            }
            else if( ( Osci_logi.settings_prefer.lcbt &  bit_pattern ) == 0 )
            {
              trig_logi_bit( bit_ch, TRIG_LOW );
            }
            else
            {
              trig_logi_bit( bit_ch, TRIG_HI );
            }
          }
        }
        else if( command_string.matches("(.*)PTRN"))
        {
          l_trig_cond = PTRN_TRIG;
          B_ltrigcond.setText("PTRN");
          for( int bit_ch=0;bit_ch<=5;bit_ch++)
          {
            bit_pattern = get_bit_pattern( bit_ch );
            if( ( Osci_logi.settings_prefer.lpmk &  bit_pattern ) == 0 )
            {
              trig_logi_bit( bit_ch, TRIG_OFF );
            }
            else if( ( Osci_logi.settings_prefer.lptn &  bit_pattern ) == 0 )
            {
              trig_logi_bit( bit_ch, TRIG_LOW );
            }
            else
            {
              trig_logi_bit( bit_ch, TRIG_HI );
            }
          }
        }
        else
        {
          l_trig_cond = TRIG_OFF;
          B_ltrigcond.setText("OFF");
          for( int bit_ch=0;bit_ch<=5;bit_ch++)
          {
            trig_logi_bit( bit_ch, TRIG_OFF );
          }
        }

        command_string = Osci_logi.settings_prefer.send_text.get(12); // O0LL
        if( command_string.matches("(.*)IN"))
        {
          otrig0cond = RANGE_IN;
          B_otrig0cond.setText("IN");
        }
        else if( command_string.matches("(.*)OUT"))
        {
          otrig0cond = RANGE_OUT;
          B_otrig0cond.setText("OUT");
        }
        else
        {
          otrig0cond = TRIG_OFF;
          B_otrig0cond.setText("OFF");
        }

        command_string = Osci_logi.settings_prefer.send_text.get(14); // O1LL
        if( command_string.matches("(.*)IN"))
        {
          otrig1cond = RANGE_IN;
          B_otrig1cond.setText("IN");
        }
        else if( command_string.matches("(.*)OUT"))
        {
          otrig1cond = RANGE_OUT;
          B_otrig1cond.setText("OUT");
        }
        else
        {
          otrig1cond = TRIG_OFF;
          B_otrig1cond.setText("OFF");
        }

        command_string = Osci_logi.settings_prefer.send_text.get(9); // TOSC
        if( command_string.matches("(.*)CH0"))
        {
//          och0_selected = true;
//          och1_selected = false;
          otrig_andor = TRIG_OFF;
          B_otrig_andor.setText("OFF");
        }
        else if( command_string.matches("(.*)CH1"))
        {
//          och1_selected = true;
//          och0_selected = false;
          otrig_andor = TRIG_OFF;
          B_otrig_andor.setText("OFF");
        }
        else if( command_string.matches("(.*)AND"))
        {
//          och0_selected = true;
//          och1_selected = true;
          otrig_andor = TRIG_AND;
          B_otrig_andor.setText("AND");
        }
        else if( command_string.matches("(.*)OR"))
        {
//          och0_selected = true;
//          och1_selected = true;
          otrig_andor = TRIG_OR;
          B_otrig_andor.setText("OR");
        }
        else
        {
//          och0_selected = false;
//          och1_selected = false;
          otrig_andor = TRIG_OFF;
          B_otrig_andor.setText("OFF");
        }
        
//        command_string = Osci_logi.settings_prefer.send_text.get(10); // TTMR
        command_string = Osci_logi.settings_prefer.send_text.get(11); // TMOD
        if( command_string.matches("(.*)STRT"))
        {
          trig_mode = START_TRIG;
          B_trig_mode.setText("STRT");
        }
        else if( command_string.matches("(.*)CNTR"))
        {
          trig_mode = CENTER_TRIG;
          B_trig_mode.setText("CNTR");
        }
        else if( command_string.matches("(.*)END"))
        {
          trig_mode = END_TRIG;
          B_trig_mode.setText("END");
        }
        else
        {
          trig_mode = TRIG_OFF;
          B_trig_mode.setText("Mode");
        }
        
        T_otrig0max.setText(String.valueOf(Osci_logi.settings_prefer.ch0_trig_max));
        T_otrig0min.setText(String.valueOf(Osci_logi.settings_prefer.ch0_trig_min));
        T_otrig1max.setText(String.valueOf(Osci_logi.settings_prefer.ch1_trig_max));
        T_otrig1min.setText(String.valueOf(Osci_logi.settings_prefer.ch1_trig_min));
    }
    
    private void trig_logi_bit( int bit, int trig_mode  )
    {
        String mode_string = null;
        switch( trig_mode )
        {
            case TRIG_OFF:
                mode_string = "----";
                break;
            case TRIG_HI:
                mode_string = "HI";
                break;
            case TRIG_LOW:
                mode_string = "LOW";
                break;
        }
        
        switch( bit )
        {
            case 0:
               l_trig_0 = trig_mode;
               B_ltrig0.setText(mode_string);
                break;
            case 1:
               l_trig_1 = trig_mode;
               B_ltrig1.setText(mode_string);
                break;
            case 2:
               l_trig_2 = trig_mode;
               B_ltrig2.setText(mode_string);
                break;
            case 3:
               l_trig_3 = trig_mode;
               B_ltrig3.setText(mode_string);
                break;
            case 4:
               l_trig_4 = trig_mode;
               B_ltrig4.setText(mode_string);
                break;
            case 5:
               l_trig_5 = trig_mode;
               B_ltrig5.setText(mode_string);
                break;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Ope_pannel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        B_lr2 = new javax.swing.JButton();
        B_ltrig0 = new javax.swing.JButton();
        B_lr10 = new javax.swing.JButton();
        B_lr5 = new javax.swing.JButton();
        B_lch0 = new javax.swing.JButton();
        B_lch5 = new javax.swing.JButton();
        B_lr20 = new javax.swing.JButton();
        B_lch3 = new javax.swing.JButton();
        B_lch4 = new javax.swing.JButton();
        B_lch2 = new javax.swing.JButton();
        B_lch1 = new javax.swing.JButton();
        B_lr1 = new javax.swing.JButton();
        B_lr50 = new javax.swing.JButton();
        B_lr100 = new javax.swing.JButton();
        B_lr200 = new javax.swing.JButton();
        B_lr500 = new javax.swing.JButton();
        B_lr1000 = new javax.swing.JButton();
        B_lr2000 = new javax.swing.JButton();
        B_ltrig1 = new javax.swing.JButton();
        B_ltrig2 = new javax.swing.JButton();
        B_ltrig3 = new javax.swing.JButton();
        B_ltrig4 = new javax.swing.JButton();
        B_ltrig5 = new javax.swing.JButton();
        B_ltrigcond = new javax.swing.JButton();
        B_lmode = new javax.swing.JButton();
        B_lmHz = new javax.swing.JButton();
        B_lHz = new javax.swing.JButton();
        B_lkHz = new javax.swing.JButton();
        T_l_sample = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hBar = new javax.swing.JSlider();
        B_or5 = new javax.swing.JButton();
        B_och0 = new javax.swing.JButton();
        B_or1 = new javax.swing.JButton();
        B_or2 = new javax.swing.JButton();
        B_och1 = new javax.swing.JButton();
        B_or10 = new javax.swing.JButton();
        B_or20 = new javax.swing.JButton();
        B_otrigselmax = new javax.swing.JButton();
        B_or500 = new javax.swing.JButton();
        B_or200 = new javax.swing.JButton();
        B_or100 = new javax.swing.JButton();
        B_or50 = new javax.swing.JButton();
        B_omHz = new javax.swing.JButton();
        B_okHz = new javax.swing.JButton();
        B_oHz = new javax.swing.JButton();
        T_otrig0max = new javax.swing.JTextField();
        T_otrig0min = new javax.swing.JTextField();
        T_otrig1max = new javax.swing.JTextField();
        T_otrig1min = new javax.swing.JTextField();
        B_otrigselmin = new javax.swing.JButton();
        B_trig_link_cond = new javax.swing.JButton();
        B_otrig0cond = new javax.swing.JButton();
        B_otrig1cond = new javax.swing.JButton();
        B_otrig_andor = new javax.swing.JButton();
        B_trig_mode = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        B_omode = new javax.swing.JButton();
        B_range = new javax.swing.JButton();
        T_o_sample = new javax.swing.JTextField();
        B_show = new javax.swing.JButton();
        jP_Oscillo = new javax.swing.JPanel();
        jP_Logiana = new javax.swing.JPanel();
        B_hannpuku = new javax.swing.JButton();
        B_shuuryou = new javax.swing.JButton();
        B_keisoku = new javax.swing.JButton();
        B_tyuudan = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 204, 51));
        setBounds(new java.awt.Rectangle(10, 20, 5, 10));

        Ope_pannel.setBackground(new java.awt.Color(51, 102, 0));
        Ope_pannel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 51), 5, true));
        Ope_pannel.setDoubleBuffered(false);
        Ope_pannel.setPreferredSize(new java.awt.Dimension(1200, 700));

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setPreferredSize(new java.awt.Dimension(450, 170));

        jLabel1.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel1.setText("ロジアナ");
        jLabel1.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel3.setText("CH選択");
        jLabel3.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel2.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel2.setText("計測レート");
        jLabel2.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel2.setRequestFocusEnabled(false);

        jLabel8.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel8.setText("トリガ");
        jLabel8.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel8.setRequestFocusEnabled(false);

        B_lr2.setText("2");
        B_lr2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr2ActionPerformed(evt);
            }
        });

        B_ltrig0.setText("--");
        B_ltrig0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig0ActionPerformed(evt);
            }
        });

        B_lr10.setText("10");
        B_lr10.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr10.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr10ActionPerformed(evt);
            }
        });

        B_lr5.setText("5");
        B_lr5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr5ActionPerformed(evt);
            }
        });

        B_lch0.setText("CH0");
        B_lch0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch0ActionPerformed(evt);
            }
        });

        B_lch5.setText("CH5");
        B_lch5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch5ActionPerformed(evt);
            }
        });

        B_lr20.setText("20");
        B_lr20.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr20.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr20ActionPerformed(evt);
            }
        });

        B_lch3.setText("CH3");
        B_lch3.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch3.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch3ActionPerformed(evt);
            }
        });

        B_lch4.setText("CH4");
        B_lch4.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch4.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch4ActionPerformed(evt);
            }
        });

        B_lch2.setText("CH2");
        B_lch2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch2ActionPerformed(evt);
            }
        });

        B_lch1.setText("CH1");
        B_lch1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lch1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lch1ActionPerformed(evt);
            }
        });

        B_lr1.setText("1");
        B_lr1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr1ActionPerformed(evt);
            }
        });

        B_lr50.setText("50");
        B_lr50.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr50.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr50ActionPerformed(evt);
            }
        });

        B_lr100.setText("100");
        B_lr100.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr100.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr100ActionPerformed(evt);
            }
        });

        B_lr200.setText("200");
        B_lr200.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr200.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr200.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr200ActionPerformed(evt);
            }
        });

        B_lr500.setText("500");
        B_lr500.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr500.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr500.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr500ActionPerformed(evt);
            }
        });

        B_lr1000.setText("1000");
        B_lr1000.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr1000.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr1000.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr1000ActionPerformed(evt);
            }
        });

        B_lr2000.setText("2000");
        B_lr2000.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lr2000.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lr2000.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lr2000ActionPerformed(evt);
            }
        });

        B_ltrig1.setText("--");
        B_ltrig1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig1ActionPerformed(evt);
            }
        });

        B_ltrig2.setText("--");
        B_ltrig2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig2ActionPerformed(evt);
            }
        });

        B_ltrig3.setText("--");
        B_ltrig3.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig3.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig3ActionPerformed(evt);
            }
        });

        B_ltrig4.setText("--");
        B_ltrig4.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig4.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig4ActionPerformed(evt);
            }
        });

        B_ltrig5.setText("--");
        B_ltrig5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrig5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrig5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrig5ActionPerformed(evt);
            }
        });

        B_ltrigcond.setText("OFF");
        B_ltrigcond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_ltrigcond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_ltrigcond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_ltrigcondActionPerformed(evt);
            }
        });

        B_lmode.setText("計測");
        B_lmode.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lmode.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lmode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lmodeActionPerformed(evt);
            }
        });

        B_lmHz.setText("mHz");
        B_lmHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lmHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lmHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lmHzActionPerformed(evt);
            }
        });

        B_lHz.setText("Hz");
        B_lHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lHzActionPerformed(evt);
            }
        });

        B_lkHz.setText("kHz");
        B_lkHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_lkHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_lkHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_lkHzActionPerformed(evt);
            }
        });

        T_l_sample.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_l_sample.setText("sample");
        T_l_sample.setPreferredSize(new java.awt.Dimension(62, 21));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(B_lr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lr5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lr10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lr20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(B_lr50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_lr100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(B_lr2000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(B_lr200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_lr500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_lr1000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(B_lmHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_lHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_lkHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(B_lch0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lch2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(B_lch3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(B_lch5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(B_lmode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(T_l_sample, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(B_lch4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(B_ltrig5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(B_ltrig0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(B_ltrig1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(B_ltrig2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_ltrig3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_ltrig4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(B_ltrigcond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lmode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lch4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lch5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_l_sample, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lr20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lr50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr1000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_lHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lmHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lr2000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_lkHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_ltrigcond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_ltrig5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setFocusCycleRoot(true);
        jPanel2.setPreferredSize(new java.awt.Dimension(450, 170));
        jPanel2.setRequestFocusEnabled(false);

        jLabel4.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel4.setText("オシロ");
        jLabel4.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel5.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel5.setText("CH選択");
        jLabel5.setPreferredSize(new java.awt.Dimension(75, 20));

        jLabel6.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel6.setText("トリガLow");
        jLabel6.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel6.setRequestFocusEnabled(false);

        jLabel7.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel7.setText("計測レート");
        jLabel7.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel7.setRequestFocusEnabled(false);

        jLabel9.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel9.setText("トリガHi");
        jLabel9.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel9.setRequestFocusEnabled(false);

        jLabel10.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("トリガ条件");
        jLabel10.setPreferredSize(new java.awt.Dimension(83, 20));
        jLabel10.setRequestFocusEnabled(false);

        hBar.setMaximum(1023);
        hBar.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                hBarStateChanged(evt);
            }
        });
        hBar.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                hBarCaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
            }
        });

        B_or5.setText("5");
        B_or5.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or5.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or5ActionPerformed(evt);
            }
        });

        B_och0.setText("CH0");
        B_och0.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och0.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och0ActionPerformed(evt);
            }
        });

        B_or1.setText("1");
        B_or1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or1ActionPerformed(evt);
            }
        });

        B_or2.setText("2");
        B_or2.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or2.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or2ActionPerformed(evt);
            }
        });

        B_och1.setText("CH1");
        B_och1.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_och1.setPreferredSize(new java.awt.Dimension(62, 21));
        B_och1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_och1ActionPerformed(evt);
            }
        });

        B_or10.setText("10");
        B_or10.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or10.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or10ActionPerformed(evt);
            }
        });

        B_or20.setText("20");
        B_or20.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or20.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or20ActionPerformed(evt);
            }
        });

        B_otrigselmax.setText("<==");
        B_otrigselmax.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrigselmax.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrigselmax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrigselmaxActionPerformed(evt);
            }
        });

        B_or500.setText("500");
        B_or500.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or500.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or500.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or500ActionPerformed(evt);
            }
        });

        B_or200.setText("200");
        B_or200.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or200.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or200.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or200ActionPerformed(evt);
            }
        });

        B_or100.setText("100");
        B_or100.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or100.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or100ActionPerformed(evt);
            }
        });

        B_or50.setText("50");
        B_or50.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_or50.setPreferredSize(new java.awt.Dimension(62, 21));
        B_or50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_or50ActionPerformed(evt);
            }
        });

        B_omHz.setText("mHz");
        B_omHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_omHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_omHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_omHzActionPerformed(evt);
            }
        });

        B_okHz.setText("kHz");
        B_okHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_okHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_okHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_okHzActionPerformed(evt);
            }
        });

        B_oHz.setText("Hz");
        B_oHz.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_oHz.setPreferredSize(new java.awt.Dimension(62, 21));
        B_oHz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_oHzActionPerformed(evt);
            }
        });

        T_otrig0max.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_otrig0max.setText("1023");
        T_otrig0max.setPreferredSize(new java.awt.Dimension(62, 21));
        T_otrig0max.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                T_otrig0maxFocusGained(evt);
            }
        });

        T_otrig0min.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_otrig0min.setText("0");
        T_otrig0min.setPreferredSize(new java.awt.Dimension(62, 21));
        T_otrig0min.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                T_otrig0minFocusGained(evt);
            }
        });

        T_otrig1max.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_otrig1max.setText("1023");
        T_otrig1max.setPreferredSize(new java.awt.Dimension(62, 21));
        T_otrig1max.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                T_otrig1maxFocusGained(evt);
            }
        });

        T_otrig1min.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_otrig1min.setText("0");
        T_otrig1min.setPreferredSize(new java.awt.Dimension(62, 21));
        T_otrig1min.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                T_otrig1minFocusGained(evt);
            }
        });

        B_otrigselmin.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrigselmin.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrigselmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrigselminActionPerformed(evt);
            }
        });

        B_trig_link_cond.setText("Link");
        B_trig_link_cond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_trig_link_cond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_trig_link_cond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_trig_link_condActionPerformed(evt);
            }
        });

        B_otrig0cond.setText("OFF");
        B_otrig0cond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrig0cond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrig0cond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrig0condActionPerformed(evt);
            }
        });

        B_otrig1cond.setText("OFF");
        B_otrig1cond.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrig1cond.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrig1cond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrig1condActionPerformed(evt);
            }
        });

        B_otrig_andor.setText("OFF");
        B_otrig_andor.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_otrig_andor.setPreferredSize(new java.awt.Dimension(62, 21));
        B_otrig_andor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_otrig_andorActionPerformed(evt);
            }
        });

        B_trig_mode.setText("Mode");
        B_trig_mode.setAutoscrolls(true);
        B_trig_mode.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_trig_mode.setPreferredSize(new java.awt.Dimension(62, 21));
        B_trig_mode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_trig_modeActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel12.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel12.setRequestFocusEnabled(false);

        jLabel13.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabel13.setPreferredSize(new java.awt.Dimension(75, 20));
        jLabel13.setRequestFocusEnabled(false);

        B_omode.setText("計測");
        B_omode.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_omode.setPreferredSize(new java.awt.Dimension(62, 21));
        B_omode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_omodeActionPerformed(evt);
            }
        });

        B_range.setText("広域");
        B_range.setMargin(new java.awt.Insets(2, 12, 2, 12));
        B_range.setPreferredSize(new java.awt.Dimension(62, 21));
        B_range.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_rangeActionPerformed(evt);
            }
        });

        T_o_sample.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        T_o_sample.setText("sample");
        T_o_sample.setPreferredSize(new java.awt.Dimension(62, 21));

        B_show.setText("show");
        B_show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_showActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(138, 138, 138)
                                .addComponent(T_otrig1min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(B_och0, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(B_or1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(B_or100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_or200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(B_or2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(B_och1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(B_or5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(B_or500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(B_or10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(T_o_sample, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(B_or20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(B_omode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otrig0cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otrig_andor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otrig1cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_trig_mode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(hBar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(B_trig_link_cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_range, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_show, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6))
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(B_or50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(B_omHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_oHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(B_okHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(T_otrig0max, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(B_otrigselmax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(T_otrig1max, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(T_otrig0min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_otrigselmin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_omode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_och1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_o_sample, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_or500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or200, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_or50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(B_omHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_oHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_okHz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(T_otrig0max, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_otrigselmax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(T_otrig1max, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_show))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_otrig0min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_otrig1min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrigselmin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(hBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_range, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrig0cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrig_andor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_otrig1cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_trig_mode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_trig_link_cond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jP_Oscillo.setBackground(new java.awt.Color(0, 51, 51));
        jP_Oscillo.setPreferredSize(new java.awt.Dimension(740, 368));

        javax.swing.GroupLayout jP_OscilloLayout = new javax.swing.GroupLayout(jP_Oscillo);
        jP_Oscillo.setLayout(jP_OscilloLayout);
        jP_OscilloLayout.setHorizontalGroup(
            jP_OscilloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 740, Short.MAX_VALUE)
        );
        jP_OscilloLayout.setVerticalGroup(
            jP_OscilloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );

        jP_Logiana.setBackground(new java.awt.Color(0, 51, 51));
        jP_Logiana.setPreferredSize(new java.awt.Dimension(740, 358));

        javax.swing.GroupLayout jP_LogianaLayout = new javax.swing.GroupLayout(jP_Logiana);
        jP_Logiana.setLayout(jP_LogianaLayout);
        jP_LogianaLayout.setHorizontalGroup(
            jP_LogianaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jP_LogianaLayout.setVerticalGroup(
            jP_LogianaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 358, Short.MAX_VALUE)
        );

        B_hannpuku.setText("反復");
        B_hannpuku.setFocusable(false);
        B_hannpuku.setPreferredSize(new java.awt.Dimension(72, 57));
        B_hannpuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_hannpukuActionPerformed(evt);
            }
        });

        B_shuuryou.setText("終了");
        B_shuuryou.setPreferredSize(new java.awt.Dimension(72, 57));
        B_shuuryou.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_shuuryouActionPerformed(evt);
            }
        });

        B_keisoku.setText("計測");
        B_keisoku.setPreferredSize(new java.awt.Dimension(72, 57));
        B_keisoku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_keisokuActionPerformed(evt);
            }
        });

        B_tyuudan.setText("中断");
        B_tyuudan.setPreferredSize(new java.awt.Dimension(72, 57));
        B_tyuudan.setRolloverEnabled(false);
        B_tyuudan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_tyuudanActionPerformed(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("OsciLogi-32");
        jLabel11.setFocusable(false);
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel11.setOpaque(true);

        javax.swing.GroupLayout Ope_pannelLayout = new javax.swing.GroupLayout(Ope_pannel);
        Ope_pannel.setLayout(Ope_pannelLayout);
        Ope_pannelLayout.setHorizontalGroup(
            Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Ope_pannelLayout.createSequentialGroup()
                .addGroup(Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(Ope_pannelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(B_shuuryou, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(B_keisoku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(B_tyuudan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(B_hannpuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 468, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 468, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jP_Oscillo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jP_Logiana, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        Ope_pannelLayout.setVerticalGroup(
            Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Ope_pannelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Ope_pannelLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jP_Oscillo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Ope_pannelLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(Ope_pannelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(B_shuuryou, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_keisoku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_tyuudan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(B_hannpuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jP_Logiana, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Ope_pannel, javax.swing.GroupLayout.DEFAULT_SIZE, 1225, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Ope_pannel, javax.swing.GroupLayout.DEFAULT_SIZE, 752, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public void insertUpdate(DocumentEvent e) {
        System.out.print("insertUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        System.out.print("removeUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        System.out.print("changedUpdate\n");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    class Command {
        Integer  command_index;
        String command;
//        String receive_param;
        String set_type;
        String set_data;
        String command_string;
        
        public Command()
        {
            command_index = 0;
            command = "SET";
//            receive_param = "";
            set_type = "";
            set_data = "";
        }
    }
    
    Command command = new Command();

    public void updateSendText()
    {
        // STS SET LOG BRK RCV
       command_string = command.command;
       command_string += " "+command.set_type+":"+command.set_data;
       Osci_logi.send_string = command_string;
    }
    
    private void b_setteiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_setteiActionPerformed
        // TODO add your handling code here:
        Osci_logi.send_flag = true;
    }//GEN-LAST:event_b_setteiActionPerformed

    private void c_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_typeActionPerformed
        // TODO add your handling code here:
//        command.set_type = (String)c_type.getSelectedItem();
        
        updateSendText();
    }//GEN-LAST:event_c_typeActionPerformed

    private void tourokuAction_common( ) { 
        int index;
        int check_cond;
        // TODO add your handling code here:
        if( command.set_type.equals("OSCH") )index = 0;
        else if( command.set_type.equals("OSCT") )index = 1;
        else if( command.set_type.equals("OSRT") )index = 2;
        else if( command.set_type.equals("OSUT") )index = 3;
        else if( command.set_type.equals("LSBT") )index = 4;
        else if( command.set_type.equals("LSCT") )index = 5;
        else if( command.set_type.equals("LSRT") )index = 6;
        else if( command.set_type.equals("LSUT") )index = 7;
        else if( command.set_type.equals("TLGI") )index = 8;
        else if( command.set_type.equals("TOSC") )index = 9;
        else if( command.set_type.equals("TTMR") )index = 10;
        else if( command.set_type.equals("TMOD") )index = 11;
        else if( command.set_type.equals("O0LL") )index = 12;
        else if( command.set_type.equals("O0UL") )index = 13;
        else if( command.set_type.equals("O1LL") )index = 14;
        else if( command.set_type.equals("O1UL") )index = 15;
        else if( command.set_type.equals("LCBT") )index = 16;
        else if( command.set_type.equals("LCMK") )index = 17;
        else if( command.set_type.equals("LPTN") )index = 18;
        else if( command.set_type.equals("LPMK") )index = 19;
        else if( command.set_type.equals("TDLY") )index = 20;
        else if( command.set_type.equals("TDUT") )index = 21;
        else index = -1;
        
        if( index == -1 )
        {
            System.out.print( command.set_type+" "+command.set_data);
            return;        
        }
       
        command_string = command.command;
        command_string += " "+command.set_type+":"+command.set_data;
        
       if( ( index == 12 )||( index == 14 ) ) // "O0LL" || O1LL"
       {
         check_cond = otrig0cond;  //"O0LL"
         if( index == 14 ) 
         {
            check_cond = otrig1cond; // "O1LL"      
         }
         if( check_cond == TRIG_OFF )
         {
           command_string += ":OFF";
         }
         else if( check_cond == RANGE_IN)
         {
           command_string += ":IN";
         }
         else
         {
           command_string += ":OUT";
         }
       }
       
        Osci_logi.send_string = command_string;
        Osci_logi.settings_prefer.send_text.set(index, command_string);
        // コマンドに応じた調整
        check_command_string();
    }                                         
    
  //  RB 0 1 4 5 7 8 9 15
  //     0 1 2 3 4 5 6 7
  private int log_bit = 0;
  private int trig_bit = 0;
  private int mask_bit = 0;
  
  private void lch_select_common( int bit, boolean flag ) {
      int select_bit = 0;
      Color set_color;
      
      if( flag )
      {
        set_color = Color.ORANGE;
      }
      else
      {
        set_color = Color.BLACK;
      }
      
      switch( bit )
      {
          case 0:
              B_lch0.setForeground( set_color );
              select_bit = 0x0001;
              break;
          case 1:
              B_lch1.setForeground( set_color );
              select_bit = 0x0002;
              break;
          case 2:
              B_lch2.setForeground( set_color );
              select_bit = 0x0010;
              break;
          case 3:
              B_lch3.setForeground( set_color );
              select_bit = 0x0020;
              break;
          case 4:
              B_lch4.setForeground( set_color );
              select_bit = 0x0080;
              break;
          case 5:
              B_lch5.setForeground( set_color );
              select_bit = 0x0100;
              break;
          case 6:
//              B_lch6.setForeground( set_color );
              select_bit = 0x0200;
              break;
          case 7:
//              B_lch7.setForeground( set_color );
              select_bit = 0x8000;
              break;
      }
      
      if( !flag )
      {
          select_bit =  ~select_bit;
          log_bit &= select_bit;
      }
      else
      {
          log_bit |= select_bit;
      }
      
//      System.out.print( Integer.toBinaryString( select_bit ) + " "+ Integer.toBinaryString( log_bit )+"\n");
      
      if (( ( log_bit & 0x00ff )!= 0 ) &&( ( log_bit & 0xff00 )!= 0 ) )
      {
           command.set_type = "LSBT";
           command.set_data = "BOTH";
           tourokuAction_common();
           T_l_sample.setText("4096");
      }
      else if( ( log_bit & 0x00ff )!= 0 )
      {
           command.set_type = "LSBT";
           command.set_data = "LOWR";
           tourokuAction_common();
           T_l_sample.setText("8192");
      }
      else if( ( log_bit & 0xff00 )!= 0 )
      {
           command.set_type = "LSBT";
           command.set_data = "UPER";
           tourokuAction_common();
           T_l_sample.setText("8192");
      }
      else
      {
           command.set_type = "LSBT";
           command.set_data = "NONE";
           tourokuAction_common();
           T_l_sample.setText("----");
      }
  }
  
  private boolean lch0_selected;
  private boolean lch1_selected;
  private boolean lch2_selected;
  private boolean lch3_selected;
  private boolean lch4_selected;
  private boolean lch5_selected;
          
    private void B_lch0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch0_selected )
        {
          lch0_selected = false;
//          B_lch0.setForeground( Color.BLACK );
        }
        else
        {
//        B_lch0.setForeground( Color.ORANGE );
          lch0_selected = true;
        }
        lch_select_common( 0, lch0_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
    }                                           

  private void B_lch1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch1_selected )
        {
          lch1_selected = false;
//          B_lch1.setForeground( Color.BLACK );
        }
        else
        {
          lch1_selected = true;
//          B_lch1.setForeground( Color.ORANGE );
        }
        lch_select_common( 1, lch1_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
   }
  
  private void B_lch2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch2_selected )
        {
          lch2_selected = false;
//          B_lch2.setForeground( Color.BLACK );
        }
        else
        {
          lch2_selected = true;
//          B_lch2.setForeground( Color.ORANGE );
        }
        lch_select_common( 2, lch2_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
    }                                           

    private void B_lch3ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch3_selected )
        {
          lch3_selected = false;
//          B_lch3.setForeground( Color.BLACK );
        }
        else
        {
          lch3_selected = true;
//          B_lch3.setForeground( Color.ORANGE );
        }
        lch_select_common( 3, lch3_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
    }
  
    private void B_lch4ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch4_selected )
        {
          lch4_selected = false;
//          B_lch4.setForeground( Color.BLACK );
        }
        else
        {
          lch4_selected = true;
//          B_lch4.setForeground( Color.ORANGE );
        }
        lch_select_common( 4, lch4_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
    }
    
    private void B_lch5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        if( lch5_selected )
        {
          lch5_selected = false;
//          B_lch5.setForeground( Color.BLACK );
        }
        else
        {
          lch5_selected = true;
//          B_lch5.setForeground( Color.ORANGE );
        }
        lch_select_common( 5, lch5_selected );
        Osci_logi.settings_prefer.lsbt = log_bit;
    }                                           

    private void lr_select_common() {
     B_lr1.setForeground( Color.BLACK );
     B_lr2.setForeground( Color.BLACK );
     B_lr5.setForeground( Color.BLACK );
     B_lr10.setForeground( Color.BLACK );
     B_lr20.setForeground( Color.BLACK );
     B_lr50.setForeground( Color.BLACK );
     B_lr100.setForeground( Color.BLACK );
     B_lr200.setForeground( Color.BLACK );
     B_lr500.setForeground( Color.BLACK );
     B_lr1000.setForeground( Color.BLACK );
     B_lr2000.setForeground( Color.BLACK );
  }

  private int l_rate;
  private int l_unit;

   private void B_lr1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr1.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "1";
           tourokuAction_common(); 
           l_rate = 1;
   }                                           

  private void B_lr2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr2.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "2";
           tourokuAction_common(); 
           l_rate = 2;
    }
    
  private void B_lr5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr5.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "5";
           tourokuAction_common(); 
           l_rate = 5;
  }                                           

  private void B_lr10ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr10.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "10";
           tourokuAction_common(); 
           l_rate = 10;
  }                                           

  private void B_lr20ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr20.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "20";
           tourokuAction_common(); 
           l_rate = 20;
    }                                           


    private void B_lr50ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr50.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "50";
           tourokuAction_common(); 
           l_rate = 50;
    }                                           

  private void B_lr100ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr100.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "100";
           tourokuAction_common(); 
           l_rate = 100;
    }                                           
  
    private void B_lr200ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr200.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "200";
           tourokuAction_common(); 
           l_rate = 200;
    }                                           
  
    private void B_lr500ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr500.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "500";
           tourokuAction_common(); 
           l_rate = 500;
    }                                           

  private void B_lr1000ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr1000.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "1000";
           tourokuAction_common(); 
           l_rate = 1000;
    }                                           

  private void B_lr2000ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           lr_select_common();
           B_lr2000.setForeground( Color.ORANGE );
           command.set_type = "LSRT";
           command.set_data = "2000";
           tourokuAction_common(); 
           l_rate = 2000;
    }                                           

  private static final int TRIG_HI = 1;
  private static final int TRIG_LOW = 2;
  private int l_trig_0;
  private int l_trig_1;
  private int l_trig_2;
  private int l_trig_3;
  private int l_trig_4;
  private int l_trig_5;
  
  private String bit_string;
  private void bit_string_ope( int posi, char l)
  {
      String front = "";
      String rear = "";
      if( posi == 0)
      {
        front = "";
        rear = bit_string.substring( 1 );
      }
      if( posi == 15)
      {
        front = bit_string.substring( 0, 15 );
        rear = "";
      }
      else
      {
        front = bit_string.substring( 0, posi );
        rear = bit_string.substring( posi+1 );
      }
      bit_string = front.concat(String.valueOf(l));
      bit_string = bit_string.concat(rear);
  }
  
  private int bit_posi( int l_ch )
  {
//      0   1  2  3  4  5 
//   RB 0   1  4  5  7  8 9 15
//      15 14 11 10  8  7 6  0
      int ret;
      switch( l_ch )
      {
          case 0: ret = 15; break;
          case 1: ret = 14; break;
          case 2: ret = 11; break;
          case 3: ret = 10; break;
          case 4: ret = 8; break;
          case 5: ret = 7; break;
          case 6: ret = 6; break;
          case 7:
          default : ret = 0; break;
      }
      System.out.print( String.valueOf(l_ch) + " " + String.valueOf(ret)+"\n" );
      return ret;
  }

  private void set_trig_timer()
  {
    command.set_type = "TTMR";
    if( l_trig_cond == TRIG_OFF )
    {
        if( ( otrig0cond != TRIG_OFF )||( otrig1cond != TRIG_OFF ) )
        {
          command.set_data = "OSCI";
        }
        else
        {
          command.set_data = "NULL";
        }
    }
    else if( ( otrig0cond != TRIG_OFF )||( otrig1cond != TRIG_OFF ) )
    {
      long l,o;
      
      l = l_rate;
      l *= l_unit;
      o = o_rate;
      o *= o_unit;
      if( l > o )
      {
        command.set_data = "LOGI";
      }
      else
      {
        command.set_data = "OSCI";
      }
    }
    else
    {
      command.set_data = "LOGI";
    }
    tourokuAction_common();
  }
  
  private void l_trig_common()
  {
    int bit_pattern;    
    if( l_trig_cond == TRIG_OFF )
    {
       command.set_data = "NULL";
       command.set_type = "LCBT";
       tourokuAction_common(); 
       command.set_type = "LCMK";
       tourokuAction_common(); 
       command.set_type = "LPTN";
       tourokuAction_common(); 
       command.set_type = "LPMK";
       tourokuAction_common();
       command.set_type = "TLGI";
       command.set_data = "NULL";
       tourokuAction_common();
       
       Osci_logi.settings_prefer.lptn  = 0;
       Osci_logi.settings_prefer.lpmk = 0;
       Osci_logi.settings_prefer.lcbt = 0;
       Osci_logi.settings_prefer.lcmk = 0;

//       command.set_type = "TTMR";
//       command.set_data = "OSCI";
//       tourokuAction_common();
    }
    else if( l_trig_cond == PTRN_TRIG )
    {
      bit_string = "0000000000000000";
      mask_bit = 0;
      trig_bit = 0;
      if( l_trig_0 == TRIG_HI )
      {
        bit_string_ope( bit_posi(0) , '1' );
        bit_pattern = get_bit_pattern( 0 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_1 == TRIG_HI )
      {
        bit_string_ope( bit_posi(1) , '1' );
        bit_pattern = get_bit_pattern( 1 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_2 == TRIG_HI )
      {
        bit_string_ope( bit_posi(2) , '1' );
        bit_pattern = get_bit_pattern( 2 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_3 == TRIG_HI )
      {
        bit_string_ope( bit_posi(3) , '1' );
        bit_pattern = get_bit_pattern( 3 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_4 == TRIG_HI )
      {
        bit_string_ope( bit_posi(4) , '1' );
        bit_pattern = get_bit_pattern( 4 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_5 == TRIG_HI )
      {
        bit_string_ope( bit_posi(5) , '1' );
        bit_pattern = get_bit_pattern( 5 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      command.set_type = "LPTN";
      command.set_data = bit_string;
      tourokuAction_common(); 
      System.out.print("LPTN"+bit_string+"\n");
//      bit_string = "abcdefghijklmnop";
      bit_string = "0000000000000000";
      if( l_trig_0 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(0) , '1' );
        bit_pattern = get_bit_pattern( 0 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_1 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(1) , '1' );
        bit_pattern = get_bit_pattern( 1 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_2 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(2) , '1' );
        bit_pattern = get_bit_pattern( 2 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_3 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(3) , '1' );
        bit_pattern = get_bit_pattern( 3 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_4 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(4) , '1' );
        bit_pattern = get_bit_pattern( 4 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_5 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(5) , '1' );
        bit_pattern = get_bit_pattern( 5 );
        mask_bit |= bit_pattern;
      }
      command.set_type = "LPMK";
      command.set_data = bit_string;
      System.out.print("LPMK"+bit_string+"\n");
       tourokuAction_common(); 
       command.set_data = "NULL";
       command.set_type = "LCBT";
       tourokuAction_common(); 
       command.set_type = "LCMK";
       tourokuAction_common(); 
       command.set_type = "TLGI";
       command.set_data = "PTRN";
       tourokuAction_common();
       
       Osci_logi.settings_prefer.lptn  = trig_bit;
       Osci_logi.settings_prefer.lpmk = mask_bit;
    }
    else   // l_trig_cond == BCHG_TRIG
    {
//      bit_string = "abcdefghijklmnop";
      bit_string = "0000000000000000";
    if( l_trig_0 == TRIG_HI )
      {
        bit_string_ope( bit_posi(0) , '1' );
        bit_pattern = get_bit_pattern( 0 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_1 == TRIG_HI )
      {
        bit_string_ope( bit_posi(1) , '1' );
        bit_pattern = get_bit_pattern( 1 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_2 == TRIG_HI )
      {
        bit_string_ope( bit_posi(2) , '1' );
        bit_pattern = get_bit_pattern( 2 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_3 == TRIG_HI )
      {
        bit_string_ope( bit_posi(3) , '1' );
        bit_pattern = get_bit_pattern( 3 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_4 == TRIG_HI )
      {
        bit_string_ope( bit_posi(4) , '1' );
        bit_pattern = get_bit_pattern( 4 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      if( l_trig_5 == TRIG_HI )
      {
        bit_string_ope( bit_posi(5) , '1' );
        bit_pattern = get_bit_pattern( 5 );
        mask_bit |= bit_pattern;
        trig_bit |= bit_pattern;
      }
      command.set_type = "LCBT";
      command.set_data = bit_string;
      tourokuAction_common(); 
      System.out.print("LCBT"+bit_string+"\n");

//      bit_string = "abcdefghijklmnop";
      bit_string = "0000000000000000";
    if( l_trig_0 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(0) , '1' );
        bit_pattern = get_bit_pattern( 0 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_1 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(1) , '1' );
        bit_pattern = get_bit_pattern( 1 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_2 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(2) , '1' );
        bit_pattern = get_bit_pattern( 2 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_3 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(3) , '1' );
        bit_pattern = get_bit_pattern( 3 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_4 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(4) , '1' );
        bit_pattern = get_bit_pattern( 4 );
        mask_bit |= bit_pattern;
      }
      if( l_trig_5 != TRIG_OFF )
      {
        bit_string_ope( bit_posi(5) , '1' );
        bit_pattern = get_bit_pattern( 5 );
        mask_bit |= bit_pattern;
      }
      command.set_type = "LCMK";
      command.set_data = bit_string;
      tourokuAction_common();
      System.out.print("LCMK"+bit_string+"\n");

       command.set_data = "NULL";
       command.set_type = "LPTN";
       tourokuAction_common(); 
       command.set_type = "LPMK";
       tourokuAction_common();
       command.set_type = "TLGI";
       command.set_data = "BCHG";
       tourokuAction_common();
       
       Osci_logi.settings_prefer.lcbt = trig_bit;
       Osci_logi.settings_prefer.lcmk = mask_bit;
    }
    set_trig_timer();
    
  }
  
  private void B_ltrig0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch0_selected )return;
    
    if( l_trig_0 == TRIG_HI )
    {
      l_trig_0 = TRIG_LOW;
      B_ltrig0.setText("LOW");
    }
    else if( l_trig_0 == TRIG_LOW )
    {
      l_trig_0 = TRIG_OFF;
      B_ltrig0.setText("---");
    }
    else
    {
      l_trig_0 = TRIG_HI;
      B_ltrig0.setText("HI");
    }
    l_trig_common();
  }                                           

  private void B_ltrig1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch1_selected )return;

    if( l_trig_1 == TRIG_HI )
    {
      l_trig_1 = TRIG_LOW;
      B_ltrig1.setText("LOW");
    }
    else if( l_trig_1 == TRIG_LOW )
    {
      l_trig_1 = TRIG_OFF;
      B_ltrig1.setText("---");
    }
    else
    {
      l_trig_1 = TRIG_HI;
      B_ltrig1.setText("HI");
    }
    l_trig_common();
  }                                           

  private void B_ltrig2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch2_selected )return;

    if( l_trig_2 == TRIG_HI )
    {
      l_trig_2 = TRIG_LOW;
      B_ltrig2.setText("LOW");
    }
    else if( l_trig_2 == TRIG_LOW )
    {
      l_trig_2 = TRIG_OFF;
      B_ltrig2.setText("---");
    }
    else
    {
      l_trig_2 = TRIG_HI;
      B_ltrig2.setText("HI");
    }
    l_trig_common();
  }                                           

  private void B_ltrig3ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch3_selected )return;

    if( l_trig_3 == TRIG_HI )
    {
      l_trig_3 = TRIG_LOW;
      B_ltrig3.setText("LOW");
    }
    else if( l_trig_3 == TRIG_LOW )
    {
      l_trig_3 = TRIG_OFF;
      B_ltrig3.setText("---");
    }
    else
    {
      l_trig_3 = TRIG_HI;
      B_ltrig3.setText("HI");
    }
    l_trig_common();
  }                                           

  private void B_ltrig4ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch4_selected )return;

    if( l_trig_4 == TRIG_HI )
    {
      l_trig_4 = TRIG_LOW;
      B_ltrig4.setText("LOW");
    }
    else if( l_trig_4 == TRIG_LOW )
    {
      l_trig_4 = TRIG_OFF;
      B_ltrig4.setText("---");
    }
    else
    {
      l_trig_4 = TRIG_HI;
      B_ltrig4.setText("HI");
    }
    l_trig_common();
  }                                           

  private void B_ltrig5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    if( !lch5_selected )return;

    if( l_trig_5 == TRIG_HI )
    {
      l_trig_5 = TRIG_LOW;
      B_ltrig5.setText("LOW");
    }
    else if( l_trig_5 == TRIG_LOW )
    {
      l_trig_5 = TRIG_OFF;
      B_ltrig5.setText("---");
    }
    else
    {
      l_trig_5 = TRIG_HI;
      B_ltrig5.setText("HI");
    }
    l_trig_common();
  }                                           

  private static final int PTRN_TRIG = 1;
  private static final int BCHG_TRIG = 2;
  private int l_trig_cond;
  private void B_ltrigcondActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( l_trig_cond == PTRN_TRIG )
      {
        l_trig_cond = BCHG_TRIG;
        B_ltrigcond.setText("BCHG");
      }
      else if( l_trig_cond == BCHG_TRIG )
      {
        l_trig_cond = TRIG_OFF;
        B_ltrigcond.setText("OFF");
      }
      else
      {
        l_trig_cond = PTRN_TRIG;
        B_ltrigcond.setText("PTRN");
      }
    l_trig_common();
  }

  private void B_lmodeActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }
    
  private boolean och0_selected;
  private boolean och1_selected;

  private void och_select_common() {
      command.set_type = "OSCH";
      if( ( och0_selected )&&( och1_selected ))
      {
        command.set_data = "BOTH";
/*
        if(( otrig0cond != TRIG_OFF )&&( otrig1cond != TRIG_OFF ))
        {
          otrig_andor = TRIG_AND;
          B_otrig_andor.setText("AND");
        }
*/        
        T_o_sample.setText("4096");
//        B_or500.setVisible(false);
        B_or500.setForeground( Color.GRAY );
      }
      else if( och0_selected )
      {
        command.set_data = "CH0";
        otrig_andor = TRIG_OFF;
//        B_otrig_andor.setText("OFF");
        T_o_sample.setText("8192");
        B_or500.setVisible(true);
        B_or500.setForeground( Color.BLACK );
    }
      else if( och1_selected )
      {
        command.set_data = "CH1";
        otrig_andor = TRIG_OFF;
//        B_otrig_andor.setText("OFF");
        T_o_sample.setText("8192");
        B_or500.setVisible(true);
        B_or500.setForeground( Color.BLACK );
      }
      else
      {
        command.set_data = "NULL";
//      otrig0cond = TRIG_OFF;
//      B_otrig0cond.setText("OFF");
//      otrig1cond = TRIG_OFF;
//      B_otrig1cond.setText("OFF");
        T_o_sample.setText("----");
      }
      tourokuAction_common();
  }

   private void och_trig_common() {
      command.set_type = "TOSC";
      if( !och0_selected )
      {
        B_otrig_andor.setText("OFF");
        otrig0cond = TRIG_OFF;
      }
      
      if( !och1_selected )
      {
        B_otrig_andor.setText("OFF");
        otrig1cond = TRIG_OFF;
      }

      if(( otrig0cond != TRIG_OFF )&&( otrig1cond != TRIG_OFF ) )
      {
        if( otrig_andor == TRIG_OR  )
        {
          B_otrig_andor.setText("OR");
          command.set_data = "OR";
        }
        else
        {
          otrig_andor = TRIG_AND;
          B_otrig_andor.setText("AND");
          command.set_data = "AND";
        }
      }
      else if( otrig0cond != TRIG_OFF )
      {
        B_otrig_andor.setText("OFF");
        B_otrig1cond.setText("OFF");
        otrig_andor = TRIG_OFF;
        command.set_data = "CH0";
      }
      else if( otrig1cond != TRIG_OFF )
      {
        B_otrig_andor.setText("OFF");
        B_otrig0cond.setText("OFF");
        otrig_andor = TRIG_OFF;
        command.set_data = "CH1";
      }
      else
      {
        B_otrig0cond.setText("OFF");
        B_otrig1cond.setText("OFF");
        command.set_data = "NULL";
      }
      tourokuAction_common();
      set_trig_timer();
  }

  private void B_och0ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( och0_selected )
      {
          och0_selected = false;
           B_och0.setForeground( Color.BLACK );
      }
      else
      {
          och0_selected = true;
          B_och0.setForeground( Color.ORANGE );
      }
      och_select_common();
      och_trig_common();
    }                                           

  private void B_och1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( och1_selected )
      {
          och1_selected = false;
           B_och1.setForeground( Color.BLACK );
      }
      else
      {
          och1_selected = true;
           B_och1.setForeground( Color.ORANGE );
      }
      och_select_common();
      tourokuAction_common(); 
    }
  
  private void or_select_common() {
     B_or1.setForeground( Color.BLACK );
     B_or2.setForeground( Color.BLACK );
     B_or5.setForeground( Color.BLACK );
     B_or10.setForeground( Color.BLACK );
     B_or20.setForeground( Color.BLACK );
     B_or50.setForeground( Color.BLACK );
     B_or100.setForeground( Color.BLACK );
     B_or200.setForeground( Color.BLACK );
     B_or500.setForeground( Color.BLACK );
  }

  private int o_rate;
  private int o_unit;
  
  private void B_or1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or1.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "1";
           tourokuAction_common();
           o_rate = 1;
        }                                           

  private void B_or2ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or2.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "2";
           tourokuAction_common(); 
           o_rate = 2;
    }                                           

    private void B_or5ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or5.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "5";
           tourokuAction_common();
           o_rate = 5;
    }                                           

  private void B_or10ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or10.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "10";
           tourokuAction_common(); 
           o_rate = 10;
    }                                           

  private void B_or20ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or20.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "20";
           tourokuAction_common(); 
           o_rate = 20;
    }                                           

  private void B_or50ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or50.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "50";
           tourokuAction_common();
           o_rate = 50;
    }                                           

  private void B_or100ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or100.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "100";
           tourokuAction_common(); 
           o_rate = 100;
    }                                           

  private void B_or200ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           or_select_common();
           B_or200.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "200";
           tourokuAction_common(); 
           o_rate = 200;
    }                                           

  private void B_or500ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           if( ( och0_selected )&&( och1_selected ))return;
           or_select_common();
           B_or500.setForeground( Color.ORANGE );
           command.set_type = "OSRT";
           command.set_data = "500";
           tourokuAction_common(); 
           o_rate = 500;
    }
  
  private static final int UNIT_mHZ = 1;
  private static final int UNIT_HZ = 1000;
  private static final int UNIT_kHZ = 1000000;
  
  private void B_omHzActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           B_omHz.setForeground( Color.ORANGE );
           B_okHz.setForeground( Color.BLACK );
           B_oHz.setForeground( Color.BLACK );
           command.set_type = "OSUT";
           command.set_data = "mHz";
           tourokuAction_common(); 
           o_unit = UNIT_mHZ;
  }                                   

  private void B_okHzActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           B_omHz.setForeground( Color.BLACK );
           B_okHz.setForeground( Color.ORANGE );
           B_oHz.setForeground( Color.BLACK );
           command.set_type = "OSUT";
           command.set_data = "kHz";
           tourokuAction_common(); 
           o_unit = UNIT_kHZ;
    }                                           
//        T_otirg1max = new javax.swing.JTextField();
//        T_otrig1min = new javax.swing.JTextField();
    private void B_oHzActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
           B_omHz.setForeground( Color.BLACK );
           B_okHz.setForeground( Color.BLACK );
           B_oHz.setForeground( Color.ORANGE );
           command.set_type = "OSUT";
           command.set_data = "Hz";
           tourokuAction_common();
           o_unit = UNIT_HZ;
    }                                           

  private int otrigsel;
  private static final int CH0_MAX = 1;
  private static final int CH1_MAX = 2;
  private static final int MAX_OFF = 0;

  private static final int CH0_MIN = 3;
  private static final int CH1_MIN = 4;
  private static final int MIN_OFF = 0;

  private String limit_string;
  
  private void set_slider_common( )
  {
      int slider_posi;
      slider_posi = Integer.valueOf(limit_string);
      B_range.setText("広域");
      fine_coarse =  COARSE;
      hBar.setMaximum(1023);
      hBar.setMinimum(0);
      hBar.setValue(slider_posi);
  }
  
  private void B_otrigselmaxActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      B_otrigselmin.setText("   ");
      if( otrigsel == CH0_MAX )
      {
        otrigsel = CH1_MAX;
        B_otrigselmax.setText("==>");
        limit_string = T_otrig1max.getText();
        set_slider_common();
      }
      else if( otrigsel == CH1_MAX )
      {
        otrigsel = MAX_OFF;
        B_otrigselmax.setText("   ");
      }
      else
      {
        otrigsel = CH0_MAX;
        B_otrigselmax.setText("<==");
        limit_string = T_otrig0max.getText();
        set_slider_common();
      }
    }                                           

  private void B_otrigselminActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      B_otrigselmax.setText("   ");
      if( otrigsel == CH0_MIN )
      {
        otrigsel = CH1_MIN;
        B_otrigselmin.setText("==>");
        limit_string = T_otrig1min.getText();
        set_slider_common();
      }
      else if( otrigsel == CH1_MIN )
      {
        otrigsel = MIN_OFF;
        B_otrigselmin.setText("   ");
      }
      else
      {
        otrigsel = CH0_MIN;
        B_otrigselmin.setText("<==");
        limit_string = T_otrig0min.getText();
        set_slider_common();
      }
    }

    private void T_otrig0maxFocusGained(java.awt.event.FocusEvent evt) {                                         
        // TODO add your handling code here:
    }

    private void T_otrig1maxFocusGained(java.awt.event.FocusEvent evt) {                                         
        // TODO add your handling code here:
    }

    private void T_otrig0minFocusGained(java.awt.event.FocusEvent evt) {                                         
        // TODO add your handling code here:
    }

    private void T_otrig1minFocusGained(java.awt.event.FocusEvent evt) {                                         
        // TODO add your handling code here:
    }

  private void B_otirg_link_condActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

  private static final int RANGE_IN = 1;
  private static final int RANGE_OUT = 2;
  private static final int TRIG_OFF = 0;
  private int otrig0cond = TRIG_OFF;
  private int otrig1cond = TRIG_OFF;
  
  private void B_otrig0condActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( !och0_selected )return;

      if( otrig0cond == RANGE_IN )
      {
        otrig0cond = RANGE_OUT;
        B_otrig0cond.setText("OUT");
      }
      else if( otrig0cond == RANGE_OUT )
      {
        otrig0cond = TRIG_OFF;
        B_otrig0cond.setText("OFF");
      }
      else
      {
        otrig0cond = RANGE_IN;
        B_otrig0cond.setText("IN");
      }
      och_trig_common();
      o_trig_common( CH0_MIN );
    }                                           

  private void B_otrig1condActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( !och1_selected )return;
      
      if( otrig1cond == RANGE_IN )
      {
        otrig1cond = RANGE_OUT;
        B_otrig1cond.setText("OUT");
      }
      else if( otrig1cond == RANGE_OUT )
      {
        otrig1cond = TRIG_OFF;
        B_otrig1cond.setText("OFF");
      }
      else
      {
        otrig1cond = RANGE_IN;
        B_otrig1cond.setText("IN");
      }
      och_trig_common();
      o_trig_common( CH1_MIN );
    }

  private static final int TRIG_AND = 1;
  private static final int TRIG_OR = 2;
  private int otrig_andor;
  private void B_otrig_andorActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
      if( !och0_selected )return;
      else if( !och1_selected )return;

      if( otrig_andor == TRIG_AND )
      {
        otrig_andor = TRIG_OR;
//        B_otrig_andor.setText("OR");
      }
      else if( otrig_andor == TRIG_OR )
      {
        otrig_andor = TRIG_AND;
//        B_otrig_andor.setText("AND");
      }
      och_trig_common();
   }
  
    private void B_omodeActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }

  private void B_trig_link_condActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }

  private static final int START_TRIG = 1;
  private static final int END_TRIG = 2;
  private static final int CENTER_TRIG = 3;
  private int trig_mode = END_TRIG;
  
  private void B_trig_modeActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
      if( trig_mode == START_TRIG )
      {
        trig_mode = CENTER_TRIG;
        B_trig_mode.setText("CNTR");
        command.set_data = "CNTR";
      }
      else if( trig_mode == CENTER_TRIG )
      {
        trig_mode = END_TRIG;
        B_trig_mode.setText("END");
        command.set_data = "END";
      }
      else
      {
        trig_mode = START_TRIG;
        B_trig_mode.setText("STRT");
        command.set_data = "STRT";
      }
      command.set_type = "TMOD";
      tourokuAction_common(); 
  }                                           

  private void B_hannpukuActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

  private void B_shuuryouActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_jyusinn0ActionPerformed
        // TODO add your handling code here:
              Osci_logi.brk_flag = true;
    }//GEN-LAST:event_jB_jyusinn0ActionPerformed

    private void B_keisokuActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
        Osci_logi.send_flag = true;
//        Osci_logi.log_flag = true;
        
    }                                          

  private void B_tyuudanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_shuuryouActionPerformed
        // TODO add your handling code here:
        Osci_logi.send_brk_flag = true;
        Osci_logi.receive_flag = true;
        Osci_logi.receive_oscillo_flag = true;
        Osci_logi.receive_logiana_flag = true;
        Osci_logi.receive_parameter_flag = true;
    }//GEN-LAST:event_b_shuuryouActionPerformed

//    private void send_commandComponentShown(java.awt.event.ComponentEvent evt) {                                            
        // TODO add your handling code here:
//    }                                           

    private void hBarCaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_send_commandComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_send_commandComponentShown

    private void o_trig_common( int trig_sel )
    {
        switch( trig_sel )
        {
            case CH0_MAX:
                command.set_data = T_otrig0max.getText();
                command.set_type = "O0UL";
//                if( otrig0cond != RANGE_OUT )
//                {
//                    otrig0cond = RANGE_IN;
//                }
                break;
            case CH1_MAX:
                command.set_data = T_otrig1max.getText();
                command.set_type = "O1UL";
//                if( otrig1cond != RANGE_OUT )
//                {
//                    otrig1cond = RANGE_IN;
//                }
                break;
            case CH0_MIN:
                command.set_data = T_otrig0min.getText();
                command.set_type = "O0LL";
//                if( otrig0cond != RANGE_OUT )
//                {
//                    otrig0cond = RANGE_IN;
//                }
                break;
            case CH1_MIN:
                command.set_data = T_otrig1min.getText();
                command.set_type = "O1LL";
//                if( otrig1cond != RANGE_OUT )
//                {
//                    otrig1cond = RANGE_IN;
//                }
                break;
        }
        tourokuAction_common(); 
    }
    
    private void hBarStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_hBarStateChanged
        // TODO add your handling code here:
        int limit_val;
        limit_val = hBar.getValue();
        limit_string = String.valueOf(limit_val);
        switch( otrigsel )
        {
            case CH0_MAX:
                T_otrig0max.setText(limit_string);
                Osci_logi.settings_prefer.ch0_trig_max = limit_val;
                break;
            case CH1_MAX:
                T_otrig1max.setText(limit_string);
                Osci_logi.settings_prefer.ch1_trig_max = limit_val;
                break;
            case CH0_MIN:
                T_otrig0min.setText(limit_string);
                Osci_logi.settings_prefer.ch0_trig_min = limit_val;
                break;
            case CH1_MIN:
                T_otrig1min.setText(limit_string);
                Osci_logi.settings_prefer.ch1_trig_min = limit_val;
                break;
        }
        o_trig_common( otrigsel );
    }//GEN-LAST:event_hBarStateChanged

    private boolean fine_coarse;
    private static final boolean FINE = true;
    private static final boolean COARSE  = false;
    
    private void B_rangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_rangeActionPerformed
        // TODO add your handling code here:
        int current_val;
        current_val = hBar.getValue();
        if( fine_coarse == FINE )
        {
          B_range.setText("広域");
          fine_coarse =  COARSE;
          hBar.setMaximum(1023);
          hBar.setMinimum(0);
        }
        else 
        {
          B_range.setText("詳細");
          fine_coarse =  FINE;
          if( current_val >= 20 )
          {
            hBar.setMaximum(current_val+20);
            hBar.setMinimum(current_val-20);
          }
          else
          {
            hBar.setMaximum(40);
            hBar.setMinimum(0);
          }
        }
    }//GEN-LAST:event_B_rangeActionPerformed

    private void B_lmHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lmHzActionPerformed
        // TODO add your handling code here:
           B_lmHz.setForeground( Color.ORANGE );
           B_lkHz.setForeground( Color.BLACK );
           B_lHz.setForeground( Color.BLACK );
           command.set_type = "LSUT";
           command.set_data = "mHz";
           tourokuAction_common(); 
           l_unit = UNIT_mHZ;
    }//GEN-LAST:event_B_lmHzActionPerformed

    private void B_lHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lHzActionPerformed
        // TODO add your handling code here:
           B_lmHz.setForeground( Color.BLACK );
           B_lkHz.setForeground( Color.BLACK );
           B_lHz.setForeground( Color.ORANGE );
           command.set_type = "LSUT";
           command.set_data = "Hz";
           tourokuAction_common(); 
           l_unit = UNIT_HZ;
    }//GEN-LAST:event_B_lHzActionPerformed

    private void B_lkHzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_lkHzActionPerformed
        // TODO add your handling code here:
           B_lmHz.setForeground( Color.BLACK );
           B_lkHz.setForeground( Color.ORANGE );
           B_lHz.setForeground( Color.BLACK );
           command.set_type = "LSUT";
           command.set_data = "kHz";
           tourokuAction_common(); 
           l_unit = UNIT_kHZ;
    }//GEN-LAST:event_B_lkHzActionPerformed

    private void B_showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_showActionPerformed
        // TODO add your handling code here:
        show_send_command();
    }//GEN-LAST:event_B_showActionPerformed
  
/**
     * @param args the command line arguments
     */
    public void Osci_logi_Comm_main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Osci_logi_Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Osci_logi_Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Osci_logi_Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Osci_logi_Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Osci_logi_Comm().setVisible(true);
//            }
//        });
    }

    public void Open(){
        setVisible(true);
    }
    
    public void Close(){
        setVisible(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B_hannpuku;
    private javax.swing.JButton B_keisoku;
    private javax.swing.JButton B_lHz;
    private javax.swing.JButton B_lch0;
    private javax.swing.JButton B_lch1;
    private javax.swing.JButton B_lch2;
    private javax.swing.JButton B_lch3;
    private javax.swing.JButton B_lch4;
    private javax.swing.JButton B_lch5;
    private javax.swing.JButton B_lkHz;
    private javax.swing.JButton B_lmHz;
    private javax.swing.JButton B_lmode;
    private javax.swing.JButton B_lr1;
    private javax.swing.JButton B_lr10;
    private javax.swing.JButton B_lr100;
    private javax.swing.JButton B_lr1000;
    private javax.swing.JButton B_lr2;
    private javax.swing.JButton B_lr20;
    private javax.swing.JButton B_lr200;
    private javax.swing.JButton B_lr2000;
    private javax.swing.JButton B_lr5;
    private javax.swing.JButton B_lr50;
    private javax.swing.JButton B_lr500;
    private javax.swing.JButton B_ltrig0;
    private javax.swing.JButton B_ltrig1;
    private javax.swing.JButton B_ltrig2;
    private javax.swing.JButton B_ltrig3;
    private javax.swing.JButton B_ltrig4;
    private javax.swing.JButton B_ltrig5;
    private javax.swing.JButton B_ltrigcond;
    private javax.swing.JButton B_oHz;
    private javax.swing.JButton B_och0;
    private javax.swing.JButton B_och1;
    private javax.swing.JButton B_okHz;
    private javax.swing.JButton B_omHz;
    private javax.swing.JButton B_omode;
    private javax.swing.JButton B_or1;
    private javax.swing.JButton B_or10;
    private javax.swing.JButton B_or100;
    private javax.swing.JButton B_or2;
    private javax.swing.JButton B_or20;
    private javax.swing.JButton B_or200;
    private javax.swing.JButton B_or5;
    private javax.swing.JButton B_or50;
    private javax.swing.JButton B_or500;
    private javax.swing.JButton B_otrig0cond;
    private javax.swing.JButton B_otrig1cond;
    private javax.swing.JButton B_otrig_andor;
    private javax.swing.JButton B_otrigselmax;
    private javax.swing.JButton B_otrigselmin;
    private javax.swing.JButton B_range;
    private javax.swing.JButton B_show;
    private javax.swing.JButton B_shuuryou;
    private javax.swing.JButton B_trig_link_cond;
    private javax.swing.JButton B_trig_mode;
    private javax.swing.JButton B_tyuudan;
    private javax.swing.JPanel Ope_pannel;
    private javax.swing.JTextField T_l_sample;
    private javax.swing.JTextField T_o_sample;
    private javax.swing.JTextField T_otrig0max;
    private javax.swing.JTextField T_otrig0min;
    private javax.swing.JTextField T_otrig1max;
    private javax.swing.JTextField T_otrig1min;
    private javax.swing.JSlider hBar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jP_Logiana;
    private javax.swing.JPanel jP_Oscillo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
