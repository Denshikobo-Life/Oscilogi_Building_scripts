package osci_logi;

import dkl.bcm2835;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Osci_logi {

    public static final int UPDATE_INTERVAL = 50;     // 50ms
    static final int BUFF_SIZE = 32;
    static final int OSCILLO_BUFF_SIZE = 16384;
    static final int LOGIANA_BUFF_SIZE = 8192;
    static final int PARAMETER_BUFF_SIZE = 256;
    static final int CH_SIZE = 8;
    static final int RECEIVE_DATA_SIZE = 20;
    static final byte TERMINATE_CODE = 22;
    static final int STATUS_READ_INTERVAL = 5000;
    static boolean brk_flag;
    static String send_string = "";
    static boolean send_flag = false;
    static boolean log_flag = false;
    static boolean send_brk_flag = false;
    static boolean read_status_flag = false;
    static boolean send_status_command_flag = false;
    static boolean receive_flag = false;
    static boolean receive_oscillo_flag = false;
    static boolean receive_logiana_flag = false;
    static boolean receive_parameter_flag = false;
    public static Preference settings_prefer;

    static short[] ch0 = new short[8192];
    static short[] ch1 = new short[8192];
    static short[] logiana = new short[8192];
    static short[] parameter = new short[PARAMETER_BUFF_SIZE / 2];

// Receive Format 
// 20 byte data 
//  1 byte check sum
//  1 byte terminate code = 22
    static boolean format_check(byte[] receive_buff) {
        byte c;
        int posi;
        c = 0;
        for (posi = 0; posi < RECEIVE_DATA_SIZE; posi++) {
            c += receive_buff[posi];
        }
        if (c != receive_buff[posi]) {
            System.out.print(" calc sum=" + Byte.toString(c) + " receive sum=" + Byte.toString(receive_buff[posi]) + "\n");
            return false;
        } else if (receive_buff[posi + 1] != TERMINATE_CODE) {
            System.out.print(" receive code=" + Byte.toString(receive_buff[posi + 1]) + "\n");
            return false;
        }
        return true;
    }

    static void show_receive_data(byte[] receive_buff) {
        byte c;
        int posi;
        byte sum;
        sum = 0;
        System.out.print(" receive data = ");
        for (posi = 0; posi < RECEIVE_DATA_SIZE; posi++) {
            c = receive_buff[posi];
            sum += c;
            System.out.print(Byte.toString(c) + " ");
        }
        c = receive_buff[posi++];
        System.out.print(Byte.toString(c) + " ");
        c = receive_buff[posi];
        System.out.print(Byte.toString(c) + " sum = ");

        System.out.print(Byte.toString(sum) + "\n");
    }

    private static int read_posi;

    private static int read_byte_value() {
        int buff;
        buff = param_buff[read_posi++];
        buff &= 0xff;
        return buff;
    }

    private static int read_short_value() {
        int buff1;
        int buff2;
        buff1 = read_byte_value();
        buff2 = read_byte_value();
        buff2 <<= 8;
        buff2 += buff1;
        return buff2;
    }

    private static int read_int_value() {
        int buff1;
        int buff2;
        buff1 = read_short_value();
        buff2 = read_short_value();
        buff2 <<= 16;
        buff2 += buff1;
        return buff1;
    }

    public static byte[] receive_buff = new byte[BUFF_SIZE];
    public static byte[] i2c_buff = new byte[1024];
    public static byte[] oscillo_buff = new byte[OSCILLO_BUFF_SIZE];
    public static byte[] logiana_buff = new byte[LOGIANA_BUFF_SIZE];
    public static byte[] param_buff = new byte[LOGIANA_BUFF_SIZE];

    public static void main(String[] args) {

        long current_time;
        long prev_time;
        long update_time;
        long half_sec_interval;
        long read_status_time;
//        long keep_time;
//        byte posi;
//        short val;
        byte ret = 0;
        int error_count;
        boolean busy_flag = false;
        boolean meas_flag = false;
//        boolean i2c_switch;

//        Swing_test swing_test = new Swing_test();
        try (FileInputStream inFile = new FileInputStream("preference.obj"); ObjectInputStream inObject = new ObjectInputStream(inFile)) {
            settings_prefer = (Preference) inObject.readObject();
        } catch (IOException | ClassNotFoundException e) {
            settings_prefer = new Preference();
        }

        System.out.print("***************************\n");
        System.out.print("*      OSCILOG32 v0.17    *\n");
        System.out.print("***************************\n");

        Osci_logi_Window window = new Osci_logi_Window();
        window.Init();

//        Mouse mouse = new Mouse();
        bcm2835.bi_init(args[0]);
        bcm2835.i2c_begin();
        bcm2835.i2c_setSlaveAddress((byte) 0x31);
        bcm2835.i2c_set_baudrate(100000);
//        bcm2835.ope_sync();
        current_time = System.currentTimeMillis();
        half_sec_interval = current_time + 500;
        prev_time = current_time;
        read_status_time = current_time;
//        keep_time = 0;
        update_time = prev_time + UPDATE_INTERVAL;
        window.Open();
//        bcm2835.i2c_write("NEXT", 5);
//        bcm2835.ope_sync();
//        bcm2835.i2c_read( receive_buff, 22 );
        error_count = 0;

        brk_flag = false;
        while (!brk_flag) {
            current_time = System.currentTimeMillis();

            if (send_flag) {
                for (String str : Osci_logi.settings_prefer.send_text) {
                    ret = bcm2835.i2c_write(str + '\0', str.length() + 1);
                    System.out.print(str);
                    System.out.print(" " + (int) ret + "\n");
                    bcm2835.ope_sync();
                }
                send_flag = false;
                log_flag = true;
            } else if (log_flag) {
                ret = bcm2835.i2c_write("LOG" + '\0', 4);
                System.out.print("LOG " + (int) ret + "\n");
                bcm2835.ope_sync();
                log_flag = false;
                meas_flag = true;
                read_status_flag = true;
            } else if (send_brk_flag) {
                ret = bcm2835.i2c_write("BRK" + '\0', 4);
                System.out.print("BRK " + (int) ret + "\n");
                bcm2835.ope_sync();
                send_brk_flag = false;
                busy_flag = false;
                meas_flag = false;
            }

            if (current_time >= half_sec_interval) {
                half_sec_interval += 500;
                if (busy_flag) {
                    window.keisoku_flicker();
                } else {
                    window.keisoku_off();
                }
            }
            if (current_time >= update_time) {
                update_time = current_time + UPDATE_INTERVAL;
//             System.out.print( "current_time="+Long.toString( current_time)+"\n" );
//             window.scroll_up();

                if (read_status_flag) {
                    if (send_status_command_flag == false) {
                        ret = bcm2835.i2c_write("STS" + '\0', 4);
                        bcm2835.ope_sync();
                        send_status_command_flag = true;
                    }
                    if (current_time >= read_status_time) {
                        read_status_time = current_time + STATUS_READ_INTERVAL;
                        ret = bcm2835.i2c_read(receive_buff, 1);
                        if (ret == 0) {
//                            try {
                                receive_buff[1] = '\0';
//                                String rec = new String(receive_buff, "UTF-8");
//                                System.out.print("STATUS =" + rec + "\n");
                                busy_flag = (receive_buff[0] == 'B');
                                if ((meas_flag) && (!busy_flag)) {
                                    Osci_logi.receive_flag = true;
                                    Osci_logi.receive_oscillo_flag = true;
                                    Osci_logi.receive_logiana_flag = true;
                                    Osci_logi.receive_parameter_flag = true;
                                    meas_flag = false;
                                }
//                            } catch (UnsupportedEncodingException ex) {
//                                Logger.getLogger(Osci_logi.class.getName()).log(Level.SEVERE, null, ex);
//                            }
                        }
                    }
                }

                if (receive_flag) {
                    int i, j;
                    int count;
                    if (receive_parameter_flag) {
                        ret = bcm2835.i2c_write("RCV 2" + '\0', 6);
//                   System.out.print( "RCV 2 "+(int)ret+"\n");
                        bcm2835.ope_sync();
                        ret = bcm2835.i2c_read(i2c_buff, PARAMETER_BUFF_SIZE);
                        if (ret == 0) {
                            System.arraycopy(i2c_buff, 0, param_buff, 0, PARAMETER_BUFF_SIZE);

                            /*
                             struct LOG_PARAM
                             {
                             unsigned char ps2;
                             unsigned int pr2;
                             unsigned char ps3;
                             unsigned int pr3;
                             unsigned int ch0_trig_count;
                             unsigned int ch0_trig_dpt;
                             unsigned int ch1_trig_count;
                             unsigned int ch1_trig_dpt;
                             unsigned int ch0_end_count;
                             unsigned int ch0_end_dpt;
                             unsigned int ch1_end_count;
                             unsigned int ch1_end_dpt;
                             };
                             */
                            read_posi = 0;
                            System.out.print("ps2=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("pr2=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ps3=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("pr3=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch0_trig_count=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch0_trig_dpt=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch1_trig_count=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch1_trig_dpt=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch0_end_count=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch0_end_dpt=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch1_end_count=" + String.valueOf(read_int_value() + "\n"));
                            System.out.print("ch1_end_dpt=" + String.valueOf(read_int_value() + "\n"));

                            receive_parameter_flag = false;
                        }

                        if (receive_oscillo_flag) {
                            ret = bcm2835.i2c_write("RCV 1" + '\0', 6);
//                   System.out.print( "RCV 1 "+(int)ret+"\n");
                            bcm2835.ope_sync();
                            for (int offset = 0; offset < OSCILLO_BUFF_SIZE;) {
                                ret = bcm2835.i2c_read(i2c_buff, 1024);
                                if (ret != 0) {
                                    break;
                                }
                                for (int o = 0; o < 1024; o++) {
                                    oscillo_buff[offset++] = i2c_buff[o];
                                }
                            }
                            if (ret == 0) {
//                     System.out.print("receive_data=oscillo data\n");
                                count = 0;
                                for (int offset = 0; offset < OSCILLO_BUFF_SIZE; offset += 2) {
                                    i = (int) oscillo_buff[offset];
                                    j = (int) oscillo_buff[offset + 1];
                                    if (i < 0) {
                                        i += 256;
                                    }
                                    if (j < 0) {
                                        j += 256;
                                    }
                                    j *= 256;
                                    j += i;
                                    if ((count % 2) == 0) {
                                        ch0[count / 2] = (short) j;
                                    } else {
                                        ch1[count / 2] = (short) j;
                                    }
                                    count++;
                                }
                                window.show_oscillo();
                            } else {
                                System.out.print("i2c_read =" + (int) ret + "\n");
                            }
                            receive_oscillo_flag = false;
                        }

                        if (receive_logiana_flag) {
                            ret = bcm2835.i2c_write("RCV 0" + '\0', 6);
                            System.out.print("RCV 0 " + (int) ret + "\n");
                            bcm2835.ope_sync();
                            for (int offset = 0; offset < LOGIANA_BUFF_SIZE;) {
                                ret = bcm2835.i2c_read(i2c_buff, 1024);
                                if (ret != 0) {
                                    break;
                                }
                                for (int o = 0; o < 1024; o++) {
                                    logiana_buff[offset++] = i2c_buff[o];
                                }
                            }
                            if (ret == 0) {
                                count = 0;
                                for (int offset = 0; offset < LOGIANA_BUFF_SIZE; offset += 2) {
                                    i = (int) logiana_buff[offset];
                                    j = (int) logiana_buff[offset + 1];
                                    if (i < 0) {
                                        i += 256;
                                    }
                                    if (j < 0) {
                                        j += 256;
                                    }
                                    j *= 256;
                                    j += i;
                                    logiana[count++] = (short) j;
                                    if (((offset % 100) == 0) && (offset > 0)) {
                                    }
                                }
                                System.out.print("receive_data=logiana data\n");
                                window.show_logiana();
                            } else {
                                System.out.print("i2c_read =" + (int) ret + "\n");
                            }
                            receive_logiana_flag = false;
                        }
                        receive_flag = false;
                        bcm2835.i2c_write("STS" + '\0', 4);
                    }
                    bcm2835.ope_sync();
                }
            }
        }
        System.out.print("error_count = " + Integer.toString(error_count) + "\n");
        window.Close();
        bcm2835.i2c_end();
        bcm2835.bi_close();

        try (FileOutputStream outFile = new FileOutputStream("preference.obj"); ObjectOutputStream outObject = new ObjectOutputStream(outFile)) {
            outObject.writeObject(settings_prefer);
        } catch (IOException e) {
            System.out.println(e);
        }
        System.exit(0);
    }
}
