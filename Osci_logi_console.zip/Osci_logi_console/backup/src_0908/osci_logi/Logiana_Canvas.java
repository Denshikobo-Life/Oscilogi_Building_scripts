/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package osci_logi;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 *
 * @author akira
 */
public class Logiana_Canvas extends Canvas {
 //=============================================================================
 //フィールド
 //=============================================================================

 //キャンバスの寸法
 Dimension dimension;

 //グラフ化するデータ 
 int [] bit0;
 int [] bit1;
 int [] bit2;
 int [] bit3;
 int [] bit4;
    private int i;

 //=============================================================================
 //コンストラクタ
 //=============================================================================
 Logiana_Canvas(int width,int height)
 {
  //領域のサイズ設定
  setSize(width,height);

  //領域のサイズ取得
  dimension = getSize();

  //data[]のインスタンス生成
  bit0 = new int[dimension.width];
  bit1 = new int[dimension.width];
  bit2 = new int[dimension.width];
  bit3 = new int[dimension.width];
  bit4 = new int[dimension.width];
  //グラフエリアを灰色に設定
//  setBackground(Color.lightGray);
  setBackground(Osci_logi_Window.CANVAS_COLOR);
 }

 //=============================================================================
 //paint()メソッド
 //=============================================================================
 public void paint(Graphics g)
 {
     int base;
     int offset;
  //領域のサイズ取得
  dimension = getSize();
  //軸の色は黒
//  g.setColor(Color.black);
  g.setColor(Color.GRAY);
  //x軸
  g.drawLine(0,dimension.height/2,dimension.width-1,dimension.height/2);
  //y軸
  g.drawLine(dimension.width/2,0,dimension.width/2,dimension.height-1);


  //グラフ線の色は青に設定
  g.setColor(Color.ORANGE);

  offset = 10;
  //グラフ描画
  for(int i=0;i<dimension.width-2;i++)
  {
   base = dimension.height/6;
   if( ( bit0[i] == 0 ) && ( bit0[i+1] == 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
   }
   if( ( bit0[i] == 0 ) && ( bit0[i+1] != 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
     g.drawLine( i+1, base, i+1, base + offset );
   }
   if( ( bit0[i] != 0 ) && ( bit0[i+1] == 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base + offset );
     g.drawLine( i+1, base + offset, i+1, base );
   }
   if( ( bit0[i] != 0 ) && ( bit0[i+1] != 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base +offset );
   }
  }
  
  for(int i=0;i<dimension.width-2;i++)
  {
   base = 2*dimension.height/6;
   if( ( bit1[i] == 0 ) && ( bit1[i+1] == 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
   }
   if( ( bit1[i] == 0 ) && ( bit1[i+1] != 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
     g.drawLine( i+1, base, i+1, base + offset );
   }
   if( ( bit1[i] != 0 ) && ( bit1[i+1] == 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base + offset );
     g.drawLine( i+1, base + offset, i+1, base );
   }
   if( ( bit1[i] != 0 ) && ( bit1[i+1] != 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base +offset );
   }
  }

   for(int i=0;i<dimension.width-2;i++)
  {
   base = 3*dimension.height/6;
   if( ( bit2[i] == 0 ) && ( bit2[i+1] == 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
   }
   if( ( bit2[i] == 0 ) && ( bit2[i+1] != 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
     g.drawLine( i+1, base, i+1, base + offset );
   }
   if( ( bit2[i] != 0 ) && ( bit2[i+1] == 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base + offset );
     g.drawLine( i+1, base + offset, i+1, base );
   }
   if( ( bit2[i] != 0 ) && ( bit2[i+1] != 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base +offset );
   }
  }
   
   for(int i=0;i<dimension.width-2;i++)
  {
   base = 4*dimension.height/6;
   if( ( bit3[i] == 0 ) && ( bit3[i+1] == 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
   }
   if( ( bit3[i] == 0 ) && ( bit3[i+1] != 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
     g.drawLine( i+1, base, i+1, base + offset );
   }
   if( ( bit3[i] != 0 ) && ( bit3[i+1] == 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base + offset );
     g.drawLine( i+1, base + offset, i+1, base );
   }
   if( ( bit3[i] != 0 ) && ( bit3[i+1] != 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base +offset );
   }
  }

      for(int i=0;i<dimension.width-2;i++)
  {
   base = 5*dimension.height/6;
   if( ( bit4[i] == 0 ) && ( bit4[i+1] == 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
   }
   if( ( bit4[i] == 0 ) && ( bit4[i+1] != 0 ) ) 
   {
     g.drawLine( i, base, i+1, base );
     g.drawLine( i+1, base, i+1, base + offset );
   }
   if( ( bit4[i] != 0 ) && ( bit4[i+1] == 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base + offset );
     g.drawLine( i+1, base + offset, i+1, base );
   }
   if( ( bit4[i] != 0 ) && ( bit4[i+1] != 0 ) ) 
   {
     g.drawLine( i, base + offset, i+1, base +offset );
   }
  }

   
 }
}
